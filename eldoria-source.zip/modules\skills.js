// =====================================================================
// skills.js — ห่อการใช้สกิล/อัลติ ด้วย Guard (isCasting) · ส่ง SKILL_CAST · ตัวกันสตันค้าง
// =====================================================================
(()=>{
 const resetCast=()=>{try{P.cast=0;P.stun=Math.min(P.stun||0,.15);if(typeof FLK!=='undefined'&&FLK.on){FLK.on=false}}catch(e){}};
 const _us=useSkill;useSkill=function(i){const cd0=(CS.cd||[])[i],mp0=P.mp;return Guard.run('useSkill',()=>{const r=_us(i);const cast=(CS.cd||[])[i]!==cd0||P.mp<mp0;const S=(CSKILLS[P.cls]||[])[i];
   EventBus.emit(cast?EV.SKILL_CAST:EV.SKILL_FAILED,{i,name:S&&S.n,cls:P.cls});return r},'isCasting',resetCast)};
 window.useSkill=useSkill;
 const _cu=castUlt;castUlt=function(){return Guard.run('castUlt',()=>{const was=!!ULT.cast;const r=_cu.apply(this,arguments);if(!was&&ULT.cast)EventBus.emit(EV.SKILL_CAST,{ult:true,cls:P.cls});return r},'isCasting',()=>{try{ULT.cast=null;ultOv.classList.remove('on')}catch(_){}resetCast()})};
 window.castUlt=castUlt;
 // ตัวกันสตันค้าง: ถ้าสตันนานผิดปกติ (ไม่ได้โดนตี/ไม่ได้ร่ายอัลติ/ไม่ได้ตีบวก) ปลดให้เอง
 let stunT=0;setInterval(()=>{try{if(P.stun>0&&!P.dead&&!ULT.cast&&!(window.FRG7on)&&!(typeof FLK!=='undefined'&&FLK.on)&&!P.jump){stunT+=.5;if(stunT>=3){P.stun=0;stunT=0;console.warn('[skills] stun watchdog reset')}}else stunT=0}catch(e){}},500);
 Eldoria.register('skills',{list:()=>CSKILLS[P.cls]||[],cast:i=>useSkill(i)});
})();
// ---------- Line of Sight (จากผลตรวจ QA bot) ----------
// ห้ามทำดาเมจ/วาปทะลุกำแพง: ตรวจกำแพงระหว่างผู้เล่น (และจุดต้นทางของการโจมตี) กับเป้าหมาย — ใช้เฉพาะกำแพงจริงในโซน/ดันเจี้ยน
function wallBetween7(x0,y0,x1,y1){try{if(!D||!D.zone||!D.zone.m)return false;const m=D.zone.m,d=Math.hypot(x1-x0,y1-y0),n=Math.ceil(d/10);
 for(let i=1;i<n;i++){const u=i/n,x=x0+(x1-x0)*u,y=y0+(y1-y0)*u-6,tx=Math.floor(x/T),ty=Math.floor(y/T);if(!m[ty]||m[ty][tx]!==FL)return true}return false}catch(e){return false}}
window.wallBetween7=wallBetween7;window.MINSRC7=0;
(()=>{const _mt=minTick;minTick=function(dt){window.MINSRC7++;try{return _mt(dt)}finally{window.MINSRC7--}};
 const _h=hurtE;hurtE=function(e,mult,o){try{if(e&&D&&D.zone&&!D.home&&!(e.qaBypass)){const ex=e.x,ey=e.y-6;
   if(window.MINSRC7>0){if(o&&isFinite(o.fx)&&isFinite(o.fy)&&wallBetween7(o.fx,o.fy,ex,ey))return 0}
   else if(wallBetween7(P.x,P.y-6,ex,ey))return 0}}catch(err){}return _h(e,mult,o)};
 // ฟันวาป/ยิงวาป: เลือกเฉพาะเป้าที่มองเห็น (ไม่วาปข้ามกำแพง)
 flkTarget=function(){let b=null,bd=1e9;for(const e of enemies()){if(e.dead)continue;const r=Math.hypot(e.x-P.x,e.y-P.y);if(r>=330)continue;if(wallBetween7(P.x,P.y-6,e.x,e.y-6))continue;const d=r+(FLK.hit.has(e)?400:0);if(d<bd){bd=d;b=e}}return b};
 // อัญเชิญ: มินเนียนไม่ไล่ล่าเป้าที่อยู่หลังกำแพง (กันบินข้ามกำแพงไปตี)
 const _en=enemies;enemies=function(){const L=_en();if(window.MINSRC7>0&&D&&D.zone&&!D.home)return L.filter(e=>!wallBetween7(P.x,P.y-6,e.x,e.y-6));return L};
 // exitD ปลอดภัยเมื่อไม่ได้อยู่ในฉากย่อย
 const _ex=exitD;exitD=function(){if(!D)return;return _ex.apply(this,arguments)};
})();
