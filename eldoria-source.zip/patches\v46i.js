
// =====================================================================
// v4.7 (ฌ) : ระบบตีบวกอุปกรณ์ (Equipment Enhancement) — ต่อเข้ากับของเดิม
//  ใช้ข้อมูลเดิมทั้งหมด: ITEMS (ข้อมูลไอเท็ม) · GEAR (กระเป๋าอุปกรณ์) · P.armor (ของที่สวม) · ENH (ระดับตีบวกต่อไอเท็ม)
//  inv.coin (เงิน) · inv.estone (💎 หินเสริมพลัง) · สูตรค่าสถานะเดิม enhAtk/enhDef · ทั่งตีเหล็กเดิมในร้านอุปกรณ์
//  ไม่สร้าง Inventory / Item DB / Equipment ใหม่ · ไม่แตะดาบ/ขวาน/ธนู/คฑา/การเดิน
// =====================================================================
// ---------- CONFIG (แก้ที่นี่ที่เดียว) ----------
const MAX_ENHANCEMENT=MAXP;                  // ระดับสูงสุด (ใช้ค่าเดิมของเกม MAXP=15 — ระบบกันโกงก็ใช้ค่านี้)
const ENHCFG={
 ALWAYS_SUCCESS:true,                         // เวอร์ชันแรก: สำเร็จ 100% · ตั้ง false = ใช้อัตราเดิม RATE[] และกติกาลดระดับเดิม
 rate:l=>ENHCFG.ALWAYS_SUCCESS?100:RATE[l],
 cost:l=>({gold:50*(l+1)*(l+2),stone:ENH_EST(l)}),   // +0→+1: 100G 💎1 · +4→+5: 1,500G 💎3 · +9→+10: 5,500G 💎5
 strikes:4,                                    // จำนวนครั้งที่ทุบ (ครั้งสุดท้ายแรงสุด)
 // ประเภทที่ตีบวกได้ + ค่าสถานะที่เพิ่ม (ใช้สูตรเดิมของเกม)
 kinds:{
  sword:{g:'w',ic:'⚔️',n:'โจมตี',v:(t,l)=>SWATK[t]+enhAtk(l)},
  bow:  {g:'w',ic:'🏹',n:'โจมตีธนู',v:(t,l)=>SWATK[t]+enhAtk(l)},
  staff:{g:'w',ic:'🔮',n:'พลังเวท',v:(t,l)=>SWATK[t]+enhAtk(l)},
  helm: {g:'a',ic:'⛑️',n:'ป้องกัน',v:(t,l)=>ADEF.helm[t]+enhDef(l)},
  chest:{g:'a',ic:'🛡️',n:'ป้องกัน',v:(t,l)=>ADEF.chest[t]+enhDef(l)},
  pants:{g:'a',ic:'👖',n:'ป้องกัน',v:(t,l)=>ADEF.pants[t]+enhDef(l)},
  arm:  {g:'a',ic:'🧤',n:'ป้องกัน',v:(t,l)=>ADEF.arm[t]+enhDef(l)},
  ring: {g:'j',ic:'💍',n:'โจมตี',v:(t,l)=>RINGATK[t]+enhRing7(l)},
  neck: {g:'j',ic:'📿',n:'เลือดสูงสุด',v:(t,l)=>NECKHP[t]+enhNeck7(l)},
  axe:  {g:'t',ic:'🪓',n:'แรงตัดไม้',v:(t,l)=>1+(t>>1)+enhTool7(l)},
  pick: {g:'t',ic:'⛏️',n:'แรงขุด',v:(t,l)=>1+(t>>1)+enhTool7(l)}},
 groups:[['all','ทั้งหมด'],['w','อาวุธ'],['a','เกราะ'],['j','เครื่องประดับ'],['t','เครื่องมือ']]};
// โบนัสของประเภทที่เดิมยังไม่ได้รับผลจากการตีบวก (แหวน/สร้อย/ขวาน/ที่ขุด) — ผูกเข้ากับสูตรเดิมผ่านฮุกใน build
function enhRing7(l){return Math.ceil(enhAtk(l)/2)}
function enhNeck7(l){return l*6}
function enhTool7(l){return Math.floor(l/3)}
window.enhX7=id=>{const it=ITEMS[id];if(!it)return 0;const l=ENH[id]|0;return it.kind==='ring'?enhRing7(l):it.kind==='neck'?enhNeck7(l):0};
window.enhT7=k=>enhTool7(ENH[k+((P.tier&&P.tier[k])|0)]|0);
const canEnh7=id=>{const it=ITEMS[id];return !!(it&&ENHCFG.kinds[it.kind]&&it.enhance!==false)};   // ใช้ property เดิม (kind) · ไอเท็มที่ตั้ง enhance:false = ตีบวกไม่ได้
const enhLv7=id=>ENH[id]|0;
const enhStat7=(id,l)=>{const it=ITEMS[id],K=ENHCFG.kinds[it.kind];return K.v(it.tier,l==null?enhLv7(id):l)};
// รายการของจริงจากกระเป๋า + ของที่สวมอยู่ (ไม่มีของปลอม)
function enhList7(){const L=[],seen=new Set();for(const k in P.armor){const id=P.armor[k];if(id&&canEnh7(id)&&!seen.has(id)){seen.add(id);L.push({id,worn:true,n:(GEAR[id]|0)})}}
 for(const id of Object.keys(GEAR).sort()){if((GEAR[id]|0)>0&&canEnh7(id)&&!seen.has(id)){seen.add(id);L.push({id,worn:false,n:GEAR[id]|0})}}
 const ord=Object.keys(ENHCFG.kinds);L.sort((a,b)=>(b.worn-a.worn)||ord.indexOf(ITEMS[a.id].kind)-ord.indexOf(ITEMS[b.id].kind)||ITEMS[b.id].tier-ITEMS[a.id].tier);return L}
// ตรวจสอบก่อนตีบวก (คืนข้อความเหตุผล หรือ null = ผ่าน)
function enhCheck7(id){if(!id)return 'ยังไม่ได้เลือกอุปกรณ์';if(!canEnh7(id))return 'อุปกรณ์นี้ไม่สามารถตีบวกได้';
 if(!(P.armor[ITEMS[id].kind]===id||(GEAR[id]|0)>0))return 'ไม่มีอุปกรณ์นี้ในกระเป๋าแล้ว';
 const l=enhLv7(id);if(l>=MAX_ENHANCEMENT)return 'อุปกรณ์นี้ถึงระดับสูงสุดแล้ว (+'+MAX_ENHANCEMENT+')';const c=ENHCFG.cost(l);
 if((inv.coin|0)<c.gold)return 'Gold ไม่เพียงพอ (ต้องใช้ '+c.gold.toLocaleString()+' มี '+(inv.coin|0).toLocaleString()+')';
 if((inv.estone|0)<c.stone)return 'วัตถุดิบไม่เพียงพอ — 💎 หินเสริมพลัง ต้องใช้ '+c.stone+' มี '+(inv.estone|0);return null}

// ---------- STATE ----------
const ENHS={open:false,sel:null,grp:'all',busy:false,res:null,msg:''};
const enhW=mk6('enhw');
{const st=document.createElement('style');st.textContent=`
#enhw .w{width:min(820px,97%)}
#enhw .lstE{flex:1;overflow-y:auto;display:flex;flex-direction:column;gap:5px;padding:2px}
#enhw .rowE{display:flex;align-items:center;gap:8px;padding:6px 8px;border-radius:10px;background:rgba(255,255,255,.05);border:1.5px solid rgba(255,255,255,.1);cursor:pointer;text-align:left;color:inherit;font:inherit}
#enhw .rowE.sel{border-color:#ffe9a0;background:rgba(255,233,160,.12);box-shadow:0 0 10px rgba(255,233,160,.25)}
#enhw .rowE img{width:38px;height:38px;flex:none;border-radius:8px;background:radial-gradient(circle at 50% 60%,#4a3a6a,#1a1428)}
#enhw .rowE b{font-size:13px;color:#fff}#enhw .rowE small{display:block}
#enhw .tag{font:800 10px system-ui;padding:1px 5px;border-radius:6px;background:#3a5a2a;color:#cfe;margin-left:4px}
#enhw .gtab{display:flex;gap:4px;flex-wrap:wrap}#enhw .gtab button{font:800 11.5px system-ui;padding:4px 8px;border-radius:8px;border:1px solid #8a7040;background:#2a2014;color:#ffe9c0}#enhw .gtab button.on{background:#ffe9a0;color:#3a2408}
#enhw .det{flex:1;display:flex;flex-direction:column;gap:7px;min-width:0;overflow-y:auto;padding-right:2px}#enhw .go{flex:none}
#enhw .big{display:flex;gap:10px;align-items:center}#enhw .big img{width:74px;height:74px;border-radius:14px;background:radial-gradient(circle at 50% 60%,#5a4a7a,#1a1428);border:2px solid var(--ec,#666);box-shadow:0 0 14px var(--eg,transparent)}
#enhw .nm{font-size:16px;font-weight:900;color:#fff}#enhw .lvl{font-size:26px;font-weight:900;text-align:center;letter-spacing:1px}
#enhw .arr{color:#ffe9a0;margin:0 8px}
#enhw .mat{display:flex;justify-content:space-between;align-items:center;padding:6px 9px;border-radius:9px;background:rgba(0,0,0,.3);font-size:13px}
#enhw .mat .no{color:#ff8a7a;font-weight:800}#enhw .mat .ok{color:#8fe08a;font-weight:800}
#enhw .go{font:900 16px system-ui;padding:11px;border-radius:12px;border:2px solid #ffe9a0;background:linear-gradient(180deg,#f2c14a,#b8781a);color:#3a2008;cursor:pointer;box-shadow:0 3px 0 #6a4008}
#enhw .go:disabled{filter:grayscale(.8) brightness(.7);cursor:default}
#enhw .why{min-height:16px;font-size:12px;color:#ff9a8a;text-align:center}
#enhw .res{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;text-align:center}
#enhw .res h2{margin:0;font-size:22px;color:#ffe9a0;text-shadow:0 0 12px rgba(255,220,120,.8);animation:enhPop .5s ease-out}
#enhw .res img{width:96px;height:96px;border-radius:16px;background:radial-gradient(circle,#ffe9a0 0%,#6a4a20 55%,#1a1428 100%);animation:enhGlow 1.2s ease-in-out 2}
@keyframes enhPop{0%{transform:scale(.4);opacity:0}70%{transform:scale(1.12)}100%{transform:scale(1)}}
@keyframes enhGlow{0%,100%{box-shadow:0 0 6px #ffd84a}50%{box-shadow:0 0 30px #ffd84a,0 0 60px rgba(255,216,74,.5)}}
@media (max-height:440px){#enhw .det{gap:4px}#enhw .mat{padding:4px 8px;font-size:12px}#enhw .card.big{padding:5px}#enhw .big img{width:44px;height:44px}#enhw .lvl{font-size:18px}#enhw .go{padding:7px;font-size:14px}#enhw .rowE img{width:30px;height:30px}#enhw .res img{width:70px;height:70px}}`;document.head.appendChild(st)}
const ico7=id=>iconURL('item:'+id);
function enhRender7(){if(!ENHS.open)return;let h='<div class="w"><div class="hd"><b>⚒️ ตีบวกอุปกรณ์ · ENHANCEMENT</b><button onclick="enhCraft7()" title="สร้างอุปกรณ์ใหม่ที่ทั่ง">🛠️ คราฟ</button><button onclick="closeEnh7()">✕</button></div>';
 if(ENHS.res){const r=ENHS.res,it=ITEMS[r.id],K=ENHCFG.kinds[it.kind];
  h+='<div class="bd"><div class="res">'+(r.ok?'<h2>✨ ENHANCEMENT SUCCESS! ✨</h2>':'<h2 style="color:#ff9a8a">💥 ENHANCEMENT FAILED</h2>')+'<img src="'+ico7(r.id)+'"><div class="nm">'+it.name+'</div>'
   +'<div class="lvl"><span style="color:'+enhCol(r.from)+'">+'+r.from+'</span><span class="arr">→</span><span style="color:'+enhCol(r.to)+'">+'+r.to+'</span></div>'
   +'<div class="mat" style="min-width:220px"><span>'+K.ic+' '+K.n+'</span><span><b>'+r.s0+'</b> <span class="arr">→</span> <span class="ok">'+r.s1+'</span></span></div>'
   +'<button class="go" style="min-width:180px" onclick="enhBack7()">ตกลง</button></div></div></div>';enhW.innerHTML=h;return}
 const L=enhList7().filter(o=>ENHS.grp==='all'||ENHCFG.kinds[ITEMS[o.id].kind].g===ENHS.grp);if(ENHS.sel&&!enhList7().some(o=>o.id===ENHS.sel))ENHS.sel=null;if(!ENHS.sel&&L.length)ENHS.sel=L[0].id;
 h+='<div class="bd"><div class="col" style="width:44%;min-width:0"><div class="gtab">'+ENHCFG.groups.map(([g,n])=>'<button class="'+(ENHS.grp===g?'on':'')+'" onclick="enhGrp7(\''+g+'\')">'+n+'</button>').join('')+'</div><div class="lstE">';
 if(!L.length)h+='<small style="padding:10px">ไม่มีอุปกรณ์ที่ตีบวกได้ในหมวดนี้<br>(ยา อาหาร วัตถุดิบ ของเควส จะไม่แสดงที่นี่)</small>';
 for(const o of L){const it=ITEMS[o.id],l=enhLv7(o.id),K=ENHCFG.kinds[it.kind];
  h+='<button class="rowE'+(ENHS.sel===o.id?' sel':'')+'" onclick="enhSel7(\''+o.id+'\')"><img src="'+ico7(o.id)+'"><div style="min-width:0"><b>'+K.ic+' '+it.name+' <span style="color:'+enhCol(l)+'">+'+l+'</span></b>'+(o.worn?'<span class="tag">สวมอยู่</span>':'')+(o.n>(o.worn?0:1)?'<span class="tag" style="background:#3a3a5a">×'+(o.n+(o.worn?1:0))+'</span>':'')+'<small>'+K.n+' +'+enhStat7(o.id)+'</small></div></button>'}
 h+='</div></div><div class="det">';
 const id=ENHS.sel;if(!id){h+='<div class="card" style="flex:1;display:flex;align-items:center;justify-content:center"><small>เลือกอุปกรณ์ทางซ้าย</small></div>'}
 else{const it=ITEMS[id],l=enhLv7(id),K=ENHCFG.kinds[it.kind],mx=l>=MAX_ENHANCEMENT,c=ENHCFG.cost(Math.min(l,MAX_ENHANCEMENT-1)),why=enhCheck7(id),ec=enhCol(l);
  h+='<div class="card big" style="--ec:'+ec+';--eg:'+(l>=3?ec:'transparent')+'"><img src="'+ico7(id)+'"><div><div class="nm">'+it.name+'</div><small>'+(GKIND[it.kind]||it.kind)+' · ระดับไอเท็ม '+TNAMES[it.tier]+' (ขั้น '+(it.tier+1)+')</small><br><small>Enhancement: <b style="color:'+ec+'">+'+l+'</b> / +'+MAX_ENHANCEMENT+'</small></div></div>';
  h+='<div class="lvl">'+(mx?'<span style="color:'+ec+'">+'+l+' MAX</span>':'<span style="color:'+ec+'">+'+l+'</span><span class="arr">→</span><span style="color:'+enhCol(l+1)+'">+'+(l+1)+'</span><small style="font-size:11px;color:#8fe08a;margin-left:8px;vertical-align:middle">🎯 สำเร็จ '+ENHCFG.rate(l)+'%</small>')+'</div>';
  h+='<div class="mat"><span>'+K.ic+' '+K.n+'</span><span><b>'+enhStat7(id,l)+'</b>'+(mx?'':' <span class="arr">→</span> <span class="ok">'+enhStat7(id,l+1)+'</span>')+'</span></div>';
  if(!mx){const hg=inv.coin|0,hs=inv.estone|0;
   h+='<div class="mat"><span>💰 Gold</span><span class="'+(hg>=c.gold?'ok':'no')+'">'+c.gold.toLocaleString()+' <small style="opacity:.8">(มี '+hg.toLocaleString()+')</small></span></div>';
   h+='<div class="mat"><span>💎 หินเสริมพลัง</span><span class="'+(hs>=c.stone?'ok':'no')+'">×'+c.stone+' <small style="opacity:.8">(มี '+hs+')</small></span></div>';
}
  h+='<div class="why">'+(ENHS.msg||why||'')+'</div><button class="go" '+(why?'disabled':'')+' onclick="enhStart7()">⚒️ ตีบวก</button>'}
 h+='</div></div></div>';enhW.innerHTML=h}
window.enhSel7=id=>{if(ENHS.busy)return;ENHS.sel=id;ENHS.msg='';sfx('ui');enhRender7()};
window.enhGrp7=g=>{if(ENHS.busy)return;ENHS.grp=g;ENHS.sel=null;ENHS.msg='';sfx('ui');enhRender7()};
window.enhBack7=()=>{ENHS.res=null;ENHS.msg='';sfx('ui');enhRender7()};
window.enhCraft7=()=>{if(ENHS.busy)return;closeEnh7();FUI.tab='craft';openForge('anvil')};
function openEnh7(id){if(ENHS.busy)return;if(!stn('anvil')||Math.hypot(P.x-stn('anvil').x,P.y-stn('anvil').y)>90){say('🔨 ไปที่ทั่งตีเหล็กในร้านอุปกรณ์ แล้วกด E เพื่อตีบวก');sfx('thud');return}
 try{closeForge()}catch(e){}try{hideBag()}catch(e){}ENHS.open=true;ENHS.res=null;ENHS.msg='';if(id)ENHS.sel=id;enhRender7();p6open(enhW)}
window.openEnh7=openEnh7;
window.closeEnh7=function(){if(ENHS.busy)return;ENHS.open=false;ENHS.res=null;p6close(enhW)};
addEventListener('keydown',e=>{if(!ENHS.open&&!ENHS.busy)return;if(e.key==='Escape'){e.stopImmediatePropagation();e.preventDefault();closeEnh7()}},true);
// กด E ที่ทั่ง = เปิดหน้าตีบวก (ทั่งเดิมยังคราฟได้ผ่านปุ่ม 🛠️ คราฟ)
{const _sa=shopAct;shopAct=function(){const s=typeof stnNear==='function'?stnNear():null;if(s&&s.k==='anvil'&&!P.sit){if(!ENHS.busy&&!ENHS.open)openEnh7();return true}return _sa()}}
try{const s=SHOP_STN.gear.find(s=>s.k==='anvil');if(s)s.n='🔨 ทั่งตีเหล็ก · ตีบวก'}catch(e){}
// ระบบตีบวกเดิม (สุ่มพลาด) → ใช้หน้าใหม่แทน (ไม่ให้มีสองระบบ)
enhItem=function(id){openEnh7(id)};
{const _of=openForge;openForge=function(k){if(k==='anvil'&&FUI.tab==='enh'){FUI.tab='craft';return openEnh7()}return _of(k)}}

// ---------- กดตีบวก: ตัดของ + บันทึกผลทันที (กันกดรัว/ของหาย) → เล่นแอนิเมชันตีเหล็ก → แสดงผล ----------
function enhStart7(){if(ENHS.busy)return;const id=ENHS.sel,why=enhCheck7(id);if(why){ENHS.msg=why;sfx('thud');enhRender7();return}
 ENHS.busy=true;const it=ITEMS[id],l=enhLv7(id),c=ENHCFG.cost(l),s0=enhStat7(id,l);
 inv.coin-=c.gold;inv.estone-=c.stone;
 let ok=Math.random()*100<ENHCFG.rate(l),to=l;
 if(ok)to=l+1;else if(l>=5){if(inv.bless>0)inv.bless--;else to=l-1}
 ENH[id]=to;try{recalcStats()}catch(e){}try{refreshInv()}catch(e){}try{saveGame(true)}catch(e){}
 ENHS.res={id,ok,from:l,to,s0,s1:enhStat7(id,to)};
 enhW.hidden=true;forgeStart7(id,ok)}
window.enhStart7=enhStart7;

// ---------- FORGING ANIMATION : เดินไปหน้าทั่ง → ยกค้อน → เหวี่ยง → กระแทก → ยกกลับ ×4 (ครั้งสุดท้ายแรงสุด) ----------
const FRG={on:false,t0:0,id:null,a:null,from:null,to:null,sp:[],hit:-1,ok:true};
const FRG_WALK=.45,FRG_HIT=[.62,.62,.62,.95],FRG_END=.45;
const frgTotal=()=>FRG_WALK+FRG_HIT.reduce((a,b)=>a+b,0)+FRG_END;
function forgeStart7(id,ok){const a=stn('anvil');FRG.on=true;window.FRG7on=true;FRG.t0=performance.now();FRG.id=id;FRG.ok=ok;FRG.a=a;FRG.from={x:P.x,y:P.y};FRG.to={x:a.x-24,y:a.y+6};FRG.sp=[];FRG.hit=-1;FRG.d0=P.dir;FRG.tool=P.tool;FRG.draw=P.draw;P.at=-1;PAUSED=false}
function forgeEnd7(){FRG.on=false;window.FRG7on=false;P.mv=false;P.dir='r';P.tool=FRG.tool;P.draw=FRG.draw;ENHS.busy=false;enhW.hidden=false;PAUSED=true;
 if(FRG.ok){sfx('chest');setTimeout(()=>sfx('gem'),180)}else sfx('thud');enhRender7()}
// ระหว่างตี: ล็อกการควบคุมตัวละคร (ข้าม playerTick ของผู้เล่นชั่วคราว · โลกเกมยังวาด/เคลื่อนไหวตามปกติ)
{const _pt=playerTick;playerTick=function(dt){if(FRG.on)return;return _pt(dt)}}
{const _a=attack;attack=function(q){if(FRG.on||ENHS.busy)return;return _a(q)}}
// เฟสของการตี: คืน {k:ครั้งที่, u:0..1, last}
function frgPhase(t){if(t<FRG_WALK)return{walk:t/FRG_WALK};let s=FRG_WALK;for(let i=0;i<FRG_HIT.length;i++){if(t<s+FRG_HIT[i])return{k:i,u:(t-s)/FRG_HIT[i],last:i===FRG_HIT.length-1};s+=FRG_HIT[i]}return{done:(t-s)/FRG_END}}
// ท่า (หันขวา): มือคู่จับด้ามค้อน [x,y] · มุมค้อน · ลำตัว [เอน, ย่อ]
function frgPose(ph){const R={h:[5,-28],a:.95,b:[0,0]},Wt={h:[-3,-42],a:-1.05,b:[-2.5,-1.5]},Wl={h:[-5,-46],a:-1.5,b:[-3.5,-2]},S={h:[0,-35],a:1.67,b:[3,2]},Sl={h:[1,-34],a:1.72,b:[4,3]};
 const LP=(p,q,u)=>({h:[L7(p.h[0],q.h[0],u),L7(p.h[1],q.h[1],u)],a:L7(p.a,q.a,u),b:[L7(p.b[0],q.b[0],u),L7(p.b[1],q.b[1],u)]});
 if(ph.walk!=null||ph.done!=null)return Object.assign({},R,{h:R.h.slice(),b:[0,0]});
 const W=ph.last?Wl:Wt,Sx=ph.last?Sl:S,u=ph.u;
 if(u<.45)return LP(R,W,e6o(u/.45));                 // ยกค้อน เตรียมแรง น้ำหนักไปด้านหลัง
 if(u<.58)return LP(W,Sx,e6i((u-.45)/.13));          // เหวี่ยงลง
 if(u<.70){const k=Math.sin((u-.58)/.12*Math.PI)*(1-(u-.58)/.12);const o=LP(Sx,Sx,0);o.h[1]+=k*1.2;o.a-=k*.06;return o}  // กระแทก (ค้อนเด้งเล็กน้อย)
 return LP(Sx,R,e6io((u-.70)/.30))}                   // ยกกลับ
function frgHammer(hx,hy,ang){ctx.save();ctx.translate(hx,hy);ctx.rotate(ang);ctx.drawImage(farmTool('hamr',3),-21,-30,42,42);ctx.restore()}
function frgClank(last){try{tone(1900,1850,.25,'triangle',last?.16:.11);tone(2850,2800,.2,'sine',last?.1:.07);nz(.06,last?.55:.4,4200,1600,3)}catch(e){}try{sfx('mine')}catch(e){}}
// วาดฉาก: ไอเท็มร้อนบนทั่ง · ค้อน · แขน · ประกายไฟ (เรียกจาก slashFx ระหว่างตี)
function frgDraw(x,by,TOP){const t=(performance.now()-FRG.t0)/1000,ph=frgPhase(t),a=FRG.a,po=frgPose(ph);
 const ix=a.x-4-(P.x-x),iy=a.y-27-(P.y-by),it=ITEMS[FRG.id];
 // ไอเท็มบนทั่ง: ร้อนแดงตอนตี → เรืองทองตอนจบ
 const heat=ph.k!=null?Math.max(.35,1-Math.abs(ph.u-.62)*2):ph.done!=null?0:.2;
 try{ctx.save();ctx.translate(ix,iy);ctx.rotate(-1.35);ctx.globalAlpha=.95;ctx.drawImage(toolIcon(it.kind,it.tier,64),-10,-10,20,20);ctx.restore();
  ctx.save();ctx.globalCompositeOperation='lighter';const gc=ph.done!=null&&FRG.ok?'255,220,90':'255,120,40',r=ph.done!=null?14+6*Math.sin(t*10):10;const g=ctx.createRadialGradient(ix,iy,0,ix,iy,r);g.addColorStop(0,'rgba('+gc+','+(ph.done!=null?.8:.55*heat)+')');g.addColorStop(1,'rgba('+gc+',0)');ctx.fillStyle=g;ctx.fillRect(ix-r,iy-r,r*2,r*2);ctx.restore()}catch(e){}
 const hx=x+po.h[0],hy=by+po.h[1];
 // ค้อน (สองมือจับด้าม) + แขนสองข้าง
 frgHammer(hx,hy,po.a);
 swArm6(x-1,by-24,hx-2,hy+2,TOP,-1);swArm6(x+2,by-25,hx+1,hy-2,TOP,1);ctx.fillStyle='#f1d2b0';ctx.fillRect(hx-4,hy-1,4,4);ctx.fillRect(hx,hy-4,4,4);
 // กระแทก: ประกายไฟ + แฟลชเล็ก ๆ + เสียง
 if(ph.k!=null&&ph.u>=.58&&FRG.hit!==ph.k){FRG.hit=ph.k;frgClank(ph.last);const n=ph.last?22:12;for(let i=0;i<n;i++){const an=-Math.PI/2+(Math.random()-.5)*2.6,sp=60+Math.random()*(ph.last?150:100);FRG.sp.push({x:ix,y:iy-2,vx:Math.cos(an)*sp,vy:Math.sin(an)*sp,t:performance.now(),l:.35+Math.random()*.35})}
  if(ph.last)try{shake(2,.12)}catch(e){}}
 if(ph.k!=null&&ph.u>=.58&&ph.u<.72){const k=1-(ph.u-.58)/.14;ctx.save();ctx.globalCompositeOperation='lighter';ctx.globalAlpha=k;ctx.fillStyle='#fff';ctx.beginPath();for(let i=0;i<8;i++){const an=i*Math.PI/4,r=i%2?3:(ph.last?13:9)*k+3;ctx.lineTo(ix+Math.cos(an)*r,iy-3+Math.sin(an)*r)}ctx.closePath();ctx.fill();ctx.restore()}
 const now=performance.now();FRG.sp=FRG.sp.filter(s=>(now-s.t)/1000<s.l);ctx.save();ctx.globalCompositeOperation='lighter';for(const s of FRG.sp){const tt=(now-s.t)/1000,k=1-tt/s.l;ctx.fillStyle='rgba(255,'+(170+Math.floor(80*k))+',60,'+k+')';ctx.fillRect(s.x+s.vx*tt-1,s.y+s.vy*tt+160*tt*tt-1,2,2)}ctx.restore();
 // จบ: ประกายสำเร็จ
 if(ph.done!=null&&FRG.ok){ctx.save();ctx.globalCompositeOperation='lighter';ctx.globalAlpha=Math.max(0,1-ph.done)*.8;ctx.strokeStyle='#ffe9a0';ctx.lineWidth=2;ctx.beginPath();ctx.arc(ix,iy,6+22*ph.done,0,7);ctx.stroke();ctx.restore()}}
// ฮุกเข้าตัวละครเดิม: ระหว่างตี ใช้ท่าทุบค้อนสองมือแทนอาวุธ (ซ่อนแขนเดิมกันเป็น 3 แขน) + ลำตัวเอน/ย่อตามแรง
{const _sf=slashFx;slashFx=function(x,by,d,side,f,TOP,held){if(!(FRG.on&&!window._drawingOther))return _sf(x,by,d,side,f,TOP,held);frgDraw(x,by,TOP)}}
{const _hb=heroBody;heroBody=function(){if(!FRG.on||window._drawingOther)return _hb();const t=(performance.now()-FRG.t0)/1000;
  if(t>=frgTotal()){forgeEnd7();return _hb()}
  const ph=frgPhase(t);
  if(ph.walk!=null){const u=e6io(Math.min(1,ph.walk));P.x=L7(FRG.from.x,FRG.to.x,u);P.y=L7(FRG.from.y,FRG.to.y,u);const dx=FRG.to.x-FRG.from.x,dy=FRG.to.y-FRG.from.y;
   if(Math.hypot(dx,dy)>4&&ph.walk<.92){P.mv=true;P.t=t*14;P.dir=Math.abs(dx)>Math.abs(dy)?(dx<0?'l':'r'):(dy<0?'u':'d');return _hb()}P.mv=false;P.dir='r';return _hb()}
  P.mv=false;P.dir='r';const po=frgPose(ph),lean=po.b[0],dip=po.b[1];
  const d0=P.draw,t0=P.tool,a0=P.at;P.draw=true;P.tool='hamr';P.at=.001;
  ctx.save();ctx.translate(P.x,P.y);ctx.transform(1,0,-lean/44,1,0,0);ctx.scale(1,1-Math.max(0,dip)*.012+Math.max(0,-dip)*.01);ctx.translate(-P.x,-P.y);
  try{_hb()}finally{ctx.restore();P.draw=d0;P.tool=t0;P.at=a0}}}

// =====================================================================
// แถบเควสด้านบน → ปุ่ม "📜 เควส" กดดูได้ (ไม่บังจอ) · กดแถบที่เปิดอยู่ = เปิดสมุดเควสเหมือนเดิม
// =====================================================================
{const st=document.createElement('style');st.textContent='#qtrack.qh7{display:none!important}#zin,#zout{display:none!important}#qbtn7{position:relative;font-size:15px}#qbtn7 i{position:absolute;right:-3px;top:-4px;font-style:normal;font-size:10px}#qbtn7[hidden]{display:none}#qbtn7.rep{border-color:#8fe08a;color:#cfffc0;animation:qtPulse 1.2s infinite}#qbtn7.on{background:#ffe9a0!important;color:#3a2408}';document.head.appendChild(st)}
const qBtn7=document.createElement('button');qBtn7.id='qbtn7';qBtn7.title='เควส';qBtn7.textContent='📜';{const zb=gid('zb'),pb=gid('pasb');if(zb){if(pb&&pb.parentNode===zb)zb.insertBefore(qBtn7,pb.nextSibling);else zb.appendChild(qBtn7)}else gid('wrap').appendChild(qBtn7)} // ปุ่มเควสอยู่ข้างปุ่ม 🌟 (แทนที่ปุ่มซูม +/-)qBtn7.addEventListener('pointerdown',e=>e.stopPropagation());
qtEl.classList.add('qh7');let qOpen7=false,qT7=0;
function qSync7(){qBtn7.hidden=qtEl.hidden;qtEl.classList.toggle('qh7',!qOpen7);qBtn7.classList.toggle('rep',qtEl.classList.contains('rep'));qBtn7.classList.toggle('on',qOpen7);qBtn7.innerHTML='📜'+(qtEl.classList.contains('rep')?'<i>✅</i>':'');
 if(qOpen7){try{const r=qBtn7.getBoundingClientRect(),w=gid('wrap').getBoundingClientRect();qtEl.style.left=(r.right-w.left+6)+'px';qtEl.style.top=(r.top-w.top-3)+'px';qtEl.style.transform='none';qtEl.style.textAlign='left'}catch(e){}}else{qtEl.style.left='';qtEl.style.top='';qtEl.style.transform='';qtEl.style.textAlign=''}}  // แถบเควสโผล่ข้างปุ่ม 📜
qBtn7.onclick=()=>{qOpen7=!qOpen7;clearTimeout(qT7);if(qOpen7)qT7=setTimeout(()=>{qOpen7=false;qSync7()},6000);sfx('ui');qSync7()};
new MutationObserver(qSync7).observe(qtEl,{attributes:true,attributeFilter:['hidden','class']});qSync7();
