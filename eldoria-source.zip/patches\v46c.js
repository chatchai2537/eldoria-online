
// =====================================================================
// v4.6 (ค) : อัลติเมทสกิล (หลอดรอบกรอบรูป · ไฟลุกสั่นเมื่อพร้อม · ร่ายเวทก่อนโจมตี)
//            ท่าดื่มยา/กินอาหาร + เสียง · โรงเตี๊ยมสั่งอาหาร → สาวเสิร์ฟยกมา → นั่งกิน
// =====================================================================
{const st=document.createElement('style');st.textContent=`
#ult6{position:absolute;pointer-events:none;border-radius:13px;z-index:1}
#ult6 .rg{position:absolute;inset:0;border-radius:13px;padding:3px;background:conic-gradient(from -90deg,var(--uc) calc(var(--u)*1%),rgba(255,255,255,.1) 0);-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask-composite:exclude}
#ult6.rdy .rg{background:linear-gradient(0deg,#ff3a00,#ffb000,#fff2a0,#ffb000,#ff3a00);background-size:100% 300%;animation:ufl .6s linear infinite}
#ult6 .fl{position:absolute;left:-6px;right:-6px;top:-14px;bottom:-4px;display:none;pointer-events:none;background:radial-gradient(ellipse at 20% 100%,rgba(255,120,0,.9),transparent 45%),radial-gradient(ellipse at 50% 100%,rgba(255,200,40,.85),transparent 50%),radial-gradient(ellipse at 80% 100%,rgba(255,80,0,.9),transparent 45%);filter:blur(2px);mix-blend-mode:screen;animation:ufire .25s steps(2) infinite;-webkit-mask:linear-gradient(0deg,#000 30%,transparent)}
#ult6.rdy .fl{display:block}
#ult6.rdy{animation:ushk .18s linear infinite}
@keyframes ufl{to{background-position:0 300%}}@keyframes ufire{0%{transform:scaleY(1) translateY(0)}50%{transform:scaleY(1.15) translateY(-2px)}}
@keyframes ushk{0%{transform:translate(0,0)}25%{transform:translate(.8px,-.6px)}50%{transform:translate(-.7px,.5px)}75%{transform:translate(.5px,.7px)}}
#ultb{position:absolute;z-index:6;right:calc(178px + var(--sr,0px));bottom:calc(64px + var(--sb,0px));width:58px;height:58px;border-radius:50%;border:2px solid #fff2a0;background-size:cover;background-position:center;cursor:pointer;box-shadow:0 0 0 3px rgba(255,120,0,.6),0 0 18px #ff8a1a,0 0 36px rgba(255,80,0,.6);animation:ubtn 1s ease-in-out infinite;padding:0}
#ultb[hidden]{display:none}#ultb b{position:absolute;left:50%;bottom:-13px;transform:translateX(-50%);font:900 9px system-ui;color:#fff2a0;background:#8a1a04;border-radius:6px;padding:0 5px;white-space:nowrap}
@keyframes ubtn{50%{box-shadow:0 0 0 6px rgba(255,160,0,.35),0 0 26px #ffb020,0 0 50px rgba(255,80,0,.7);transform:scale(1.06)}}
#ultov{position:absolute;inset:0;z-index:7;pointer-events:none;opacity:0;transition:opacity .25s}
#ultov.on{opacity:1}#ultov::before,#ultov::after{content:"";position:absolute;left:0;right:0;height:11%;background:#000;transition:transform .35s}
#ultov::before{top:0;transform:translateY(-100%)}#ultov::after{bottom:0;transform:translateY(100%)}#ultov.on::before,#ultov.on::after{transform:none}
#ultov .vg{position:absolute;inset:0;background:radial-gradient(ellipse at 50% 55%,transparent 30%,rgba(0,0,0,.6))}
#ultov .nm{position:absolute;left:5%;top:16%;font:900 clamp(18px,5.5vh,34px) system-ui,"Noto Sans Thai";color:#fff;letter-spacing:1px;text-shadow:0 0 12px var(--uc),0 2px 0 #000;transform:skewX(-12deg) translateX(-30px);opacity:0;transition:all .4s}
#ultov .nm small{display:block;font-size:.42em;color:var(--uc);letter-spacing:3px}
#ultov.on .nm{opacity:1;transform:skewX(-12deg)}
`;document.head.appendChild(st)}
const ULT={v:0,cast:null,fx:[]};
const ULTD={none:{n:'แสงอรุณศักดิ์สิทธิ์',en:'DAWN BURST',c:'#ffe9a0',rgb:'255,230,150'},sword:{n:'พันดาบเทพพิโรธ',en:'THOUSAND HEAVEN BLADES',c:'#9fd8ff',rgb:'160,215,255'},mage:{n:'อุกกาบาตวันสิ้นโลก',en:'APOCALYPSE METEOR',c:'#ff8a3a',rgb:'255,140,60'},archer:{n:'ธนูเหยี่ยวเพลิงสวรรค์',en:'PHOENIX ARROW',c:'#ffd23a',rgb:'255,210,80'}};
const ultK=()=>ULTD[P.cls]?P.cls:'none';
// ไอคอนอัลติเมท
SKART['ULT_sword']=(q,S)=>{skBg(q,S,'#2a4a8a','#02040c','#ffe9a0');sglow(q,48,30,40,'160,215,255',.7);for(let i=0;i<7;i++)skSword(q,14+i*11,22+(i%2)*10,Math.PI,30,'#e8f4ff','#9fd8ff');skSword(q,48,90,0,70,'#ffffff','#ffd23a')};
SKART['ULT_mage']=(q,S)=>{skBg(q,S,'#8a2a0a','#0a0202','#ffe9a0');q.strokeStyle='rgba(255,170,80,.6)';q.lineWidth=16;q.beginPath();q.moveTo(-10,-10);q.lineTo(52,52);q.stroke();sglow(q,58,58,40,'255,150,40');q.fillStyle='#3a1a0a';q.beginPath();q.arc(58,58,18,0,7);q.fill();q.fillStyle='#ff9a3a';q.beginPath();q.arc(62,62,9,0,7);q.fill();q.fillStyle='#fff6c0';q.beginPath();q.arc(64,64,4,0,7);q.fill()};
SKART['ULT_archer']=(q,S)=>{skBg(q,S,'#8a5a0a','#0a0602','#ffe9a0');sglow(q,48,48,44,'255,200,60',.7);q.fillStyle='#ff7a1a';q.beginPath();q.moveTo(48,52);q.bezierCurveTo(28,30,10,34,4,46);q.bezierCurveTo(20,46,30,54,40,62);q.lineTo(48,72);q.lineTo(56,62);q.bezierCurveTo(66,54,76,46,92,46);q.bezierCurveTo(86,34,68,30,48,52);q.fill();skArrow(q,48,48,-Math.PI/4,70,'#fff6c0','#ffd23a')};
SKART['ULT_none']=(q,S)=>{skBg(q,S,'#8a7a2a','#0a0802','#ffe9a0');sglow(q,48,48,46,'255,240,170');for(let i=0;i<12;i++){const a=i*.5236;q.strokeStyle='rgba(255,250,210,.8)';q.lineWidth=3;q.beginPath();q.moveTo(48+Math.cos(a)*12,48+Math.sin(a)*12);q.lineTo(48+Math.cos(a)*44,48+Math.sin(a)*44);q.stroke()}q.fillStyle='#fffbe0';q.beginPath();q.arc(48,48,11,0,7);q.fill()};
// วงหลอดรอบรูป
const ult6=document.createElement('div');ult6.id='ult6';ult6.innerHTML='<div class="fl"></div><div class="rg"></div>';gid('hud').appendChild(ult6);
function placeUlt6(){const f=gid('face'),h=gid('hud');if(!f||!h)return;ult6.style.left=(f.offsetLeft-3)+'px';ult6.style.top=(f.offsetTop-3)+'px';ult6.style.width=(f.offsetWidth+6)+'px';ult6.style.height=(f.offsetHeight+6)+'px'}
addEventListener('resize',placeUlt6);setTimeout(placeUlt6,500);
const ultB=document.createElement('button');ultB.id='ultb';ultB.hidden=true;gid('wrap').appendChild(ultB);ultB.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();castUlt()});
let ultWasRdy=false;
setInterval(()=>{const d=ULTD[ultK()],rdy=ULT.v>=100;ult6.style.setProperty('--u',Math.min(100,ULT.v).toFixed(1));ult6.style.setProperty('--uc',d.c);ult6.classList.toggle('rdy',rdy);
 const inTown=D&&(D.town||D.shop||D.home);ultB.hidden=!rdy||inTown||!!ULT.cast||P.dead;if(rdy){const u=skillIcon('ULT_'+ultK());const bg='url('+u+')';if(ultB._bg!==bg){ultB._bg=bg;ultB.style.backgroundImage=bg;ultB.innerHTML='<b>อัลติเมท</b>'}}
 if(rdy&&!ultWasRdy){sfx('gem');tone(440,880,.5,'sawtooth',.03);tone(660,1320,.6,'triangle',.04,.1);sysSay('🔥 อัลติเมทพร้อมแล้ว! — '+d.n+(COARSE?'':' (กด U)'))}ultWasRdy=rdy;if(!ult6.style.width)placeUlt6()},150);
const ultGain=v=>{if(ULT.cast)return;ULT.v=Math.min(100,ULT.v+v)};
{const _h=hurtE;hurtE=function(e,mult,o){const r=_h(e,mult,o);if(r&&!(o&&o.ult))ultGain(e&&e.boss?1.6:.9);return r}}
{const _mk=mobKill;mobKill=function(m){_mk(m);ultGain(m.boss?25:m.elite?6:2.2)}}
{const _dl=dropLoot;dropLoot=function(x,y,s){_dl(x,y,s);if(s)ultGain(2)}}
{const _z=zHurt;zHurt=function(src,d,k,m){const h0=P.hp;_z(src,d,k,m);if(P.hp<h0)ultGain(1.5)}}
addEventListener('keydown',e=>{if((e.key==='u'||e.key==='U')&&document.activeElement.tagName!=='INPUT')castUlt()});
const ultOv=document.createElement('div');ultOv.id='ultov';ultOv.innerHTML='<div class="vg"></div><div class="nm"></div>';gid('wrap').appendChild(ultOv);
function chant(k){const C=AU.c;if(!C||SET.mute)return;const base={sword:55,mage:50,archer:57,none:60}[k]||55;
 for(const [iv,dl] of [[0,0],[7,.05],[12,.1],[16,.3],[19,.5],[24,.75]]){const f=440*Math.pow(2,(base+iv-69)/12);tone(f,f*1.02,1.4-dl,'sawtooth',.018,dl);tone(f*1.005,f*1.03,1.4-dl,'sine',.04,dl)}
 nz(1.2,.06,300,3000,2,'bandpass',0);for(let i=0;i<5;i++)tone(1800+i*300,2600,.25,'sine',.02,.2+i*.18)}
function boom(v){nz(.9,.5*(v||1),900,40,1,'lowpass');tone(80,30,.9,'sine',.4*(v||1));tone(140,40,.5,'square',.08*(v||1))}
function castUlt(){if(ULT.v<100||ULT.cast||P.dead||PAUSED)return;if(D&&(D.town||D.shop||D.home)){say('ใช้อัลติเมทในเมือง/ที่ดินไม่ได้');return}
 if(typeof MOUNT!=='undefined'&&MOUNT.on){MOUNT.on=false;try{mountB.classList.remove('on')}catch(e){}}
 const k=ultK(),d=ULTD[k];ULT.v=0;ULT.cast={k,t:0,ph:0,dir:P.dir};P.iframe=Math.max(P.iframe,2.6);P.stun=Math.max(P.stun,1.15);P.draw=true;
 ultOv.style.setProperty('--uc',d.c);ultOv.querySelector('.nm').innerHTML='<small>ULTIMATE · '+d.en+'</small>'+d.n;ultOv.classList.add('on');chant(k);shake(1.5,1.1)}
window.castUlt=castUlt;
function foeNear(r){let best=null,bd=r;for(const e of enemies()){const dd=Math.hypot(e.x-P.x,e.y-P.y);if(dd<bd){bd=dd;best=e}}return best}
function ultTick(dt){const U=ULT.cast;if(U){U.t+=dt;const k=U.k,d=ULTD[k];
  if(U.t<1.1){if(Math.random()<.7){const a=Math.random()*6.28,r=40+Math.random()*30;rfxP(P.x+Math.cos(a)*r,P.y+Math.sin(a)*r*.4,-Math.cos(a)*40,-60-Math.random()*60,.7,d.rgb,2.4,'spark')}}
  else if(!U.fired){U.fired=1;ultOv.classList.remove('on');ultFire(k)}
  if(U.t>1.3)ULT.cast=null}
 for(let i=ULT.fx.length-1;i>=0;i--){const f=ULT.fx[i];f.t+=dt;if(f.dl>0){f.dl-=dt;f.t=0;continue}if(f.tick)f.tick(f,dt);if(f.t>=f.l)ULT.fx.splice(i,1)}}
{const _pt=playerTick;playerTick=function(dt){_pt(dt);ultTick(dt);animTick(dt);innTick(dt)}}
function ultFire(k){const d=ULTD[k],v=DIRV[ULT.cast.dir]||[1,0];
 if(k==='sword'){const pts=[];const foes=enemies().filter(e=>Math.hypot(e.x-P.x,e.y-P.y)<260);for(let i=0;i<14;i++){const e=foes[i%Math.max(1,foes.length)];const x=e?e.x+(Math.random()-.5)*30:P.x+(Math.random()-.5)*360,y=e?e.y+(Math.random()-.5)*20:P.y+(Math.random()-.5)*220;pts.push([x,y])}
  pts.forEach(([x,y],i)=>ULT.fx.push({k:'fsword',x,y,t:0,l:.55,dl:i*.07,s:1,tick:(f)=>{if(!f.hit&&f.t>.28){f.hit=1;eachIn(f.x,f.y,58,e=>hurtE(e,2.4,{kb:200,ult:1,col:'#cfe9ff'}));shake(2.5,.12);nz(.25,.25,3000,600,2);tone(1200,300,.2,'square',.04);for(let j=0;j<10;j++)rfxP(f.x,f.y,(Math.random()-.5)*160,-40-Math.random()*90,.5,d.rgb,2.4,'spark');RFX.push({k:'ring',x:f.x,y:f.y,t:0,l:.4,rgb:d.rgb,s:50})}}}));
  const gx=P.x+v[0]*90,gy=P.y+v[1]*70;ULT.fx.push({k:'fsword',x:gx,y:gy,t:0,l:.9,dl:1.1,s:3.2,tick:(f)=>{if(!f.hit&&f.t>.4){f.hit=1;eachIn(f.x,f.y,210,e=>hurtE(e,7,{kb:420,stun:1.2,ult:1,col:'#ffffff'}));shake(9,.6);boom(1.2);RFX.push({k:'ring',x:f.x,y:f.y,t:0,l:.7,rgb:'255,255,255',s:220});RFX.push({k:'ring',x:f.x,y:f.y,t:0,l:.9,rgb:d.rgb,s:300});for(let j=0;j<60;j++){const a=Math.random()*6.28;rfxP(f.x,f.y,Math.cos(a)*260,Math.sin(a)*150-60,.8,j%2?d.rgb:'255,255,255',3,'spark')}}}})}
 else if(k==='mage'){const e=foeNear(320),tx=e?e.x:P.x+v[0]*140,ty=e?e.y:P.y+v[1]*100;ULT.fx.push({k:'meteor',x:tx,y:ty,t:0,l:1.6,tick:(f)=>{if(f.t<.9&&Math.random()<.9)rfxP(f.x+260*(1-f.t/.9),f.y-360*(1-f.t/.9),40,-20,.5,'255,150,40',4,'spark');
   if(!f.hit&&f.t>=.9){f.hit=1;eachIn(f.x,f.y,240,q=>hurtE(q,9,{kb:500,stun:1.4,ult:1,burn:4,col:'#ffb070'}));shake(12,.8);boom(1.5);FADE.a=.6;FADE.c='#fff4d0';for(let i=1;i<4;i++)RFX.push({k:'ring',x:f.x,y:f.y,t:0,l:.5+i*.2,rgb:i%2?'255,200,80':'255,90,20',s:90*i});for(let j=0;j<90;j++){const a=Math.random()*6.28,s=60+Math.random()*320;rfxP(f.x,f.y,Math.cos(a)*s,Math.sin(a)*s*.55-80,1,j%3?'255,140,40':'255,240,180',3.4,'spark')}}}})}
 else if(k==='archer'){const dx=v[0]||0,dy=v[1]||0;ULT.fx.push({k:'phoenix',x:P.x,y:P.y-20,dx,dy,t:0,l:1.1,hit:new Set(),tick:(f)=>{const s=900*Math.min(f.t,.8);const cx=P.x+f.dx*s,cy=P.y-20+f.dy*s;f.cx=cx;f.cy=cy;if(f.t<.8){eachIn(cx,cy+16,56,e=>{if(f.hit.has(e))return;f.hit.add(e);hurtE(e,6,{kb:300,ult:1,col:'#ffe08a',burn:2});RFX.push({k:'ring',x:e.x,y:e.y,t:0,l:.4,rgb:'255,180,60',s:60});nz(.3,.2,1200,200,1)});for(let j=0;j<4;j++)rfxP(cx-f.dx*20+(Math.random()-.5)*20,cy-f.dy*20+(Math.random()-.5)*20,-f.dx*60+(Math.random()-.5)*40,-f.dy*60-20,.6,j%2?'255,120,30':'255,220,100',3,'spark')}}});shake(5,.5);tone(300,1200,.6,'sawtooth',.06);nz(.8,.2,600,4000,1,'bandpass')}
 else{eachIn(P.x,P.y,200,e=>hurtE(e,5,{kb:380,stun:1,ult:1,col:'#fff6c0'}));shake(7,.5);boom(1);FADE.a=.5;FADE.c='#fffbe0';for(let i=1;i<4;i++)RFX.push({k:'ring',x:P.x,y:P.y,t:0,l:.4+i*.2,rgb:'255,240,170',s:80*i})}}
function drawUltWorld(under){const t=performance.now()/1000,U=ULT.cast;
 if(under&&U&&U.t<1.25){const d=ULTD[U.k],a=Math.min(1,U.t*3)*(U.t>1.1?Math.max(0,1-(U.t-1.1)*7):1),r=58+Math.sin(t*6)*2;ctx.save();ctx.globalAlpha=a;ctx.translate(P.x,P.y);ctx.scale(1,.42);ctx.globalCompositeOperation='lighter';
  const g=ctx.createRadialGradient(0,0,r*.2,0,0,r*1.2);g.addColorStop(0,'rgba('+d.rgb+',.45)');g.addColorStop(1,'rgba('+d.rgb+',0)');ctx.fillStyle=g;ctx.fillRect(-r*1.3,-r*1.3,r*2.6,r*2.6);
  ctx.strokeStyle='rgba('+d.rgb+',.95)';ctx.lineWidth=3;for(const [rr,sp] of [[r,1],[r*.72,-1.6],[r*.42,2.4]]){ctx.save();ctx.rotate(t*sp);ctx.beginPath();ctx.arc(0,0,rr,0,7);ctx.stroke();for(let i=0;i<(rr>40?12:6);i++){const aa=i*Math.PI*2/(rr>40?12:6);ctx.fillStyle='rgba(255,255,255,.9)';ctx.fillRect(Math.cos(aa)*rr-2,Math.sin(aa)*rr-2,4,4)}ctx.restore()}
  ctx.save();ctx.rotate(-t*.8);ctx.beginPath();for(let i=0;i<=6;i++){const aa=i*Math.PI*2/6*2;ctx.lineTo(Math.cos(aa)*r*.72,Math.sin(aa)*r*.72)}ctx.stroke();ctx.restore();ctx.restore();
  ctx.save();ctx.globalCompositeOperation='lighter';ctx.globalAlpha=a*.6;const pg=ctx.createLinearGradient(0,P.y-160,0,P.y);pg.addColorStop(0,'rgba('+d.rgb+',0)');pg.addColorStop(1,'rgba('+d.rgb+',.55)');ctx.fillStyle=pg;ctx.fillRect(P.x-26,P.y-160,52,160);ctx.restore()}
 if(under)return;
 for(const f of ULT.fx){if(f.dl>0)continue;const u=f.t/f.l;ctx.save();
  if(f.k==='fsword'){const fall=Math.min(1,f.t/(f.s>1?.4:.28)),y=f.y-(1-fall)*(f.s>1?420:260),al=u>.75?(1-u)*4:1;ctx.globalAlpha=al;ctx.globalCompositeOperation='lighter';const g=ctx.createRadialGradient(f.x,y-20*f.s,0,f.x,y-20*f.s,40*f.s);g.addColorStop(0,'rgba(160,215,255,.6)');g.addColorStop(1,'rgba(160,215,255,0)');ctx.fillStyle=g;ctx.fillRect(f.x-40*f.s,y-60*f.s,80*f.s,80*f.s);ctx.globalCompositeOperation='source-over';
   ctx.translate(f.x,y);ctx.scale(f.s,f.s);const bg=ctx.createLinearGradient(-4,0,4,0);bg.addColorStop(0,'rgba(140,190,255,.85)');bg.addColorStop(.5,'rgba(255,255,255,.95)');bg.addColorStop(1,'rgba(120,170,240,.85)');ctx.fillStyle=bg;ctx.beginPath();ctx.moveTo(-4,-50);ctx.lineTo(4,-50);ctx.lineTo(4,-6);ctx.lineTo(0,4);ctx.lineTo(-4,-6);ctx.closePath();ctx.fill();ctx.fillStyle='rgba(255,230,140,.95)';ctx.fillRect(-11,-54,22,4);ctx.fillStyle='rgba(200,230,255,.9)';ctx.fillRect(-2,-66,4,12)}
  else if(f.k==='meteor'){if(f.t<.9){const p=f.t/.9,mx=f.x+260*(1-p),my=f.y-360*(1-p),sz=18+p*22;ctx.globalCompositeOperation='lighter';const tg=ctx.createLinearGradient(mx,my,mx+160,my-220);tg.addColorStop(0,'rgba(255,200,80,.9)');tg.addColorStop(1,'rgba(255,60,0,0)');ctx.strokeStyle=tg;ctx.lineWidth=sz*1.4;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(mx,my);ctx.lineTo(mx+160,my-220);ctx.stroke();
    const g=ctx.createRadialGradient(mx,my,0,mx,my,sz*2);g.addColorStop(0,'rgba(255,250,210,1)');g.addColorStop(.4,'rgba(255,140,40,.9)');g.addColorStop(1,'rgba(255,60,0,0)');ctx.fillStyle=g;ctx.fillRect(mx-sz*2,my-sz*2,sz*4,sz*4);ctx.globalCompositeOperation='source-over';ctx.fillStyle='#4a1a08';ctx.beginPath();ctx.arc(mx,my,sz*.6,0,7);ctx.fill();
    ctx.globalAlpha=.35*p;ctx.fillStyle='#000';ctx.beginPath();ctx.ellipse(f.x,f.y,240*p,90*p,0,0,7);ctx.fill();ctx.globalAlpha=1;ctx.strokeStyle='rgba(255,90,40,'+(.5+.4*Math.sin(f.t*30))+')';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(f.x,f.y,240,90,0,0,7);ctx.stroke()}
   else{const p=(f.t-.9)/.7,al=Math.max(0,1-p);ctx.globalCompositeOperation='lighter';const g=ctx.createRadialGradient(f.x,f.y-30,0,f.x,f.y-30,260*(.5+p));g.addColorStop(0,'rgba(255,240,200,'+al+')');g.addColorStop(.4,'rgba(255,120,30,'+al*.8+')');g.addColorStop(1,'rgba(200,30,0,0)');ctx.fillStyle=g;ctx.fillRect(f.x-400,f.y-400,800,800)}}
  else if(f.k==='phoenix'&&f.cx!=null&&f.t<.85){const a=Math.atan2(f.dy,f.dx||1e-6),fl=Math.sin(f.t*40);ctx.translate(f.cx,f.cy);ctx.rotate(a);ctx.globalCompositeOperation='lighter';const g=ctx.createRadialGradient(0,0,0,0,0,70);g.addColorStop(0,'rgba(255,250,200,.95)');g.addColorStop(.35,'rgba(255,150,40,.8)');g.addColorStop(1,'rgba(255,60,0,0)');ctx.fillStyle=g;ctx.fillRect(-70,-70,140,140);
   ctx.fillStyle='rgba(255,180,60,.9)';for(const s of [-1,1]){ctx.beginPath();ctx.moveTo(10,0);ctx.bezierCurveTo(-10,s*(30+fl*8),-40,s*(46+fl*10),-62,s*(30+fl*6));ctx.bezierCurveTo(-40,s*18,-24,s*8,-10,0);ctx.fill()}ctx.fillStyle='rgba(255,90,20,.8)';ctx.beginPath();ctx.moveTo(-10,0);ctx.lineTo(-90,-12);ctx.lineTo(-80,0);ctx.lineTo(-90,12);ctx.closePath();ctx.fill();ctx.fillStyle='#fff6c0';ctx.beginPath();ctx.moveTo(30,0);ctx.lineTo(4,-6);ctx.lineTo(4,6);ctx.closePath();ctx.fill()}
  ctx.restore()}}
{const _h=hero;hero=function(){drawUltWorld(true);_h();drawUltWorld(false);drawAnim6();drawInn6()}}

// =====================================================================
// ท่าดื่มยา / กินอาหาร
// =====================================================================
const ANIM6={k:null,t:0,l:0};
function gulp(){if(!AU.c||SET.mute)return;for(let i=0;i<3;i++){tone(180-i*15,90,.12,'sine',.12,i*.2);nz(.08,.05,900,300,4,'bandpass',i*.2+.04)}tone(700,1400,.18,'sine',.03,.65)}
function munch(){if(!AU.c||SET.mute)return;for(let i=0;i<3;i++){nz(.09,.12,1800,500,1.5,'bandpass',i*.22);nz(.05,.06,4000,2000,2,'highpass',i*.22+.03)}}
{const _ui=useItem;useItem=function(k){const n0=inv[k]|0;const r=_ui(k);if((inv[k]|0)<n0){const pot=k==='hpp'||k==='mpp';ANIM6.k=pot?'drink':'eat';ANIM6.t=0;ANIM6.l=pot?.9:1.1;ANIM6.item=k;ANIM6.col=k==='hpp'?'#e8303a':k==='mpp'?'#3a7aff':null;ANIM6.e=FOOD&&FOOD[k]?FOOD[k].e:(k==='bread'?'🍞':k==='apple'?'🍎':'🍖');if(pot)gulp();else munch()}return r}}
function animTick(dt){if(ANIM6.k){ANIM6.t+=dt;if(ANIM6.t>=ANIM6.l)ANIM6.k=null}}
function drawAnim6(){if(!ANIM6.k||P.dead||(MOUNT&&MOUNT.on))return;const u=ANIM6.t/ANIM6.l,d=P.dir;if(d==='u')return;const side=d==='l'||d==='r',f=d==='l'?-1:1,EC=EQCOL(),mx=P.x+(side?f*4:0),my=P.y-36+(P.sit?3:0);
 const lift=u<.2?u/.2:u>.85?(1-u)/.15:1,sx=P.x+(side?f*2:6),sy=P.y-25+(P.sit?3:0),hx=sx+(mx+(side?f*5:3)-sx)*lift,hy=sy+(my+3-sy)*lift;
 ctx.save();ctx.lineCap='round';ctx.strokeStyle=EC.TOP;ctx.lineWidth=6;ctx.beginPath();ctx.moveTo(sx,sy);ctx.lineTo(hx,hy+3);ctx.stroke();ctx.fillStyle='#f1d2b0';ctx.fillRect(hx-3,hy,6,5);
 if(ANIM6.k==='drink'){const tilt=lift*(side?f*1.6:1.2)*(u>.3&&u<.8?1.1:1);ctx.translate(hx,hy);ctx.rotate(-tilt*(side?1:.0)+(side?0:-.3*lift));ctx.fillStyle='rgba(220,240,255,.85)';ctx.strokeStyle='#2a2a3a';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(-3,-12);ctx.lineTo(3,-12);ctx.lineTo(3,-8);ctx.lineTo(5,-5);ctx.lineTo(5,3);ctx.lineTo(-5,3);ctx.lineTo(-5,-5);ctx.lineTo(-3,-8);ctx.closePath();ctx.fill();ctx.stroke();
  const lv=Math.max(0,1-u*1.1);ctx.fillStyle=ANIM6.col;ctx.fillRect(-4.4,3-7*lv,8.8,7*lv);ctx.fillStyle='#8a5a2a';ctx.fillRect(-2.5,-14,5,3);
  if(u>.3&&u<.8&&Math.random()<.4)rfxP(mx,my,(Math.random()-.5)*10,-20,.4,ANIM6.item==='hpp'?'255,120,120':'140,180,255',1.6,'dot')}
 else{ctx.font='12px "Noto Color Emoji","Apple Color Emoji",sans-serif';ctx.textAlign='center';ctx.fillText(ANIM6.e,hx,hy+2);if(lift>.9&&Math.random()<.3)rfxP(mx,my+2,(Math.random()-.5)*30,10,.4,'230,200,150',1.5,'dot')}
 ctx.restore()}

// =====================================================================
// โรงเตี๊ยม: สั่งอาหาร → เดินไปนั่ง → สาวเสิร์ฟยกมา → นั่งกิน
// =====================================================================
const INNMENU=[{id:'stew',n:'สตูว์เนื้อหม้อดิน',e:'🍲',p:45,hu:70,hpP:.5,st:{str:3,vit:3},dur:600,d:'อิ่ม +70 · เลือด +50% · STR/VIT +3 (10 นาที)'},
 {id:'fishp',n:'ปลาย่างสมุนไพรจานใหญ่',e:'🐟',p:40,hu:55,mpP:.6,st:{int:4,agi:2},dur:600,d:'อิ่ม +55 · มานา +60% · INT +4 AGI +2 (10 นาที)'},
 {id:'feastp',n:'ชุดเลี้ยงผู้กล้า (ไก่อบ+ขนมปัง+เบียร์ผึ้ง)',e:'🍗',p:90,hu:100,hpP:1,mpP:1,fa:100,st:{str:4,vit:4,agi:3,end:4,int:3},dur:900,d:'อิ่มเต็ม · ฟื้นทุกอย่าง · ทุกค่า +3~4 (15 นาที)'}];
const INN6={st:null};
const TABLES=SEATS.map(s=>{const pair=SEATS.find(q=>q!==s&&Math.abs(q[1]-s[1])<4&&Math.abs(q[0]-s[0])<110);return pair?{x:(s[0]+pair[0])/2,y:s[1]-10}:{x:s[0]+40,y:s[1]-10}});
{const _ot=ownerTalk;ownerTalk=function(id){const r=_ot(id);if(id==='inn'&&DLG.open&&!INN6.st){DLG.ch.splice(0,0,{t:'🍲 สั่งอาหารมานั่งกิน',c:'go',f:innOrder});try{dlgShowChoices()}catch(e){}}return r}}
function innOrder(){const o=D.owner;talk(o,'วันนี้มีของอร่อยหลายอย่างเลย เลือกได้ตามสบาย นั่งรอที่โต๊ะเดี๋ยวเสิร์ฟให้!',INNMENU.map(m=>({t:m.e+' '+m.n+' — '+m.p+' 🪙',f:()=>innPick(m)})).concat([BYE]),'🍲 เมนูโรงเตี๊ยม')}
function innPick(m){if(inv.coin<m.p){say('เหรียญไม่พอ');sfx('thud');return}inv.coin-=m.p;refreshInv();sfx('coin');
 let bi=0,bd=1e9;SEATS.forEach((s,i)=>{const d=Math.hypot(s[0]-P.x,s[1]-P.y);if(d<bd){bd=d;bi=i}});const seat=SEATS[bi],tb=TABLES[bi];
 INN6.st='walk';INN6.m=m;INN6.seat=seat;INN6.tb=tb;INN6.t=0;P.sit=null;say('🍽️ สั่ง'+m.n+'แล้ว — เดินไปนั่งที่โต๊ะ…');
 const o=D.owner;INN6.w=mkNPC({name:'น้องเมย์ (สาวเสิร์ฟ)',c:'#3a6a9a',h:'#6a3a1a',x:0,y:0,g:'f',age:'adult',hs:'bun',apron:1,lines:[]});INN6.w.x=o.x+30;INN6.w.y=o.y+46;INN6.w.home={x:INN6.w.x,y:INN6.w.y};INN6.w.vis=false}
function innTick(dt){const S=INN6;if(!S.st)return;if(!D||D.shop!=='inn'){S.st=null;return}S.t+=dt;const w=S.w;
 if(S.st==='walk'){const tx=S.seat[0],ty=S.seat[1]+4,dx=tx-P.x,dy=ty-P.y,d=Math.hypot(dx,dy);if(d<4||S.t>4){P.x=tx;P.y=ty;P.sit=S.seat;P.dir=S.tb.x>tx?'r':'l';S.st='wait';S.t=0;w.vis=true;sfx('ui')}else{const sp=Math.min(d,110*dt);P.x+=dx/d*sp;P.y+=dy/d*sp;P.mv=true;P.t+=dt*8;P.dir=Math.abs(dx)>Math.abs(dy)?(dx<0?'l':'r'):(dy<0?'u':'d')}}
 else if(S.st==='wait'||S.st==='back'){// เดินผ่านทางเดินระหว่างโต๊ะ (ไม่เหยียบโต๊ะ): ลงทางเดิน → เลียบทางเดิน → เข้าหาหน้าโต๊ะ
  const fin=S.st==='wait'?{x:S.tb.x+(S.tb.x>S.seat[0]?10:-10),y:S.tb.y+28}:w.home,AY=S.tb.y+50;
  if(!S.wp||S.wpFor!==S.st){S.wpFor=S.st;S.wp=S.st==='wait'?[{x:w.x,y:AY},{x:fin.x,y:AY},fin]:[{x:w.x,y:AY},{x:fin.x,y:AY},fin]}
  let tgt=S.wp[0],dx=tgt.x-w.x,dy=tgt.y-w.y,d=Math.hypot(dx,dy);
  while(d<3&&S.wp.length>1){S.wp.shift();tgt=S.wp[0];dx=tgt.x-w.x;dy=tgt.y-w.y;d=Math.hypot(dx,dy)}
  if(d<3){S.wp=null;if(S.st==='wait'){S.st='serve';S.t=0;w.mv=false;w.dir='u';sfx('pop');tone(520,0,.08,'triangle',.05);w.bub={txt:'ได้แล้วค่ะ! ทานให้อร่อยนะคะ ♪',t:2.2};S.plate=1}else{S.st=S.st==='back'?'eat':S.st;w.vis=false;w.mv=false}}
  else{const sp=Math.min(d,90*dt);w.x+=dx/d*sp;w.y+=dy/d*sp;w.mv=true;w.t+=dt*7;w.dir=Math.abs(dx)>Math.abs(dy)?(dx<0?'l':'r'):(dy<0?'u':'d')}
  if(S.st==='wait'||S.st==='back')P.sit=S.seat}
 else if(S.st==='serve'){if(S.t>.6){S.st='back2';S.t=0;S.eatT=0;S.wp2=null}}
 if(S.st==='back2'){S.eatT+=dt;if(!S.wp2){const AY=S.tb.y+50;S.wp2=[{x:w.x,y:AY},{x:w.home.x,y:AY},{x:w.home.x,y:w.home.y}]}while(S.wp2.length>1&&Math.hypot(S.wp2[0].x-w.x,S.wp2[0].y-w.y)<3)S.wp2.shift();const tg2=S.wp2[0],dx=tg2.x-w.x,dy=tg2.y-w.y,d=Math.hypot(dx,dy);if(d>3||S.wp2.length>1){const sp=Math.min(d,90*dt);w.x+=dx/d*sp;w.y+=dy/d*sp;w.mv=true;w.t+=dt*7;w.dir=Math.abs(dx)>Math.abs(dy)?(dx<0?'l':'r'):(dy<0?'u':'d')}else{w.vis=false;w.mv=false}
  if(!P.sit){S.st=null;say('ลุกจากโต๊ะก่อนกินเสร็จ — อาหารที่เหลือเก็บไว้ไม่ได้นะ');return}
  if(Math.floor(S.eatT/.55)!==Math.floor((S.eatT-dt)/.55)){munch();ANIM6.k='eat';ANIM6.t=0;ANIM6.l=.5;ANIM6.e=S.m.e}
  if(S.eatT>=4.2){const m=S.m;P.hu=Math.min(100,(P.hu|0)+m.hu);if(m.hpP)P.hp=Math.min(BAL.hp,P.hp+Math.round(BAL.hp*m.hpP));if(m.mpP)P.mp=Math.min(BAL.mp,P.mp+Math.round(BAL.mp*m.mpP));if(m.fa)P.fa=100;addBuff('inn_'+m.id,{n:m.n,e:m.e,st:m.st,dur:m.dur});applyBonus();
   sfx('chest');tone(660,990,.3,'triangle',.05);say(m.e+' อิ่มอร่อย! '+m.d);S.st=null;S.plate=0}}}
function drawInn6(){const S=INN6;if(!S.st||!D||D.shop!=='inn')return;const t=performance.now()/1000;
 if(S.plate||S.st==='back2'){const px=S.tb.x+(S.tb.x>S.seat[0]?-12:12),py=S.tb.y-6,left=S.st==='back2'?Math.max(0,1-S.eatT/4.2):1;ctx.save();ctx.fillStyle='#f4f0e8';ctx.strokeStyle='#8a7a6a';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(px,py,10,4,0,0,7);ctx.fill();ctx.stroke();
  if(left>0){ctx.font=(8+left*5)+'px "Noto Color Emoji","Apple Color Emoji",sans-serif';ctx.textAlign='center';ctx.fillText(S.m.e,px,py+1);ctx.strokeStyle='rgba(255,255,255,.5)';ctx.lineWidth=1;for(const o of [-4,0,4]){ctx.beginPath();ctx.moveTo(px+o,py-8);ctx.quadraticCurveTo(px+o+3*Math.sin(t*3+o),py-13,px+o,py-18-2*Math.sin(t*2+o));ctx.stroke()}}ctx.restore()}
 const w=S.w;if(w&&w.vis){try{drawNPC(w,t)}catch(e){}if(S.st==='wait'){ctx.save();const tx=w.x+(w.dir==='l'?-8:8),ty=w.y-30;ctx.fillStyle='#8a5a2a';ctx.fillRect(tx-10,ty,20,3);ctx.font='11px "Noto Color Emoji","Apple Color Emoji",sans-serif';ctx.textAlign='center';ctx.fillText(S.m.e,tx,ty-1);ctx.restore()}
  if(w.bub&&w.bub.t>0){w.bub.t-=1/60;ctx.save();ctx.font='bold 10px system-ui,"Noto Sans Thai",sans-serif';const tw=ctx.measureText(w.bub.txt).width+12;ctx.fillStyle='rgba(255,255,255,.95)';ctx.fillRect(w.x-tw/2,w.y-66,tw,16);ctx.fillStyle='#3a2a1a';ctx.textAlign='center';ctx.fillText(w.bub.txt,w.x,w.y-54);ctx.restore()}}}
{const _sa=shopAct;shopAct=function(){if(INN6.st&&INN6.st!=='back2')return true;return _sa()}}
