// =====================================================================
// events.js — EventSystem: เปิด/ปิดอีเวนต์ด้วยค่า true/false (config) หรือปุ่ม GM
// EXP/เหรียญ/ดรอป ×N · มอนพิเศษ · บอสตามฤดูกาล · ร้านอีเวนต์
// =====================================================================
const EventSystem=(()=>{const DB=GAME_DATABASE,LSK='fm_ev7';let ovr={};try{ovr=JSON.parse(localStorage.getItem(LSK)||'{}')||{}}catch(e){ovr={}}
 const isActive=id=>{const E=DB.event(id);if(!E)return false;return id in ovr?!!ovr[id]:!!E.active};
 const active=()=>DB.EventsData.filter(e=>isActive(e.eventId));
 const mult=k=>active().reduce((a,e)=>a*((e.multiplier&&e.multiplier[k])||1),1);
 function setActive(id,on){const E=DB.event(id);if(!E)return false;const was=isActive(id);ovr[id]=!!on;try{localStorage.setItem(LSK,JSON.stringify(ovr))}catch(e){}if(was!==!!on)EventBus.emit(on?EV.EVENT_STARTED:EV.EVENT_ENDED,{eventId:id,name:E.name,icon:E.icon});return true}
 function reset(id){delete ovr[id];try{localStorage.setItem(LSK,JSON.stringify(ovr))}catch(e){}}
 // ตัวคูณผ่าน Hooks (ระบบอื่นไม่ต้องรู้จักอีเวนต์)
 Hooks.add('xp',v=>v*mult('xp'),'events');Hooks.add('coin',v=>v*mult('coin'),'events');Hooks.add('dropChance',v=>v*mult('drop'),'events');
 // มอนพิเศษ + บอสตามฤดูกาล
 const lastBoss={};
 setInterval(()=>Guard.run('eventSpawns',()=>{if(!D||!D.zone||D.home||PAUSED||P.dead)return;const where=D.dg?'dungeon':'zone';
  for(const E of active()){for(const S of (E.specialSpawns||[])){if(!(S.where||['zone']).includes(where))continue;const alive=D.mobs.filter(m=>!m.dead&&m.mid===S.monsterId).length;if(alive<(S.max||1)&&Math.random()<(S.chancePerSec||.02))EventBus.emit('SPAWN_REQUEST',{monsterId:S.monsterId,event:E.eventId})}
   if(E.seasonalBossId&&where==='zone'){const alive=D.mobs.some(m=>!m.dead&&m.mid===E.seasonalBossId);const now=Date.now();if(!alive&&now-(lastBoss[E.eventId]||0)>(E.seasonalBossEverySec||300)*1000){lastBoss[E.eventId]=now;const M=DB.monster(E.seasonalBossId);
     EventBus.emit('SPAWN_REQUEST',{monsterId:E.seasonalBossId,event:E.eventId,r:180,announce:(E.icon||'⚠️')+' '+(M?M.name:'บอสอีเวนต์')+' ปรากฏตัวแล้ว!'})}}}}),1000);
 // แจ้งเมื่อมีอีเวนต์ตอนเริ่มเกม
 setTimeout(()=>{for(const E of active())EventBus.emit(EV.EVENT_STARTED,{eventId:E.eventId,name:E.name,icon:E.icon,boot:true})},2500);
 const api={isActive,active,setActive,reset,mult,list:()=>DB.EventsData.map(e=>({eventId:e.eventId,name:e.name,icon:e.icon,active:isActive(e.eventId)}))};
 Eldoria.register('events',api);return api})();
window.EventSystem=EventSystem;
