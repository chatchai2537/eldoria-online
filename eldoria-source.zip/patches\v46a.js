
// =====================================================================
// v4.6 (ก) : HUD ใหม่ (บัฟใต้หลอดเลือด · หิว/แรง · ชุดครบ) · แชทไม่บังจอย · ช่องลัดกลางจอ · แบนเนอร์ไม่บัง
//            สัตว์ขี่นั่งจริง + สัตว์ขี่ใหม่ · เครื่องมือ/เมล็ดวาดใหม่ · ไอคอนสกิลวาดใหม่
// =====================================================================
{const st=document.createElement('style');st.textContent=`
#buffs{display:none!important}
#wrap #hud{background:linear-gradient(180deg,rgba(18,14,26,.78),rgba(10,8,16,.72));border:1px solid rgba(232,193,74,.45);box-shadow:0 2px 10px rgba(0,0,0,.45);padding:5px 7px 5px 5px;border-radius:12px}
#wrap #face{border-radius:10px}
#vit6{display:flex;gap:5px;margin-top:1px}
#vit6 .v{flex:1;display:flex;align-items:center;gap:3px;font:800 9px system-ui;color:#fff}
#vit6 .v img{width:13px;height:13px;flex:none}
#vit6 .v div{flex:1;height:6px;border-radius:4px;background:rgba(255,255,255,.12);overflow:hidden;box-shadow:inset 0 1px 2px rgba(0,0,0,.6)}
#vit6 .v div i{display:block;height:100%;border-radius:4px;transition:width .4s}
#vit6 .hu i{background:linear-gradient(90deg,#ff8a3a,#ffc24a)}#vit6 .fa i{background:linear-gradient(90deg,#4fd06a,#c8f05a)}
#vit6 .v.low i{background:linear-gradient(90deg,#ff3a3a,#ff7a5a);animation:vlow .7s ease-in-out infinite alternate}
@keyframes vlow{from{opacity:1}to{opacity:.35}}
#bfrow{position:absolute;left:calc(6px + var(--sl,0px));top:calc(72px + var(--st,0px));display:flex;gap:4px;align-items:center;z-index:3;pointer-events:auto;max-width:44vw;flex-wrap:wrap}
#bfrow .b6{position:relative;width:26px;height:26px;border-radius:50%;padding:2px;background:conic-gradient(var(--c) calc(var(--p)*1%),rgba(255,255,255,.14) 0);box-shadow:0 1px 4px rgba(0,0,0,.5);cursor:pointer}
#bfrow .b6 img{width:22px;height:22px;border-radius:50%;display:block;background:#140f1c}
#bfrow .b6 em{position:absolute;right:-3px;bottom:-4px;font:800 8px system-ui;color:#fff;background:rgba(0,0,0,.75);border-radius:6px;padding:0 3px;font-style:normal}
#bfrow .b6.new{animation:b6in .5s ease-out}#bfrow .b6.end{animation:vlow .4s infinite alternate}
@keyframes b6in{from{transform:scale(2);opacity:0}to{transform:scale(1);opacity:1}}
#wrap #coinbox{position:static!important;display:inline-flex;align-items:center;gap:3px;background:linear-gradient(180deg,rgba(40,30,8,.85),rgba(20,14,4,.85));border:1px solid rgba(232,193,74,.6);color:#ffd84a;padding:1px 8px 1px 4px;border-radius:12px;font:800 11px system-ui;height:20px;box-sizing:border-box}
#set6{position:absolute;left:30px;top:30px;width:20px;height:22px;cursor:pointer;filter:drop-shadow(0 1px 2px #000);z-index:2}
#set6[hidden]{display:none}#set6 b{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font:900 9px system-ui;color:#fff;text-shadow:0 1px 1px #000;padding-top:1px}
#set6.full{animation:set6g 1.6s ease-in-out infinite}@keyframes set6g{50%{filter:drop-shadow(0 0 5px var(--sc)) drop-shadow(0 1px 2px #000)}}
#wrap #zb{position:absolute!important;top:calc(100px + var(--st,0px))!important;left:calc(6px + var(--sl,0px))!important;bottom:auto!important;right:auto!important;flex-direction:row!important;gap:5px;z-index:3}
#wrap #zb button{width:30px!important;height:30px!important;font-size:15px!important;border-radius:9px;background:rgba(10,8,16,.6);border:1px solid rgba(232,193,74,.55)}
#wrap #bar{left:50%!important;right:auto!important;transform:translateX(-50%)!important;bottom:calc(6px + var(--sb,0px))!important;z-index:5;gap:5px;padding:4px 6px;border-radius:14px;background:linear-gradient(180deg,rgba(10,8,16,.25),rgba(10,8,16,.6));box-shadow:0 2px 10px rgba(0,0,0,.35)}
#chatTg{position:absolute;z-index:6;bottom:calc(10px + var(--sb,0px));left:calc(50% - 178px);width:36px;height:36px;border-radius:50%;border:1px solid rgba(232,193,74,.6);background:rgba(10,8,16,.65);color:#fff;font-size:17px;cursor:pointer;padding:0}
#chatTg i{position:absolute;right:-3px;top:-3px;min-width:15px;height:15px;border-radius:8px;background:#e0443a;font:800 9px/15px system-ui;font-style:normal}#chatTg i[hidden]{display:none}
#wrap #chatBox.c6{position:absolute!important;left:50%!important;right:auto!important;top:auto!important;transform:translateX(-50%);bottom:calc(58px + var(--sb,0px))!important;width:min(48vw,380px)!important;border:0!important;box-shadow:none!important;background:transparent!important;z-index:4;font-size:11px!important}
#wrap #chatBox.c6.mini6{pointer-events:none}
#wrap #chatBox.c6.mini6 #chatHd,#wrap #chatBox.c6.mini6 #chatIn{display:none!important}
#wrap #chatBox.c6.mini6 #chatList{max-height:31px!important;min-height:0!important;overflow:hidden!important;display:flex;flex-direction:column;justify-content:flex-end;background:linear-gradient(90deg,transparent,rgba(0,0,0,.42) 12%,rgba(0,0,0,.42) 88%,transparent);border-radius:8px;padding:1px 14px;mask-image:linear-gradient(180deg,transparent,#000 35%)}
#wrap #chatBox.c6.mini6 .cl{flex:none;animation:cl6 14s forwards;line-height:1.35;text-shadow:0 1px 2px #000;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
@keyframes cl6{0%,80%{opacity:1}100%{opacity:0}}
#wrap #chatBox.c6.open6{pointer-events:auto;background:linear-gradient(180deg,rgba(16,12,24,.94),rgba(10,8,16,.94))!important;border:1px solid rgba(232,193,74,.5)!important;border-radius:12px;box-shadow:0 6px 20px rgba(0,0,0,.6)!important}
#wrap #chatBox.c6.open6 #chatList{max-height:min(34vh,140px)!important;overflow-y:auto!important}
#wrap #chatBox.c6 #chatFold{display:none}
#wrap #msg{bottom:calc(100px + var(--sb,0px))!important}
#tut{bottom:calc(104px + var(--sb,0px))!important}
#banner{top:calc(96px + var(--st,0px))!important}
#banner .b1{font-size:clamp(17px,5.2vh,30px)!important;letter-spacing:.5px}
#banner .b2{font-size:clamp(10px,2.8vh,13px)!important}
#banner:not([hidden]){animation:bn6 1.9s ease-out forwards}
@keyframes bn6{0%{opacity:0;transform:translateY(-10px) scale(.92)}10%{opacity:1;transform:none}78%{opacity:1}100%{opacity:0;transform:translateY(-6px)}}
#joyzone{z-index:1!important}
.sk.hasi{background-size:cover!important;background-position:center!important}
.sk.hasi .ic{color:transparent!important;text-shadow:none!important}
#skw .card .e img{width:46px;height:46px;border-radius:12px;display:block}
@media (max-height:520px){#wrap #hud{transform:none!important;top:calc(4px + var(--st,0px))!important;left:calc(4px + var(--sl,0px))!important;padding:3px 6px 3px 3px}#wrap #face{width:40px!important;height:40px!important}#wrap #hud .bars{width:132px!important;gap:2px!important}
 #wrap #hud .bar{height:11px!important;font-size:8.5px!important}#bfrow{top:calc(66px + var(--st,0px))}#wrap #zb{top:calc(94px + var(--st,0px))!important}#set6{left:26px;top:26px}}
`;document.head.appendChild(st)}

// ---------- ไอคอนวาด (บัฟ / หิว-แรง / โล่ชุด) ----------
const ICN6={};
function ic6(key,fn,s){if(ICN6[key])return ICN6[key];const c=document.createElement('canvas');c.width=c.height=s||64;const k=c.getContext('2d');k.lineJoin='round';k.lineCap='round';try{fn(k,c.width)}catch(e){}return ICN6[key]=c.toDataURL()}
function glowBg(k,S,c1,c2){const g=k.createRadialGradient(S*.5,S*.4,2,S*.5,S*.5,S*.62);g.addColorStop(0,c1);g.addColorStop(1,c2);k.fillStyle=g;k.beginPath();k.arc(S/2,S/2,S/2,0,7);k.fill()}
const BUFFICON={
 str:k=>{glowBg(k,64,'#ff8a6a','#5a0e0a');k.fillStyle='#ffd0b0';k.strokeStyle='#4a1a10';k.lineWidth=2.5;k.beginPath();k.moveTo(18,40);k.quadraticCurveTo(16,24,26,20);k.lineTo(42,20);k.quadraticCurveTo(50,22,48,34);k.quadraticCurveTo(48,46,36,48);k.lineTo(24,48);k.closePath();k.fill();k.stroke();
  for(const x of [27,33,39]){k.beginPath();k.moveTo(x,20);k.lineTo(x,28);k.stroke()}k.beginPath();k.moveTo(22,32);k.quadraticCurveTo(30,30,34,36);k.stroke();k.fillStyle='rgba(255,255,255,.5)';k.fillRect(26,22,10,3)},
 agi:k=>{glowBg(k,64,'#8af08a','#0a3a14');k.fillStyle='#f4fff0';k.strokeStyle='#1a4a1a';k.lineWidth=2;for(let i=0;i<4;i++){k.beginPath();k.moveTo(16+i*3,46-i*7);k.quadraticCurveTo(30+i*4,28-i*6,50,18+i*2);k.quadraticCurveTo(38+i*2,34-i*4,20+i*3,50-i*7);k.closePath();k.fill();k.stroke()}},
 vit:k=>{glowBg(k,64,'#ff9ac0','#5a0a2a');const g=k.createLinearGradient(0,16,0,50);g.addColorStop(0,'#ff6a8a');g.addColorStop(1,'#c01a3a');k.fillStyle=g;k.strokeStyle='#3a0812';k.lineWidth=2.5;k.beginPath();k.moveTo(32,50);k.bezierCurveTo(8,34,14,14,32,24);k.bezierCurveTo(50,14,56,34,32,50);k.fill();k.stroke();k.fillStyle='rgba(255,255,255,.6)';k.beginPath();k.ellipse(24,26,4,3,-.6,0,7);k.fill()},
 int:k=>{glowBg(k,64,'#9ac8ff','#0a1a4a');k.fillStyle='#e8f4ff';k.strokeStyle='#1a3a8a';k.lineWidth=2;k.beginPath();for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,r=i%2?8:20;k.lineTo(32+Math.cos(a)*r,33+Math.sin(a)*r)}k.closePath();k.fill();k.stroke();k.fillStyle='#7fd0ff';k.beginPath();k.arc(32,33,5,0,7);k.fill()},
 end:k=>{glowBg(k,64,'#ffe08a','#4a3a0a');const g=k.createLinearGradient(0,14,0,52);g.addColorStop(0,'#fff0b0');g.addColorStop(1,'#c8901a');k.fillStyle=g;k.strokeStyle='#4a3008';k.lineWidth=2.5;k.beginPath();k.moveTo(32,14);k.lineTo(48,20);k.quadraticCurveTo(48,42,32,52);k.quadraticCurveTo(16,42,16,20);k.closePath();k.fill();k.stroke();k.strokeStyle='#8a5a10';k.beginPath();k.moveTo(32,20);k.lineTo(32,46);k.moveTo(22,28);k.lineTo(42,28);k.stroke()},
 rest:k=>{glowBg(k,64,'#b8a8ff','#14103a');k.fillStyle='#fff6c8';k.beginPath();k.arc(30,32,15,0,7);k.fill();k.fillStyle='#14103a';k.beginPath();k.arc(37,27,13,0,7);k.fill();k.fillStyle='#fff';k.font='bold 11px sans-serif';k.fillText('z',42,46);k.fillText('Z',47,38)},
 food:k=>{glowBg(k,64,'#ffc88a','#4a1e0a');k.fillStyle='#e8e0d0';k.strokeStyle='#5a3a1a';k.lineWidth=2;k.beginPath();k.ellipse(32,40,20,7,0,0,7);k.fill();k.stroke();k.fillStyle='#c8642a';k.beginPath();k.ellipse(32,35,14,9,0,Math.PI,0);k.fill();k.stroke();k.strokeStyle='rgba(255,255,255,.7)';for(const x of [26,32,38]){k.beginPath();k.moveTo(x,22);k.quadraticCurveTo(x+3,18,x,14);k.stroke()}}};
function buffIcon(b){const ks=Object.keys(b.st||{}),id=b.id||'';let key=id==='rest'?'rest':FOOD&&FOOD[id]?'food':ks.sort((a,c)=>(b.st[c]||0)-(b.st[a]||0))[0]||'food';if(!BUFFICON[key])key='food';return ic6('bf_'+key,BUFFICON[key])}
const BUFFC={str:'#ff6a4a',agi:'#5ae06a',vit:'#ff6a9a',int:'#6aa8ff',end:'#ffc84a',rest:'#a898ff',food:'#ffa84a'};
const ICO_HU=ic6('v_hu',k=>{k.fillStyle='#c8642a';k.strokeStyle='#3a1a08';k.lineWidth=4;k.beginPath();k.ellipse(36,28,18,14,-.5,0,7);k.fill();k.stroke();k.fillStyle='#f4ecdc';k.beginPath();k.moveTo(24,38);k.lineTo(12,52);k.lineTo(8,48);k.lineTo(20,34);k.fill();k.stroke();k.fillStyle='rgba(255,255,255,.5)';k.beginPath();k.ellipse(32,22,6,3,-.5,0,7);k.fill()});
const ICO_FA=ic6('v_fa',k=>{k.fillStyle='#ffe04a';k.strokeStyle='#4a3a08';k.lineWidth=4;k.beginPath();k.moveTo(38,6);k.lineTo(16,36);k.lineTo(30,36);k.lineTo(24,58);k.lineTo(48,26);k.lineTo(34,26);k.closePath();k.fill();k.stroke()});

// ---------- แถว: เหรียญ + บัฟ ----------
const bfRow=document.createElement('div');bfRow.id='bfrow';gid('wrap').appendChild(bfRow);
{const cb=gid('coinbox');if(cb)bfRow.appendChild(cb)}
const bfList=document.createElement('span');bfList.style.cssText='display:contents';bfRow.appendChild(bfList);
let bf6prev=new Set();
function renderBf6(){const cur=new Set();let h='';for(const b of BUFFS){cur.add(b.id);const p=Math.max(0,Math.min(100,b.t/(b.dur||b.t||1)*100)),ks=Object.keys(b.st||{}),key=b.id==='rest'?'rest':FOOD&&FOOD[b.id]?'food':ks[0]||'food',tm=b.t>=60?Math.ceil(b.t/60)+'m':Math.ceil(b.t)+'s';
  h+='<div class="b6'+(bf6prev.has(b.id)?'':' new')+(b.t<10?' end':'')+'" data-b="'+b.id+'" style="--p:'+p.toFixed(1)+';--c:'+(BUFFC[key]||'#fff')+'"><img src="'+buffIcon(b)+'"><em>'+tm+'</em></div>'}
 if(bfList._h!==h){bfList.innerHTML=h;bfList._h=h}bf6prev=cur}
bfList.addEventListener('click',e=>{const el=e.target.closest('.b6');if(!el)return;const b=BUFFS.find(q=>q.id===el.dataset.b);if(b)say((b.ic||'✨')+' '+b.n+' — '+(typeof stTxt==='function'?stTxt(b.st):'')+' · เหลือ '+Math.ceil(b.t)+' วิ')});
{const _rb=renderBuffs;renderBuffs=function(){try{_rb()}catch(e){}renderBf6();renderSet6()}}
// ---------- หิว/แรง ใต้หลอด XP ----------
{const bars=document.querySelector('#hud .bars');const v=document.createElement('div');v.id='vit6';v.innerHTML='<div class="v hu" title="ความอิ่ม"><img src="'+ICO_HU+'"><div><i></i></div></div><div class="v fa" title="แรง"><img src="'+ICO_FA+'"><div><i></i></div></div>';if(bars)bars.appendChild(v)}
const vHu=document.querySelector('#vit6 .hu'),vFa=document.querySelector('#vit6 .fa');
setInterval(()=>{if(!vHu)return;const hu=Math.max(0,Math.min(100,P.hu|0)),fa=Math.max(0,Math.min(100,P.fa|0));vHu.querySelector('i').style.width=hu+'%';vFa.querySelector('i').style.width=fa+'%';vHu.classList.toggle('low',hu<25);vFa.classList.toggle('low',fa<20);vHu.title='ความอิ่ม '+hu+'/100';vFa.title='แรง '+fa+'/100'},300);
// ---------- โล่ชุดครบ (มุมรูปโปรไฟล์) ----------
const set6=document.createElement('div');set6.id='set6';set6.hidden=true;gid('hud').style.position='absolute';gid('hud').appendChild(set6);
set6.onclick=e=>{e.stopPropagation();const f=gid('face');if(f)f.click()};
function renderSet6(){let best=null;try{const c=setCount();for(const t in c)if(c[t]>=2&&(!best||c[t]>best.n||c[t]===best.n&&+t>+best.t))best={t,n:c[t]}}catch(e){}
 if(!best){set6.hidden=true;return}const full=best.n>=4,col=(TIERS[best.t]&&TIERS[best.t].mid)||'#e8c14a',k='sh_'+best.t;
 const img=ic6(k,(q)=>{const g=q.createLinearGradient(0,0,0,64);g.addColorStop(0,'#fff');g.addColorStop(.3,col);g.addColorStop(1,'#1a1a22');q.fillStyle=g;q.strokeStyle='#120c06';q.lineWidth=5;q.beginPath();q.moveTo(32,4);q.lineTo(58,12);q.quadraticCurveTo(58,44,32,60);q.quadraticCurveTo(6,44,6,12);q.closePath();q.fill();q.stroke()});
 const h='<img src="'+img+'" style="width:100%;height:100%"><b>'+(full?'4':'2')+'</b>';if(set6._h!==h){set6.innerHTML=h;set6._h=h}set6.hidden=false;set6.classList.toggle('full',full);set6.style.setProperty('--sc',col);
 set6.title='ชุด'+TNAMES[best.t]+' '+best.n+'/4 — แตะดูโบนัส'}
// ---------- แชท: ย่อเหลือ 2 บรรทัดกลางล่าง + ปุ่ม 💬 ----------
{const cb=gid('chatBox');if(cb){cb.classList.add('c6','mini6');const tg=document.createElement('button');tg.id='chatTg';tg.innerHTML='💬<i hidden>0</i>';gid('wrap').appendChild(tg);
 let unread=0;const badge=tg.querySelector('i');
 const open=v=>{cb.classList.toggle('open6',v);cb.classList.toggle('mini6',!v);if(v){unread=0;badge.hidden=true;const L=gid('chatList');if(L)L.scrollTop=1e6}};
 tg.onclick=e=>{e.stopPropagation();open(!cb.classList.contains('open6'));sfx('ui')};
 const L=gid('chatList');if(L)new MutationObserver(m=>{if(cb.classList.contains('open6')){L.scrollTop=1e6;return}let n=0;for(const r of m)for(const a of r.addedNodes)if(a.nodeType===1&&!a.classList.contains('ch-sys'))n++;if(n){unread+=n;badge.textContent=unread>9?'9+':unread;badge.hidden=false}}).observe(L,{childList:true});
 addEventListener('keydown',e=>{if(e.key==='Enter'&&cb.classList.contains('mini6')&&document.activeElement.tagName!=='INPUT'){open(true)}},true);
 window.chatOpen6=open}}
// ---------- แบนเนอร์: สั้นลง ไม่บังกลางจอ ----------
{const _b=banner;banner=function(a,b,cls){_b(a,b,cls);try{bnEl.style.animation='none';void bnEl.offsetWidth;bnEl.style.animation='';clearTimeout(_bnT);_bnT=setTimeout(()=>bnEl.hidden=true,1900)}catch(e){}}}

// =====================================================================
// สัตว์ขี่: นั่งบนอานจริง · ขึ้น/ลงมีท่า · เสียงกีบ · ฝุ่น · สัตว์ขี่ใหม่ (ยูนิคอร์น · ม้าอัคคี)
// =====================================================================
const MOUNTS={horse:{n:'ม้าศึกหุ้มเกราะ',spd:1.6},unicorn:{n:'ยูนิคอร์นแสงจันทร์',spd:1.85},flame:{n:'ม้าอัคคีนรก',spd:2.0},wolf:{n:'หมาป่าเงาจันทร์',spd:1.9}};
const MPAL={horse:{hi:'#c08a5a',b:'#8a5430',s:'#4a2a14',m:'#2a1a10',leg:'#5a3418'},unicorn:{hi:'#ffffff',b:'#eef0fa',s:'#b8bcd8',m:'#f0c8ff',leg:'#d8dcf0'},flame:{hi:'#4a3a40',b:'#241a20',s:'#0a0608',m:'#ff6a1a',leg:'#1a1014'},wolf:{hi:'#d8def0',b:'#7a80a0',s:'#3a3e58',m:'#e8ecff',leg:'#4a4e68'}};
if(!ANIMS.some(a=>a.k==='unicorn'))ANIMS.push({k:'unicorn',n:'ยูนิคอร์นแสงจันทร์',p:35000,mount:1,d:'สัตว์ขี่หายาก: เร็วขึ้น 85% · ประกายรุ้งทุกก้าว · ต้อง Lv.40'});
{const h=ANIMS.find(a=>a.k==='horse');if(h){h.n='ม้าศึกหุ้มเกราะ';h.d='สัตว์ขี่: เร็วขึ้น 60% · เกราะหน้าม้าเหล็ก อานหนังแท้'}}
{const w=ANIMS.find(a=>a.k==='wolf');if(w)w.d='สัตว์ขี่ในตำนาน: เร็วขึ้น 90% · ดวงตาเรืองแสง · ต้องปราบบอสสุดท้าย'}
{const _ba=buyAnimal;buyAnimal=function(k){if(k==='unicorn'&&P.lv<40){say('ต้อง Lv.40 ขึ้นไป');sfx('thud');return}const own=HOME.mounts||(HOME.mounts=[]);if(HOME.mount&&!own.includes(HOME.mount))own.push(HOME.mount);_ba(k);if(HOME.mount&&!own.includes(HOME.mount))own.push(HOME.mount);saveHome()}}
const MSC=.92,toW=(x,y,f,lx,ly)=>[x+f*MSC*(lx-34),y+MSC*ly];
function drawWolfMount(K,A,t,g){
 const leg=(hx,hy,ph,hind,far)=>beastLeg(hx,hy,ph,A*1.2,hind,K,far,1);
 leg(22,-24,g+Math.PI,1,1);leg(50,-24,g+4.712,0,1);
 ctx.save();ctx.translate(0,-Math.abs(Math.sin(g*2))*1.6*A);
 // หางพุ่มฟู
 const sw=Math.sin(t*3)*.25+Math.sin(g)*.2*A;ctx.fillStyle=K.b;ctx.strokeStyle='rgba(10,10,20,.5)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(14,-34);ctx.bezierCurveTo(2,-36+sw*8,-6,-28+sw*10,-4,-20+sw*12);ctx.bezierCurveTo(2,-24,8,-28,16,-28);ctx.fill();ctx.stroke();ctx.fillStyle=K.hi;ctx.beginPath();ctx.ellipse(-3,-22+sw*12,3,4,0,0,7);ctx.fill();
 // ลำตัว
 ctx.beginPath();ctx.moveTo(12,-30);ctx.bezierCurveTo(12,-42,26,-44,38,-42);ctx.bezierCurveTo(50,-41,56,-44,60,-42);ctx.bezierCurveTo(64,-36,60,-24,52,-22);ctx.bezierCurveTo(40,-20,26,-20,16,-22);ctx.closePath();bodyFill(K,-46,-20);
 ctx.fillStyle='rgba(255,255,255,.18)';for(let i=0;i<5;i++){ctx.beginPath();ctx.moveTo(20+i*7,-42);ctx.lineTo(23+i*7,-37);ctx.lineTo(26+i*7,-42);ctx.fill()}
 // หัว
 ctx.save();ctx.translate(60,-40);ctx.rotate(Math.sin(g)*.05*A);ctx.beginPath();ctx.moveTo(-6,-6);ctx.bezierCurveTo(0,-14,10,-12,14,-6);ctx.lineTo(24,-2);ctx.bezierCurveTo(26,2,22,5,16,5);ctx.bezierCurveTo(8,6,0,4,-4,2);ctx.closePath();bodyFill(K,-14,6);
 ctx.fillStyle=K.b;for(const ex of [0,6]){ctx.beginPath();ctx.moveTo(ex,-9);ctx.lineTo(ex+3,-20);ctx.lineTo(ex+7,-9);ctx.fill();ctx.stroke()}
 ctx.fillStyle='#120a14';ctx.beginPath();ctx.ellipse(24,0,2,1.6,0,0,7);ctx.fill();
 const eg=ctx.createRadialGradient(11,-5,0,11,-5,7);eg.addColorStop(0,'rgba(120,200,255,1)');eg.addColorStop(1,'rgba(120,200,255,0)');ctx.fillStyle=eg;ctx.fillRect(4,-12,14,14);ctx.fillStyle='#dff4ff';ctx.fillRect(10,-6,3,2);
 ctx.strokeStyle='#e8ecff';ctx.lineWidth=1.2;ctx.beginPath();ctx.moveTo(17,4);ctx.lineTo(18,7);ctx.moveTo(20,4);ctx.lineTo(21,7);ctx.stroke();ctx.restore();
 // อาน
 ctx.fillStyle='#2a2238';ctx.fillRect(26,-46,16,6);ctx.fillStyle='#8a7ad0';ctx.fillRect(26,-41,16,1.5);ctx.fillStyle='#3a2a18';ctx.beginPath();ctx.moveTo(25,-46);ctx.quadraticCurveTo(34,-51,43,-46);ctx.lineTo(43,-44);ctx.lineTo(25,-44);ctx.fill();
 ctx.restore();leg(16,-24,g,1,0);leg(46,-24,g+Math.PI/2,0,0)}
function drawSteed(k,x,y,f,A){const t=performance.now()/1000,g=t*(A?9.5:0)+(MOUNT.g0||0),K=MPAL[k]||MPAL.horse;
 ctx.save();ctx.translate(x,y);ctx.scale(f*MSC,MSC);ctx.translate(-34,0);
 ctx.fillStyle='rgba(0,0,0,.28)';ctx.beginPath();ctx.ellipse(34,1,40,6,0,0,7);ctx.fill();
 if(k==='wolf'){drawWolfMount(K,A,t,g);ctx.globalCompositeOperation='lighter';const gg=ctx.createRadialGradient(34,-34,2,34,-34,48);gg.addColorStop(0,'rgba(140,180,255,.28)');gg.addColorStop(1,'rgba(140,180,255,0)');ctx.fillStyle=gg;ctx.fillRect(-14,-82,96,96);ctx.restore();return}
 try{drawHorse({x:0,amp:A},t,K,A,g)}catch(e){}
 const lift=-Math.abs(Math.sin(g*2))*1.2*A;ctx.translate(0,lift);
 // อานหนังแท้ + โกลน
 ctx.fillStyle='#3a1e0c';ctx.strokeStyle='#1a0c04';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(26,-46);ctx.quadraticCurveTo(28,-53,31,-50);ctx.quadraticCurveTo(35,-47,39,-49);ctx.quadraticCurveTo(43,-53,44,-47);ctx.lineTo(43,-43);ctx.lineTo(27,-43);ctx.closePath();ctx.fill();ctx.stroke();
 ctx.fillStyle=k==='unicorn'?'#8a6ad0':k==='flame'?'#5a0a0a':'#7a1a1a';ctx.fillRect(27,-43,16,5);ctx.fillStyle='#e8c14a';ctx.fillRect(27,-38.5,16,1.2);
 if(k==='horse'){// เกราะหน้าม้า + เกราะอก
  ctx.fillStyle='#c8ccd6';ctx.strokeStyle='#3a3e48';ctx.beginPath();ctx.moveTo(57,-70);ctx.lineTo(66,-66);ctx.lineTo(73,-55);ctx.lineTo(69,-52);ctx.lineTo(60,-60);ctx.closePath();ctx.fill();ctx.stroke();ctx.fillStyle='#e8c14a';ctx.beginPath();ctx.arc(63,-63,1.6,0,7);ctx.fill();
  ctx.fillStyle='#a8acb8';ctx.beginPath();ctx.moveTo(52,-46);ctx.quadraticCurveTo(62,-40,58,-30);ctx.lineTo(52,-32);ctx.closePath();ctx.fill();ctx.stroke()}
 if(k==='unicorn'){ctx.save();ctx.translate(60,-71);const hg=ctx.createLinearGradient(0,0,6,-16);hg.addColorStop(0,'#fff4c0');hg.addColorStop(1,'#ffd040');ctx.fillStyle=hg;ctx.beginPath();ctx.moveTo(-2,0);ctx.lineTo(5,-17);ctx.lineTo(3,1);ctx.closePath();ctx.fill();ctx.strokeStyle='#c8901a';ctx.lineWidth=.8;for(let i=1;i<5;i++){ctx.beginPath();ctx.moveTo(-1+i*.9,-i*3.4);ctx.lineTo(2.6+i*.4,-i*3.4+1.2);ctx.stroke()}ctx.restore();
  ctx.globalCompositeOperation='lighter';const hg2=ctx.createRadialGradient(64,-86,0,64,-86,10);hg2.addColorStop(0,'rgba(255,240,180,.8)');hg2.addColorStop(1,'rgba(255,240,180,0)');ctx.fillStyle=hg2;ctx.fillRect(54,-96,20,20);ctx.globalCompositeOperation='source-over'}
 if(k==='flame'){ctx.globalCompositeOperation='lighter';for(let i=0;i<8;i++){const u=i/7,px=47+u*11,py=-48-u*20,fl=4+Math.sin(t*12+i*2)*2;const fg=ctx.createRadialGradient(px-3,py+2,0,px-3,py+2,fl+5);fg.addColorStop(0,'rgba(255,220,120,.9)');fg.addColorStop(.5,'rgba(255,90,20,.6)');fg.addColorStop(1,'rgba(255,40,0,0)');ctx.fillStyle=fg;ctx.fillRect(px-12,py-10,18,18)}
  const eg=ctx.createRadialGradient(65,-62,0,65,-62,5);eg.addColorStop(0,'rgba(255,80,20,1)');eg.addColorStop(1,'rgba(255,80,20,0)');ctx.fillStyle=eg;ctx.fillRect(60,-67,10,10);ctx.globalCompositeOperation='source-over'}
 ctx.restore()}
function mountParticles(k,x,y,f,A,dt){if(!A)return;MOUNT.pt=(MOUNT.pt||0)-dt;MOUNT.ht=(MOUNT.ht||0)-dt;const sp=MOUNTS[k]?MOUNTS[k].spd:1.6;
 if(MOUNT.ht<=0){MOUNT.ht=.34/sp*1.6;try{sfx('hoof')}catch(e){}}
 if(MOUNT.pt>0)return;MOUNT.pt=.05;const hooves=k==='wolf'?[[16,0],[46,0]]:[[20,0],[48,0]];const [lx,ly]=hooves[Math.random()*2|0],[wx,wy]=toW(x,y,f,lx,ly);
 if(k==='flame'){rfxP(wx,wy-2,(Math.random()-.5)*20,-30-Math.random()*30,.5,Math.random()<.5?'255,140,40':'255,60,20',2.4,'spark');const [mx,my]=toW(x,y,f,47+Math.random()*11,-50-Math.random()*20);rfxP(mx,my,-f*20,-30,.45,'255,120,30',2,'spark')}
 else if(k==='unicorn'){const hue=['255,140,200','255,230,120','140,230,255','180,150,255','150,255,180'][Math.random()*5|0];rfxP(wx,wy-4,(Math.random()-.5)*16,-20-Math.random()*20,.8,hue,2.2,'spark')}
 else if(k==='wolf'){rfxP(wx,wy-2,(Math.random()-.5)*14,-14,.6,'150,180,255',1.8,'dot')}
 else rfxP(wx,wy-1,(Math.random()-.5)*24-f*14,-8-Math.random()*10,.5,'190,170,140',2.6,'dot')}
let mLastT=performance.now();
// ท่านั่ง (ใช้ทั้งบนหลังสัตว์และเก้าอี้)
function seatLegs(x,hipY,f,side,EC,stir){const LG=EC.BLK||'#262631',BT='#2a1a10';ctx.save();ctx.lineCap='round';
 if(side){ctx.strokeStyle=LG;ctx.lineWidth=6;ctx.beginPath();ctx.moveTo(x,hipY);ctx.lineTo(x+f*7,hipY+4);ctx.stroke();ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(x+f*7,hipY+4);ctx.lineTo(x+f*5,hipY+11);ctx.stroke();ctx.fillStyle=BT;ctx.fillRect(x+f*5-3+(f>0?1:-2),hipY+10,7,4);if(!stir){ctx.restore();return}
  ctx.strokeStyle='#5a3418';ctx.lineWidth=1.2;ctx.beginPath();ctx.moveTo(x+f*2,hipY);ctx.lineTo(x+f*4,hipY+13);ctx.stroke();ctx.fillStyle='#c8ccd6';ctx.fillRect(x+f*4-4,hipY+13,8,2)}
 else{ctx.fillStyle=LG;ctx.fillRect(x-8,hipY,7,6);ctx.fillRect(x+1,hipY,7,6);ctx.fillRect(x-8,hipY+5,6,7);ctx.fillRect(x+2,hipY+5,6,7);ctx.fillStyle=BT;ctx.fillRect(x-8,hipY+11,6,3);ctx.fillRect(x+2,hipY+11,6,3)}
 ctx.restore()}
{const _h=hero;hero=function(){
  const now=performance.now(),dt=Math.min(.05,(now-mLastT)/1000);mLastT=now;
  if(P.sit&&!P.dead&&!MOUNT.on){const EC=EQCOL(),hip=P.y-9;ctx.save();ctx.translate(0,3);ctx.beginPath();ctx.rect(P.x-60,P.y-130,120,130-12);ctx.clip();_h();ctx.restore();const sd=P.dir==='l'||P.dir==='r';seatLegs(P.x,hip,P.dir==='l'?-1:1,sd,EC,false);return}
  if(!(MOUNT.on&&HOME.mount)||P.dead){if(MOUNT.jt>0)MOUNT.jt-=dt;return _h()}
  const k=HOME.mount,f=P.dir==='l'?-1:P.dir==='r'?1:(MOUNT.f||1);MOUNT.f=f;const A=P.mv?1:0,t=now/1000,g=t*(A?9.5:0);
  let jy=0;if(MOUNT.jt>0){MOUNT.jt-=dt;const u=1-MOUNT.jt/.35;jy=-Math.sin(Math.max(0,Math.min(1,u))*Math.PI)*18}
  if((P.dir==='u'||P.dir==='d')&&window.drawSteedUD7)drawSteedUD7(k,P.x,P.y+2,P.dir,A,0);else drawSteed(k,P.x,P.y+2,f,A);mountParticles(k,P.x,P.y+2,f,A,dt);
  const bob=-Math.abs(Math.sin(g*2))*1.2*A*MSC,saddle=k==='wolf'?-37:-40,hipY=P.y+2+saddle*MSC+bob+jy+1;
  const sv={dir:P.dir,mv:P.mv},ud7=!!window.drawSteedUD7&&(P.dir==='u'||P.dir==='d');if(!ud7)P.dir=f<0?'l':'r';P.mv=false;const EC=EQCOL();
  ctx.save();ctx.translate(ud7?0:f*2,hipY-(P.y-12));ctx.beginPath();ctx.rect(P.x-70,P.y-140,140,140-12);ctx.clip();MOUNT.on=false;try{_h()}finally{MOUNT.on=true}ctx.restore();
  if(ud7){seatLegs(P.x,hipY,f,false,EC,true);drawSteedUD7(k,P.x,P.y+2,P.dir,A,1)}else seatLegs(P.x+f*2,hipY,f,true,EC,true);P.dir=sv.dir;P.mv=sv.mv}}
{const _sm=spdMul;spdMul=function(){const b=_sm();if(!MOUNT.on||!HOME.mount)return b;const old=HOME.mount==='wolf'?1.9:1.6,nw=(MOUNTS[HOME.mount]||MOUNTS.horse).spd;return b/old*nw}}
{const _tm=toggleMount;toggleMount=function(){const was=MOUNT.on;_tm();if(MOUNT.on!==was){MOUNT.jt=.35;for(let i=0;i<16;i++){const a=Math.random()*6.28;rfxP(P.x+Math.cos(a)*14,P.y,Math.cos(a)*50,-10-Math.random()*20,.5,'210,190,150',2.6,'dot')}
  if(MOUNT.on){const k=HOME.mount;tone(520,780,.18,'triangle',.05);tone(780,640,.3,'triangle',.04,.16);if(k!=='wolf'){nz(.35,.08,1800,700,3,'bandpass',.05)}else{tone(300,700,.6,'sawtooth',.03,.05)}say('🐎 ขี่'+((MOUNTS[k]||{}).n||'สัตว์ขี่')+' · เร็วขึ้น '+Math.round(((MOUNTS[k]||MOUNTS.horse).spd-1)*100)+'%')}}}}
// ลงจากหลังเมื่อเข้าโหมดต่อสู้: มีท่ากระโดดลง
{const _a=attack;attack=function(q){if(MOUNT.on&&!(D&&D.home&&TOOLKEYS.includes(P.tool))){MOUNT.jt=.35;for(let i=0;i<10;i++)rfxP(P.x+(Math.random()-.5)*30,P.y,(Math.random()-.5)*60,-20,.4,'210,190,150',2.4,'dot')}return _a(q)}}

// =====================================================================
// เครื่องมือฟาร์มวาดใหม่ (จอบ/บัวรดน้ำ/เคียว/ค้อน) + ถุงเมล็ดพันธุ์
// =====================================================================
const FT6={};const TMET=[['#8a8a90','#c8c8d0','#4a4a52'],['#9aa0aa','#e0e6ee','#4a505a'],['#c8743a','#ffb070','#6a3010'],['#c8d0dc','#ffffff','#6a7280'],['#e8b820','#fff0a0','#7a5a08'],['#5ac8f0','#e0faff','#1a5a80']];
function farmTool(k,tier){tier=tier|0;const key=k+tier;if(FT6[key])return FT6[key];const c=document.createElement('canvas');c.width=c.height=64;const q=c.getContext('2d'),[m,mh,md]=TMET[tier]||TMET[0];q.lineCap='round';q.lineJoin='round';
 const handle=(x1,y1,x2,y2,w)=>{const g=q.createLinearGradient(x1,y1,x2+4,y2);g.addColorStop(0,'#5a3418');g.addColorStop(.5,'#b07a44');g.addColorStop(1,'#6a4020');q.strokeStyle='#24140a';q.lineWidth=w+2.5;q.beginPath();q.moveTo(x1,y1);q.lineTo(x2,y2);q.stroke();q.strokeStyle=g;q.lineWidth=w;q.stroke();q.strokeStyle='rgba(255,230,190,.35)';q.lineWidth=1;q.beginPath();q.moveTo(x1-1,y1-1);q.lineTo(x2-1,y2-1);q.stroke()};
 const metal=(path,x0,y0,x1,y1)=>{const g=q.createLinearGradient(x0,y0,x1,y1);g.addColorStop(0,mh);g.addColorStop(.45,m);g.addColorStop(1,md);q.fillStyle=g;q.strokeStyle='#14141a';q.lineWidth=1.8;q.beginPath();path();q.fill();q.stroke()};
 if(k==='hoe'){handle(32,60,32,10,4.5);
  metal(()=>{q.moveTo(28,8);q.lineTo(36,8);q.lineTo(36,15);q.lineTo(28,15);q.closePath()},28,8,36,15);
  metal(()=>{q.moveTo(36,9);q.lineTo(50,11);q.lineTo(54,27);q.quadraticCurveTo(48,30,40,27);q.lineTo(36,15);q.closePath()},36,9,54,30);
  q.strokeStyle=mh;q.lineWidth=1.4;q.beginPath();q.moveTo(42,26);q.lineTo(52,26);q.stroke()}
 else if(k==='hamr'){handle(32,60,32,18,4.5);q.fillStyle='#3a2410';q.fillRect(29,18,6,4);
  metal(()=>{q.moveTo(22,6);q.lineTo(44,6);q.lineTo(44,18);q.lineTo(22,18);q.closePath()},22,6,44,18);
  metal(()=>{q.moveTo(44,5);q.lineTo(51,4);q.lineTo(51,20);q.lineTo(44,19);q.closePath()},44,4,51,20);
  metal(()=>{q.moveTo(22,7);q.quadraticCurveTo(12,4,8,11);q.quadraticCurveTo(14,11,22,17);q.closePath()},8,4,22,17);
  q.fillStyle='rgba(255,255,255,.55)';q.fillRect(25,8,16,2)}
 else if(k==='sick'){handle(32,60,32,30,5);q.fillStyle='#3a2410';q.fillRect(29,27,7,5);
  metal(()=>{q.moveTo(30,29);q.bezierCurveTo(26,10,42,2,56,10);q.bezierCurveTo(46,8,36,14,35,29);q.closePath()},26,4,56,29);
  q.strokeStyle=mh;q.lineWidth=1.3;q.beginPath();q.moveTo(33,25);q.bezierCurveTo(32,12,43,7,53,10);q.stroke()}
 else{// บัวรดน้ำ (ด้ามจับอยู่กลาง)
  const g=q.createLinearGradient(14,24,48,58);g.addColorStop(0,mh);g.addColorStop(.5,m);g.addColorStop(1,md);q.fillStyle=g;q.strokeStyle='#14141a';q.lineWidth=2;
  q.beginPath();q.moveTo(18,32);q.lineTo(46,32);q.lineTo(48,58);q.quadraticCurveTo(32,62,16,58);q.closePath();q.fill();q.stroke();
  q.beginPath();q.ellipse(32,32,14,4,0,0,7);q.fillStyle=md;q.fill();q.stroke();q.fillStyle='#4a8ac8';q.beginPath();q.ellipse(32,32,11,2.6,0,0,7);q.fill();
  q.beginPath();q.moveTo(46,48);q.lineTo(58,28);q.lineTo(61,30);q.lineTo(48,54);q.closePath();q.fillStyle=g;q.fill();q.stroke();
  q.strokeStyle=md;q.lineWidth=3;q.beginPath();q.moveTo(22,32);q.bezierCurveTo(22,12,42,12,42,32);q.stroke();
  q.fillStyle='rgba(255,255,255,.45)';q.fillRect(21,36,3,18)}
 if(tier>=3){q.globalCompositeOperation='lighter';const gl=q.createRadialGradient(40,14,0,40,14,20);gl.addColorStop(0,tier>=5?'rgba(120,220,255,.5)':'rgba(255,230,140,.4)');gl.addColorStop(1,'rgba(0,0,0,0)');q.fillStyle=gl;q.fillRect(20,0,44,40)}
 return FT6[key]=c}
toolIcon2=function(k,tier){return farmTool(k,tier)};
{const _ts=toolSpr;toolSpr=function(hx,hy,ang){if(!TOOLKEYS.includes(P.tool))return _ts(hx,hy,ang);ctx.save();ctx.translate(hx,hy);ctx.rotate(ang);if(P.dir==='r')ctx.scale(-1,1);ctx.drawImage(farmTool(P.tool,HOME.tools[P.tool]|0),-21,-38,42,42);ctx.restore()}}
// ถุงเมล็ดพันธุ์
const SEEDART={turnip:(q)=>{q.fillStyle='#f4f0e8';q.beginPath();q.ellipse(32,40,9,8,0,0,7);q.fill();q.fillStyle='#b06ad0';q.beginPath();q.ellipse(32,36,9,5,0,Math.PI,0);q.fill();q.fillStyle='#4aa040';for(const a of [-.5,0,.5]){q.beginPath();q.ellipse(32+a*10,26,3,7,a,0,7);q.fill()}},
 wheat:(q)=>{q.strokeStyle='#8a6a20';q.lineWidth=1.5;for(const x of [26,32,38]){q.beginPath();q.moveTo(x,48);q.lineTo(x,24);q.stroke();q.fillStyle='#e8c860';for(let i=0;i<5;i++){q.beginPath();q.ellipse(x-2,28+i*4,2,3,-.5,0,7);q.ellipse(x+2,28+i*4,2,3,.5,0,7);q.fill()}}},
 carrot:(q)=>{q.fillStyle='#ff8a2a';q.beginPath();q.moveTo(26,28);q.lineTo(38,28);q.lineTo(32,50);q.closePath();q.fill();q.strokeStyle='#c85a10';q.lineWidth=1;for(const y of [33,38,43]){q.beginPath();q.moveTo(28+(y-28)*.2,y);q.lineTo(31,y);q.stroke()}q.fillStyle='#4aa040';for(const a of [-.4,0,.4]){q.beginPath();q.ellipse(32+a*8,22,2.5,7,a,0,7);q.fill()}},
 cabbage:(q)=>{const g=q.createRadialGradient(30,34,2,32,38,13);g.addColorStop(0,'#e8ffc8');g.addColorStop(1,'#5aa040');q.fillStyle=g;q.beginPath();q.arc(32,38,12,0,7);q.fill();q.strokeStyle='#3a7a2a';q.lineWidth=1;for(const a of [0,1.2,2.4,3.6,4.8]){q.beginPath();q.arc(32,38,7,a,a+1.2);q.stroke()}},
 tomato:(q)=>{const g=q.createRadialGradient(28,34,1,32,38,12);g.addColorStop(0,'#ff9a8a');g.addColorStop(1,'#c0201a');q.fillStyle=g;q.beginPath();q.arc(32,38,11,0,7);q.fill();q.fillStyle='#3a8a2a';q.beginPath();for(let i=0;i<5;i++){const a=i*1.256-1.57;q.lineTo(32+Math.cos(a)*7,28+Math.sin(a)*3);q.lineTo(32+Math.cos(a+.6)*2,28+Math.sin(a+.6)*1)}q.fill()},
 strawberry:(q)=>{const g=q.createLinearGradient(0,28,0,50);g.addColorStop(0,'#ff6a7a');g.addColorStop(1,'#b0102a');q.fillStyle=g;q.beginPath();q.moveTo(22,32);q.quadraticCurveTo(32,26,42,32);q.quadraticCurveTo(40,46,32,52);q.quadraticCurveTo(24,46,22,32);q.fill();q.fillStyle='#fff3a0';for(const [a,b] of [[27,36],[32,35],[37,36],[29,42],[35,42],[32,47]])q.fillRect(a,b,1.6,2);q.fillStyle='#3a9a3a';q.beginPath();q.ellipse(32,29,9,3,0,0,7);q.fill()},
 corn:(q)=>{q.fillStyle='#6aa040';q.beginPath();q.ellipse(26,40,5,14,.3,0,7);q.ellipse(38,40,5,14,-.3,0,7);q.fill();const g=q.createLinearGradient(28,0,36,0);g.addColorStop(0,'#ffd23a');g.addColorStop(1,'#e8a820');q.fillStyle=g;q.beginPath();q.ellipse(32,36,6,14,0,0,7);q.fill();q.fillStyle='rgba(160,100,10,.35)';for(let y=25;y<48;y+=3)for(let x=28;x<37;x+=3)q.fillRect(x,y,1.2,1.2)},
 pumpkin:(q)=>{const g=q.createRadialGradient(28,34,2,32,40,14);g.addColorStop(0,'#ffc070');g.addColorStop(1,'#d0600a');q.fillStyle=g;for(const dx of [-7,0,7]){q.beginPath();q.ellipse(32+dx,40,8,10,0,0,7);q.fill()}q.strokeStyle='rgba(120,40,0,.4)';q.lineWidth=1;for(const dx of [-4,4]){q.beginPath();q.ellipse(32+dx,40,4,10,0,0,7);q.stroke()}q.fillStyle='#5a3a10';q.fillRect(31,26,3,6);q.fillStyle='#3a8a2a';q.beginPath();q.ellipse(37,28,5,2,.4,0,7);q.fill()}};
const SEEDCV={};function seedPack(k){if(SEEDCV[k])return SEEDCV[k];const cv=document.createElement('canvas');cv.width=cv.height=64;const q=cv.getContext('2d');q.lineJoin='round';q.lineCap='round';try{((q)=>{const C=CROPS[k];q.fillStyle='rgba(0,0,0,.25)';q.beginPath();q.ellipse(32,60,20,3,0,0,7);q.fill();
 const g=q.createLinearGradient(10,0,54,0);g.addColorStop(0,'#c8a46a');g.addColorStop(.5,'#ecd4a0');g.addColorStop(1,'#b08a50');q.fillStyle=g;q.strokeStyle='#5a3a18';q.lineWidth=2;
 q.beginPath();q.moveTo(12,12);for(let x=12;x<=52;x+=4)q.lineTo(x,x%8?9:12);q.lineTo(52,12);q.lineTo(54,58);q.lineTo(10,58);q.closePath();q.fill();q.stroke();
 q.fillStyle='#fffaf0';q.strokeStyle='rgba(90,58,24,.5)';q.lineWidth=1;q.beginPath();q.roundRect?q.roundRect(15,18,34,30,4):q.rect(15,18,34,30);q.fill();q.stroke();
 q.save();q.beginPath();q.rect(15,18,34,30);q.clip();const sg=q.createLinearGradient(0,18,0,48);sg.addColorStop(0,'#cfe8ff');sg.addColorStop(.7,'#eef8ff');sg.addColorStop(.71,'#9cd07a');sg.addColorStop(1,'#6fae55');q.fillStyle=sg;q.fillRect(15,18,34,30);q.translate(0,-4);(SEEDART[k]||SEEDART.turnip)(q);q.restore();
 q.fillStyle=C.c[1];q.fillRect(12,50,40,6);q.fillStyle='#fff';q.font='bold 6px sans-serif';q.textAlign='center';q.fillText('SEEDS',32,55.5)})(q)}catch(e){}return SEEDCV[k]=cv}
{const _mi=matIcon;matIcon=function(key){if(/^sd_/.test(key)&&CROPS[key.slice(3)]){const c=document.createElement('canvas');c.width=c.height=48;c.getContext('2d').drawImage(seedPack(key.slice(3)),0,0,48,48);return c}
  if(/^t_/.test(key)){const c=document.createElement('canvas');c.width=c.height=48;c.getContext('2d').drawImage(farmTool(key.slice(2),HOME.tools[key.slice(2)]|0),0,0,48,48);return c}return _mi(key)}}
try{for(const k in IURL)if(/^mat:(sd_|t_)/.test(k))delete IURL[k]}catch(e){}

// =====================================================================
// ไอคอนสกิลวาดใหม่ (แทนอีโมจิ)
// =====================================================================
const SKI6={};
function skBg(q,S,a,b,rim){const g=q.createRadialGradient(S*.5,S*.45,S*.05,S*.5,S*.5,S*.75);g.addColorStop(0,a);g.addColorStop(1,b);q.fillStyle=g;q.fillRect(0,0,S,S);
 q.strokeStyle=rim||'rgba(255,230,160,.7)';q.lineWidth=S*.05;q.strokeRect(S*.025,S*.025,S*.95,S*.95);q.strokeStyle='rgba(0,0,0,.5)';q.lineWidth=S*.02;q.strokeRect(S*.06,S*.06,S*.88,S*.88)}
function sglow(q,x,y,r,rgb,a){const g=q.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,'rgba('+rgb+','+(a||.9)+')');g.addColorStop(1,'rgba('+rgb+',0)');q.fillStyle=g;q.fillRect(x-r,y-r,r*2,r*2)}
function skSword(q,x,y,ang,L,col,hilt){q.save();q.translate(x,y);q.rotate(ang);const g=q.createLinearGradient(-4,0,4,0);g.addColorStop(0,'#8a96aa');g.addColorStop(.5,col||'#ffffff');g.addColorStop(1,'#6a7488');q.fillStyle=g;q.strokeStyle='#1a1e2a';q.lineWidth=1.5;
 q.beginPath();q.moveTo(-3.5,0);q.lineTo(-3.5,-L*.82);q.lineTo(0,-L);q.lineTo(3.5,-L*.82);q.lineTo(3.5,0);q.closePath();q.fill();q.stroke();q.fillStyle=hilt||'#e8c14a';q.fillRect(-9,0,18,3.5);q.strokeRect(-9,0,18,3.5);q.fillStyle='#4a2a14';q.fillRect(-2,3.5,4,L*.22);q.fillStyle=hilt||'#e8c14a';q.beginPath();q.arc(0,4+L*.24,3,0,7);q.fill();q.restore()}
function skArrow(q,x,y,ang,L,col,fl){q.save();q.translate(x,y);q.rotate(ang);q.strokeStyle='#6a4a2a';q.lineWidth=2.4;q.beginPath();q.moveTo(-L/2,0);q.lineTo(L/2,0);q.stroke();q.fillStyle=col||'#d8dce8';q.strokeStyle='#1a1a22';q.lineWidth=1;q.beginPath();q.moveTo(L/2+7,0);q.lineTo(L/2-2,-4);q.lineTo(L/2-2,4);q.closePath();q.fill();q.stroke();
 q.fillStyle=fl||'#e04a3a';q.beginPath();q.moveTo(-L/2,0);q.lineTo(-L/2-5,-5);q.lineTo(-L/2+5,0);q.lineTo(-L/2-5,5);q.closePath();q.fill();q.restore()}
function skFlame(q,x,y,s,c1,c2){const g=q.createRadialGradient(x,y+s*.3,0,x,y,s*1.2);g.addColorStop(0,c1||'#fff4a0');g.addColorStop(.45,c2||'#ff8a1a');g.addColorStop(1,'rgba(200,30,0,0)');q.fillStyle=g;q.beginPath();q.moveTo(x,y-s*1.3);q.bezierCurveTo(x+s*.9,y-s*.4,x+s*.8,y+s*.7,x,y+s*.8);q.bezierCurveTo(x-s*.8,y+s*.7,x-s*.9,y-s*.4,x,y-s*1.3);q.fill()}
function skBolt(q,pts,w,col){q.strokeStyle=col||'#fff8c0';q.lineWidth=w;q.shadowColor='#7fd8ff';q.shadowBlur=10;q.beginPath();q.moveTo(pts[0],pts[1]);for(let i=2;i<pts.length;i+=2)q.lineTo(pts[i],pts[i+1]);q.stroke();q.shadowBlur=0}
const SKART={
 'กระทืบปฐพี':(q,S)=>{skBg(q,S,'#c87a3a','#2a1206');sglow(q,48,70,40,'255,170,60');q.strokeStyle='#1a0a02';q.lineWidth=3;for(const a of [-2.6,-2,-1.2,-.5,.2]){q.beginPath();q.moveTo(48,70);q.lineTo(48+Math.cos(a)*40,70+Math.sin(a)*26+20);q.stroke()}
  for(let i=1;i<4;i++){q.strokeStyle='rgba(255,220,140,'+(.9-i*.2)+')';q.lineWidth=3;q.beginPath();q.ellipse(48,72,12*i,4*i,0,0,7);q.stroke()}
  q.fillStyle='#3a2a1a';q.strokeStyle='#0a0602';q.lineWidth=2;q.beginPath();q.moveTo(36,18);q.lineTo(54,18);q.lineTo(56,56);q.lineTo(66,58);q.lineTo(66,66);q.lineTo(34,66);q.closePath();q.fill();q.stroke();q.fillStyle='#8a8a92';q.fillRect(34,60,32,6);
  for(let i=0;i<8;i++){q.fillStyle='#6a4a2a';q.fillRect(20+i*8,64-((i*7)%11),5,5)}},
 'ดาบสามจังหวะ':(q,S)=>{skBg(q,S,'#8a1a2a','#1a0408');for(let i=0;i<3;i++){q.strokeStyle='rgba(255,240,240,'+(.95-i*.22)+')';q.lineWidth=6-i;q.beginPath();q.arc(48+i*6,52-i*10,30-i*3,-2.5+i*.3,-.6+i*.3);q.stroke()}skSword(q,58,74,.75,52,'#fff0f0')},
 'พายุดาบ':(q,S)=>{skBg(q,S,'#4a6a8a','#0a1420');for(let i=0;i<3;i++){q.strokeStyle='rgba(200,230,255,'+(.7-i*.18)+')';q.lineWidth=4;q.beginPath();q.arc(48,48,14+i*10,i,i+4.2);q.stroke()}for(let i=0;i<6;i++){const a=i*1.047;skSword(q,48+Math.cos(a)*24,48+Math.sin(a)*24,a+Math.PI,24,'#dff0ff')}sglow(q,48,48,16,'200,240,255')},
 'ฟันวาปสายฟ้า':(q,S)=>{skBg(q,S,'#3a4a9a','#060818');skBolt(q,[60,6,44,38,56,40,34,90],5);skBolt(q,[60,6,44,38,56,40,34,90],2,'#ffffff');for(let i=0;i<3;i++){q.globalAlpha=.25+i*.25;skSword(q,22+i*14,74-i*6,.6,40,'#e0f0ff')}q.globalAlpha=1},
 'ใบดาบวิญญาณวน':(q,S)=>{skBg(q,S,'#2a7a8a','#041418');sglow(q,48,48,30,'110,255,230',.7);for(let i=0;i<5;i++){const a=i*1.256;q.globalAlpha=.85;skSword(q,48+Math.cos(a)*26,48+Math.sin(a)*26,a+1.9,26,'#b8fff0','#5affd8')}q.globalAlpha=1;q.strokeStyle='rgba(110,255,230,.6)';q.lineWidth=2;q.beginPath();q.arc(48,48,26,0,7);q.stroke()},
 'ฟันกากบาทสวรรค์':(q,S)=>{skBg(q,S,'#c89a2a','#2a1a04');sglow(q,48,48,40,'255,240,160');q.strokeStyle='#fffbe0';q.lineWidth=8;q.beginPath();q.moveTo(14,14);q.lineTo(82,82);q.moveTo(82,14);q.lineTo(14,82);q.stroke();q.strokeStyle='#ffd23a';q.lineWidth=3;q.stroke();for(let i=0;i<8;i++){const a=i*.785;q.strokeStyle='rgba(255,250,200,.6)';q.lineWidth=1.5;q.beginPath();q.moveTo(48+Math.cos(a)*10,48+Math.sin(a)*10);q.lineTo(48+Math.cos(a)*44,48+Math.sin(a)*44);q.stroke()}},
 'วงแหวนเพลิง':(q,S)=>{skBg(q,S,'#6a1a0a','#100402');for(let i=0;i<14;i++){const a=i*.449;skFlame(q,48+Math.cos(a)*28,52+Math.sin(a)*16,8)}sglow(q,48,52,20,'255,160,60',.6)},
 'เวทธาตุสามสาย':(q,S)=>{skBg(q,S,'#3a2a6a','#08061a');const orb=(x,y,rgb,c)=>{sglow(q,x,y,18,rgb);q.fillStyle=c;q.beginPath();q.arc(x,y,8,0,7);q.fill();q.fillStyle='rgba(255,255,255,.8)';q.beginPath();q.arc(x-3,y-3,2.5,0,7);q.fill()};orb(48,26,'140,220,255','#bfeaff');orb(26,64,'255,240,120','#fff6a0');orb(70,64,'255,120,40','#ff9a4a');q.strokeStyle='rgba(220,200,255,.5)';q.lineWidth=2;q.beginPath();q.moveTo(48,26);q.lineTo(26,64);q.lineTo(70,64);q.closePath();q.stroke()},
 'พายุอุกกาบาต':(q,S)=>{skBg(q,S,'#7a2a0a','#120402');for(let i=0;i<3;i++){const x=24+i*22,y=30+i*16;q.strokeStyle='rgba(255,180,80,.5)';q.lineWidth=7-i;q.beginPath();q.moveTo(x-30,y-30);q.lineTo(x,y);q.stroke();sglow(q,x,y,14,'255,150,50');q.fillStyle='#5a2a14';q.beginPath();q.arc(x,y,7-i,0,7);q.fill();q.fillStyle='#ffb050';q.beginPath();q.arc(x+2,y+2,3,0,7);q.fill()}},
 'อัญเชิญโครงกระดูก':(q,S)=>{skBg(q,S,'#2a5a2a','#040c04');skFlame(q,48,60,26,'#d0ffb0','#40c060');q.fillStyle='#f0ecdc';q.strokeStyle='#2a2a1a';q.lineWidth=2;q.beginPath();q.arc(48,42,18,Math.PI*.9,Math.PI*2.1);q.lineTo(60,62);q.lineTo(36,62);q.closePath();q.fill();q.stroke();q.fillStyle='#0a140a';q.beginPath();q.ellipse(40,44,5,6,0,0,7);q.ellipse(56,44,5,6,0,0,7);q.fill();q.fillStyle='#7aff7a';q.beginPath();q.arc(40,45,2,0,7);q.arc(56,45,2,0,7);q.fill();q.fillStyle='#0a140a';for(let i=0;i<4;i++)q.fillRect(40+i*5,56,2,6)},
 'อัญเชิญภูตไฟ':(q,S)=>{skBg(q,S,'#8a3a0a','#140602');skFlame(q,48,54,30);skFlame(q,48,58,18,'#ffffff','#ffd060');q.fillStyle='#3a1004';q.beginPath();q.ellipse(41,52,3,4.5,0,0,7);q.ellipse(55,52,3,4.5,0,0,7);q.fill();q.beginPath();q.arc(48,62,4,0,Math.PI);q.fill()},
 'อัญเชิญโกเลมศิลา':(q,S)=>{skBg(q,S,'#5a5a6a','#0a0a10');q.fillStyle='#7a7a86';q.strokeStyle='#1a1a22';q.lineWidth=2;q.beginPath();q.moveTo(26,80);q.lineTo(22,40);q.lineTo(34,22);q.lineTo(62,22);q.lineTo(74,40);q.lineTo(70,80);q.closePath();q.fill();q.stroke();q.strokeStyle='rgba(0,0,0,.35)';q.beginPath();q.moveTo(30,50);q.lineTo(46,58);q.lineTo(40,74);q.moveTo(66,46);q.lineTo(54,62);q.stroke();sglow(q,38,40,8,'120,200,255');sglow(q,58,40,8,'120,200,255');q.fillStyle='#c8f0ff';q.fillRect(35,38,6,4);q.fillRect(55,38,6,4)},
 'ยิงกระจาย':(q,S)=>{skBg(q,S,'#2a6a3a','#04120a');for(let i=0;i<5;i++)skArrow(q,48,60,-Math.PI/2+(i-2)*.32,46);sglow(q,48,70,14,'255,255,200',.5)},
 'ธนูวิญญาณ':(q,S)=>{skBg(q,S,'#3a2a7a','#06041a');sglow(q,48,48,34,'170,150,255',.8);q.globalCompositeOperation='lighter';for(let i=0;i<4;i++){q.globalAlpha=.3;skArrow(q,40-i*6,56+i*6,-.75,50,'#e0d8ff','#a890ff')}q.globalAlpha=1;q.globalCompositeOperation='source-over';skArrow(q,50,46,-.75,54,'#ffffff','#c8b8ff')},
 'ฝนธนู':(q,S)=>{skBg(q,S,'#3a4a5a','#06080c');q.fillStyle='#5a6a7a';q.beginPath();q.ellipse(30,18,20,10,0,0,7);q.ellipse(56,16,24,12,0,0,7);q.ellipse(76,22,14,8,0,0,7);q.fill();for(let i=0;i<7;i++)skArrow(q,16+i*11,44+(i%3)*12,Math.PI/2+.25,26)},
 'ยิงวาปเงา':(q,S)=>{skBg(q,S,'#3a1a5a','#06020c');q.strokeStyle='rgba(180,120,255,.8)';q.lineWidth=4;q.beginPath();q.ellipse(26,58,10,18,.3,0,7);q.stroke();sglow(q,26,58,18,'140,80,255',.6);q.globalAlpha=.4;skArrow(q,40,52,-.5,40,'#c8a8ff','#5a2a8a');q.globalAlpha=1;skArrow(q,58,40,-.5,40,'#ffffff','#7a3ab0')},
 'อัญเชิญเหยี่ยว':(q,S)=>{skBg(q,S,'#6a8ac8','#0a1430');sglow(q,48,44,30,'255,240,200',.5);q.fillStyle='#5a3a1a';q.strokeStyle='#1a0a02';q.lineWidth=1.5;q.beginPath();q.moveTo(48,40);q.bezierCurveTo(30,22,12,26,6,34);q.bezierCurveTo(20,36,30,42,40,50);q.lineTo(48,62);q.lineTo(56,50);q.bezierCurveTo(66,42,76,36,90,34);q.bezierCurveTo(84,26,66,22,48,40);q.fill();q.stroke();q.fillStyle='#f0e8d8';q.beginPath();q.arc(48,40,6,0,7);q.fill();q.fillStyle='#ffc020';q.beginPath();q.moveTo(48,44);q.lineTo(52,47);q.lineTo(48,48);q.fill();q.fillStyle='#000';q.fillRect(46,38,2,2)},
 'ธนูพายุหมุน':(q,S)=>{skBg(q,S,'#2a7a6a','#041410');for(let i=0;i<4;i++){q.strokeStyle='rgba(200,255,240,'+(.7-i*.15)+')';q.lineWidth=3;q.beginPath();q.arc(48,48,10+i*9,i*1.4,i*1.4+3.6);q.stroke()}skArrow(q,48,48,-.8,60,'#ffffff','#2ad0a0')},
 'ฟันหมุน':(q,S)=>{skBg(q,S,'#5a6a7a','#0a0e14');q.strokeStyle='rgba(220,240,255,.8)';q.lineWidth=5;q.beginPath();q.arc(48,48,28,0,5.4);q.stroke();skSword(q,48,48,2.3,40)},
 'ลูกไฟ':(q,S)=>{skBg(q,S,'#6a2a0a','#100402');q.strokeStyle='rgba(255,160,60,.45)';q.lineWidth=10;q.beginPath();q.moveTo(14,80);q.lineTo(52,42);q.stroke();sglow(q,56,38,26,'255,160,40');q.fillStyle='#fff3b0';q.beginPath();q.arc(56,38,10,0,7);q.fill()},
 'เยียวยา':(q,S)=>{skBg(q,S,'#2a8a4a','#041a0a');sglow(q,48,48,34,'140,255,170');q.fillStyle='#f0fff0';q.strokeStyle='#1a5a2a';q.lineWidth=2;q.beginPath();q.rect(40,22,16,52);q.rect(22,40,52,16);q.fill();for(let i=0;i<6;i++){q.fillStyle='rgba(200,255,200,.8)';q.fillRect(16+i*12,76-(i*9)%22,3,3)}}};
function skillIcon(name){if(SKI6[name]!==undefined)return SKI6[name];const fn=SKART[name];if(!fn)return SKI6[name]=null;const c=document.createElement('canvas');c.width=c.height=96;const q=c.getContext('2d');q.lineCap='round';q.lineJoin='round';try{fn(q,96)}catch(e){}
 const v=q.createLinearGradient(0,0,0,96);v.addColorStop(0,'rgba(255,255,255,.12)');v.addColorStop(.4,'rgba(255,255,255,0)');v.addColorStop(1,'rgba(0,0,0,.25)');q.fillStyle=v;q.fillRect(0,0,96,96);return SKI6[name]=c.toDataURL()}
window.skillIcon=skillIcon;
setInterval(()=>{for(const b of document.querySelectorAll('#acts .sk')){const n=b.getAttribute('aria-label'),lock=b.classList.contains('lock'),u=!lock&&n?skillIcon(n):null;const want=u?'url('+u+')':'';if(b._ski!==want){b._ski=want;b.style.backgroundImage=want;b.classList.toggle('hasi',!!u)}}},300);
{const _r=renderSkw;renderSkw=function(){_r();try{for(const c of skwEl.querySelectorAll('.card.sk')){const nm=c.querySelector('b'),e=c.querySelector('.e');if(!nm||!e)continue;const u=skillIcon(nm.textContent.trim());if(u)e.innerHTML='<img src="'+u+'">'}}catch(e){}}}
