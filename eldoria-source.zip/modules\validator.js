// =====================================================================
// validator.js — SystemValidator.runChecks(): ตรวจ ID ในฐานข้อมูล · ไอเท็มซ้ำ · ตารางดรอป · ชั้นดันเจี้ยน · อีเวนต์ · ร้าน · การปิดหน้าต่าง
// =====================================================================
const SystemValidator=(()=>{function runChecks(opt){opt=opt||{};const R={ok:true,checks:0,errors:[],warnings:[],t:Date.now()};const DB=GAME_DATABASE;
 const err=m=>{R.errors.push('❌ '+m)},warn=m=>{R.warnings.push('⚠️ '+m)},chk=(c,m,w)=>{R.checks++;if(!c)(w?warn:err)(m)};
 const isMat=k=>!!(INVMETA[k]||k==='coin'),isItem=k=>!!ITEMS[k];
 try{// มอน
  const ids=new Set();for(const M of DB.MonstersData){chk(!ids.has(M.id),'มอน id ซ้ำ: '+M.id);ids.add(M.id);chk(!!FAM[M.family],'มอน '+M.id+' ใช้รูปร่างที่ไม่มี: '+M.family);chk(!!DB.LootTables[M.dropTableId],'มอน '+M.id+' ไม่มีตารางดรอป '+M.dropTableId);
   const s=M.stats||{};chk(s.hp>0&&s.atk>0&&s.speed>0,'ค่าสเตตัสมอน '+M.id+' ไม่ถูกต้อง');chk(M.colors==='band'||(Array.isArray(M.colors)&&M.colors.length===3),'สีมอน '+M.id+' ต้องมี 3 สี',1)}
  // ตารางดรอป
  for(const id in DB.LootTables)for(const r of DB.LootTables[id].rolls){chk(isMat(r.item),'ตารางดรอป '+id+': ไม่รู้จักของ '+r.item);chk(r.chance>=0&&r.chance<=1&&r.min<=r.max,'ตารางดรอป '+id+': ค่าโอกาส/จำนวนผิด')}
  // ชั้นดันเจี้ยน
  const B=DB.DungeonsData.bands;let exp=1;for(const b of B){chk(b.from===exp,'ช่วงชั้นดันเจี้ยนไม่ต่อเนื่องที่ชั้น '+exp+' (เริ่ม '+b.from+')');exp=b.to+1;for(const id of b.monsterSpawns)chk(ids.has(id),'ชั้น '+b.from+'-'+b.to+': ไม่มีมอน '+id);if(b.bossId)chk(ids.has(b.bossId),'ไม่มีบอส '+b.bossId)}
  chk(exp>DB.DungeonsData.maxFloor||!isFinite(exp),'ช่วงชั้นไม่ครอบคลุมถึงชั้นสูงสุด '+DB.DungeonsData.maxFloor);
  for(const f of [1,10,11,50,99,100,101,150,500,DGMAX7()]){const L=dgMobs7(f,['#999','#444','#fff']);chk(L.length>0,'ชั้น '+f+' ไม่มีมอนเกิด');for(const t of L)chk(!!FAM[t[0]],'ชั้น '+f+': รูปร่าง '+t[0]+' ไม่มี');const I=dgInfo7(f);chk(isFinite(I.hp)&&isFinite(I.atk)&&I.hp>0,'ชั้น '+f+': ค่าสเกลผิด')}
  // อีเวนต์ + ร้าน
  const eids=new Set();for(const E of DB.EventsData){chk(!eids.has(E.eventId),'อีเวนต์ id ซ้ำ: '+E.eventId);eids.add(E.eventId);chk(typeof E.active==='boolean','อีเวนต์ '+E.eventId+' ต้องมี active:true/false');
   for(const S of (E.specialSpawns||[]))chk(ids.has(S.monsterId),'อีเวนต์ '+E.eventId+': ไม่มีมอน '+S.monsterId);if(E.seasonalBossId)chk(ids.has(E.seasonalBossId),'อีเวนต์ '+E.eventId+': ไม่มีบอส '+E.seasonalBossId);if(E.eventShopId)chk(!!DB.ShopsData[E.eventShopId],'อีเวนต์ '+E.eventId+': ไม่มีร้าน '+E.eventShopId);
   for(const k in (E.multiplier||{}))chk(['xp','coin','drop'].includes(k)&&E.multiplier[k]>0,'อีเวนต์ '+E.eventId+': ตัวคูณ '+k+' ไม่รองรับ')}
  for(const sid in DB.ShopsData){const S=DB.ShopsData[sid];chk(!!SHOP_DATA[S.host],'ร้าน '+sid+': ไม่มีร้านหลัก '+S.host);const sids=new Set();for(const it of S.items){chk(!sids.has(it.id),'ร้าน '+sid+': id ซ้ำ '+it.id);sids.add(it.id);chk(it.give&&(it.give.item?isItem(it.give.item):isMat(it.give.mat)),'ร้าน '+sid+': ของที่ให้ไม่ถูกต้อง '+it.id);for(const k in (it.cost||{}))chk(isMat(k),'ร้าน '+sid+': ไม่รู้จักวัตถุดิบ '+k)}}
  for(const X of DB.ItemsExtra){chk(!!ITEMS[X.base],'ไอเท็มเพิ่ม '+X.id+': ไม่มีไอเท็มต้นแบบ '+X.base);chk(!!ITEMS[X.id],'ไอเท็มเพิ่ม '+X.id+' ลงทะเบียนไม่สำเร็จ')}
  // ไอเท็มซ้ำ (ใช้ตัวตรวจเดิม)
  if(typeof validateItemDB7==='function'){const V=validateItemDB7();R.checks+=V.items+V.mats;for(const s of V.dupNames)err('ชื่อไอเท็มซ้ำ: '+s);for(const s of V.dupIcons)warn('ไอคอนซ้ำ (ต่างชื่อ): '+s);for(const s of V.dupStats)warn('ค่าสเตตัสซ้ำ (ต่างชื่อ): '+s);for(const s of V.missing)err('ข้อมูลไอเท็มขาด: '+s)}
  // ระบบหลัก
  chk(typeof EventBus.emit==='function'&&EventBus.count()>0,'EventBus ไม่มีผู้ฟัง');chk(Hooks.count('xp')>0,'Hooks xp ไม่ทำงาน');chk(!!document.getElementById('lsm7')||true,'LoadingScreen');
  for(const f of ['isCasting','isInteracting','isEquipping','inTransition'])chk(PSTATE[f]===false||opt.live,'สถานะ '+f+' ค้างเป็น true',1);
  // การปิดหน้าต่าง (เรียกเมื่อสั่ง เพราะจะปิดหน้าต่างที่เปิดอยู่)
  if(opt.ui&&typeof validateUI7==='function')for(const [n,res] of validateUI7())chk(res==='ok','UI: '+n+' → '+res)}
 catch(e){err('ตัวตรวจทำงานผิดพลาด: '+e.message)}
 R.ok=!R.errors.length;window.SV_LAST=R;try{EventBus.emit(EV.VALIDATED,R)}catch(e){}return R}
 // ตรวจอัตโนมัติหลังโหลดเกม (ไม่แตะหน้าต่าง)
 setTimeout(()=>{const R=runChecks();console[R.ok?'log':'warn']('[SystemValidator] '+(R.ok?'OK':'FAIL')+' checks='+R.checks+' errors='+R.errors.length+' warnings='+R.warnings.length,R.errors)},3000);
 return {runChecks}})();
window.SystemValidator=SystemValidator;
Eldoria.register('validator',{run:o=>SystemValidator.runChecks(o)});

// =====================================================================
// QA BOT — SystemValidator.runFullGamePlaytest()
// เล่นเกมอัตโนมัติ: วาปทุกแผนที่/ชั้นดันเจี้ยน · เดินสุ่ม 360° ชนสิ่งกีดขวาง · ร่ายทุกสกิลใกล้กำแพง (ตรวจ LOS) · อัญเชิญรัว
// · คุยกับ NPC ทุกตัว · ทดสอบสาวเสิร์ฟ · ส่งเควส/แลกของ/คราฟ/ตีบวก · เปิด-ปิด UI รัว ๆ · บันทึกบั๊กพร้อมโมดูล/พิกัด/สถานะ
// ระหว่างรัน: ปิดการเซฟทั้งหมด (ไม่แตะเซฟจริง) · จบแล้วกด "โหลดเกมใหม่" เพื่อคืนสถานะเดิม
// =====================================================================
SystemValidator.runFullGamePlaytest=async function(opt){opt=Object.assign({floors:'sample',moveSteps:360,uiCycles:25,onProgress:null},opt||{});
 const t0=performance.now(),BUGS=[],seen=new Set(),ST={scenes:0,floors:0,steps:0,skills:0,npcs:0,ui:0,checks:0};
 const sleep=ms=>new Promise(r=>setTimeout(r,ms)),frame=()=>new Promise(r=>requestAnimationFrame(()=>r()));
 const scene=()=>!D?'field':D.town?'town':D.shop?'shop:'+D.shop:D.home?'home':D.dg?'dg:'+D.dg:D.zone?'zone:'+(D.zone.Zd&&D.zone.Zd.id):'?';
 const tileOf=(x,y)=>[Math.floor(x/T),Math.floor(y/T)];
 function bug(module,type,detail,o){o=o||{};const x=Math.round(o.x!=null?o.x:P.x),y=Math.round(o.y!=null?o.y:P.y),key=module+'|'+type+'|'+scene().replace(/^dg:\d+/,'dg')+'|'+(o.key||Math.floor(x/T)+','+Math.floor(y/T));
  if(seen.has(key))return;seen.add(key);BUGS.push({module,type,scene:scene(),x,y,tile:tileOf(x,y),detail,state:{dir:P.dir,cls:P.cls,lv:P.lv,hp:Math.round(P.hp),stun:+(P.stun||0).toFixed(2),flags:Object.assign({},PSTATE),paused:PAUSED,ui:{bag:!bagEl.hidden,shop:!shopEl.hidden,dlg:!!DLG.open}},sev:o.sev||'major'})}
 const toField=()=>{try{if(D&&D.shop)leaveShop(true)}catch(e){}try{if(D)exitD()}catch(e){}};const prog=m=>{try{opt.onProgress&&opt.onProgress(m)}catch(e){}};
 // จุดชนแบบคงที่ (ไม่นับ NPC ที่เดินมาชน)
 function staticHit(x,y){if(!hit(x,y))return false;if(!D||!D.npcs)return true;const sv=D.npcs.map(n=>[n,n.x,n.y]);for(const [n] of sv){n.x+=1e5}try{return hit(x,y)}finally{for(const [n,a,b] of sv){n.x=a;n.y=b}}}
 // ปิดการเซฟระหว่างทดสอบ
 const SP=Storage.prototype,_set=SP.setItem;SP.setItem=function(k,v){if(/fm_|eldoria/.test(String(k)))return;return _set.call(this,k,v)};
 const svGod=(typeof GM7!=='undefined')?GM7.god:null;try{if(typeof GM7!=='undefined')GM7.god=true}catch(e){}
 const closeAll=()=>{for(const f of [()=>dlgClose(true),()=>hideBag(),()=>icClose(),()=>{if(SHOPK)closeShop()},()=>{if(STN.open)closeForge()},()=>{chp.hidden=true},()=>{if(!skwEl.hidden)closeSkw()},()=>{menuEl.hidden=true},()=>{for(const w of document.querySelectorAll('.p6w'))w.hidden=true},()=>{if(typeof closeEnh7==='function'&&ENHS.open)closeEnh7()},()=>{shopEl.hidden=true;CM.open=false;GM.open=false;ZM.open=false}])try{f()}catch(e){}PAUSED=false};
 async function fuzzMove(n,label){let a=Math.random()*6.283;for(let i=0;i<n;i++){if(i%18===0)a=Math.random()*6.283;const sp=3.2;
   try{moveSlide(Math.cos(a)*sp,Math.sin(a)*sp)}catch(e){bug('core','moveSlide-error',e.message);return}ST.steps++;ST.checks++;
   if(!isFinite(P.x)||!isFinite(P.y)){bug('player','position-NaN','ตำแหน่งผู้เล่นเป็น NaN หลังเดิน');P.x=P.y=100;return}
   if(staticHit(P.x,P.y))bug('player','collider-penetration','ผู้เล่นทะลุเข้าไปในสิ่งกีดขวาง ('+label+')');
   if(i%24===0){await frame();checkActors(label)}}}
 function checkActors(label){if(!D)return;try{if(D.npcs)for(const n of D.npcs){if(n.vis===false||n.fixed)continue;ST.checks++;let bad=false;const tx=Math.floor(n.x/T),ty=Math.floor(n.y/T);bad=!dm[ty]||(dm[ty][tx]!==FL&&dm[ty][tx]!==GATE);if(bad)bug('ui','npc-in-wall','NPC "'+n.name+'" ยืนในช่องทึบ',{x:n.x,y:n.y,key:'npc:'+n.name,sev:'minor'})}
   if(D.zone&&D.mobs)for(const m of D.mobs){if(m.dead||(m.F&&m.F.fly))continue;ST.checks++;if(!isFinite(m.x)||!isFinite(m.y)){bug('monsters','mob-NaN',m.nm+' พิกัด NaN',{key:'nan:'+m.nm});continue}if(zHit(m.x,m.y))bug('monsters','mob-in-obstacle',m.nm+' ติดในกำแพง/แร่',{x:m.x,y:m.y,sev:'minor'})}}catch(e){}}
 // ---------- 1) แผนที่ทั้งหมด ----------
 prog('แผนที่');closeAll();
 const scenes=[['field',()=>toField()],['town',()=>{enterTown(1)}]];
 for(const id of Object.keys(SHOP_DATA)){if(/^st_/.test(id))continue;scenes.push(['shop:'+id,()=>{enterTown(1);enterShop(id)}])}
 ZONES.forEach((z,i)=>{if(z&&i<200&&!z.dg)scenes.push(['zone:'+z.id,()=>enterZone(i)])});
 scenes.push(['home',()=>{const u=HOME.unlocked;HOME.unlocked=1;enterHome();HOME.unlocked=u}]);
 for(const [nm,go] of scenes){try{go()}catch(e){bug('dungeons','scene-load-error','โหลดฉาก '+nm+' ไม่ได้: '+e.message,{key:nm});continue}ST.scenes++;await frame();
  if(staticHit(P.x,P.y))bug('player','spawn-in-collider','จุดเกิดในฉาก '+nm+' อยู่ในสิ่งกีดขวาง');await fuzzMove(nm==='field'?opt.moveSteps*2:opt.moveSteps,nm)}
 // ดันเจี้ยน
 const maxF=DGMAX7(),floors=opt.floors==='all'?Array.from({length:maxF},(_,i)=>i+1):[...new Set([1,2,3,5,10,11,20,21,30,31,50,60,61,85,86,99,100,101,102,120,121,150,200,333,500,750,998,maxF])].filter(f=>f<=maxF);
 for(const f of floors){try{toField();enterDg(f)}catch(e){bug('dungeons','floor-gen-error','สร้างชั้น '+f+' ไม่ได้: '+e.message,{key:'f'+f});continue}ST.floors++;
  if(!(D&&D.dg===f)){bug('dungeons','floor-not-entered','เข้าชั้น '+f+' ไม่สำเร็จ',{key:'f'+f});continue}
  const ms=D.mobs.filter(m=>!m.dead&&!m.boss);if(!ms.length)bug('dungeons','floor-empty','ชั้น '+f+' ไม่มีมอน',{key:'fe'+f});
  if(ms.some(m=>!isFinite(m.hp)||!isFinite(m.atk)||m.hp<=0))bug('dungeons','floor-bad-stats','ชั้น '+f+' ค่ามอนผิด (NaN/0)',{key:'fs'+f});
  if(staticHit(P.x,P.y))bug('dungeons','floor-spawn-in-wall','จุดเกิดชั้น '+f+' อยู่ในกำแพง',{key:'fw'+f});
  const a=D.zone.arena;if(!a||D.zone.m[a.y][a.x]!==FL)bug('dungeons','boss-arena-blocked','ห้องบอสชั้น '+f+' ไม่มีพื้นที่ยืน',{key:'fa'+f});
  checkActors('dg'+f);if(f%50===1||floors.length<60)await fuzzMove(120,'dg'+f);if(ST.floors%25===0){prog('ดันเจี้ยน '+f);await frame()}}
 toField();
 // ---------- 2) สกิล & LOS ----------
 prog('สกิล');
 function wallSpot(){const Zm=D.zone,m=Zm.m;for(let k=0;k<4000;k++){const x=3+Math.floor(Math.random()*(ZW-8)),y=3+Math.floor(Math.random()*(ZH-6));
   if(m[y][x]!==FL||m[y][x+1]===FL||zHit(x*T+16,y*T+16))continue;let w=1;while(w<4&&m[y][x+w]!==FL)w++;if(w>=4||w<2&&m[y][x+2]!==FL)continue;if(m[y][x+w]===FL&&m[y][x+w+1]===FL&&!zHit((x+w)*T+16,y*T+16))return [x,y,w]}return null}
 const W={sword:'sword3',mage:'staff1',archer:'bow1'};
 for(const cls of ['sword','mage','archer']){try{gmCls(cls);gmA('lv99');gmWpn(W[cls]&&ITEMS[W[cls]]?W[cls]:Object.keys(ITEMS).find(k=>ITEMS[k].kind===NEEDW[cls]));closeAll()}catch(e){bug('skills','class-setup',cls+': '+e.message,{key:cls});continue}
  for(const where of ['zone','dungeon']){try{toField();if(where==='zone')enterZone(1);else enterDg(40)}catch(e){continue}await frame();D.mobs.length=0;D.spT=1e9;D.bossT=1e9;
   const L=CSKILLS[cls]||[];for(let i=0;i<=L.length;i++){let ws=null;for(let r=0;r<4&&!ws;r++)ws=wallSpot();if(!ws){bug('skills','no-wall-spot','หาจุดทดสอบกำแพงไม่ได้',{key:'ws'+where});break}
    const [wx,wy,ww]=ws;P.x=wx*T+16;P.y=wy*T+16;P.dir='r';P.stun=0;P.mp=BAL.mp;CS.cd=[0,0,0];CS.step=0;MIN.length=0;
    const dm7=mkMob('skeleton','หุ่นทดสอบ QA',['#888','#444','#fff'],10,(wx+ww)*T+16,wy*T+16,{});dm7.hp=dm7.max=1e7;dm7.F=Object.assign({},dm7.F,{spd:0,range:0});dm7.qa=1;D.mobs.push(dm7);
    const x0=P.x,y0=P.y,nm=i<L.length?L[i].n:'อัลติเมท';ST.skills++;
    try{if(i<L.length)useSkill(i);else{ULT.v=100;castUlt()}}catch(e){bug('skills','cast-throw',nm+': '+e.message,{key:'ct'+cls+i})}
    for(let k=0;k<(i<L.length?40:110);k++){await frame();if(staticHit(P.x,P.y)){bug('skills','warp-into-wall',nm+' ทำให้ผู้เล่นเข้าไปในกำแพง',{key:'wi'+cls+i+where});break}}
    if(P.x>(wx+1)*T+20)bug('skills','warp-through-wall',nm+' วาป/พุ่งทะลุกำแพงไปอีกฝั่ง',{key:'wt'+cls+i+where,x:P.x,y:P.y});
    if(dm7.hp<dm7.max)bug('skills','damage-through-wall',nm+' ทำดาเมจทะลุกำแพง ('+Math.round(dm7.max-dm7.hp)+')',{key:'dt'+cls+i+where,x:dm7.x,y:dm7.y});
    if(PSTATE.isCasting)bug('skills','cast-state-stuck',nm+' ค้างสถานะ isCasting',{key:'cs'+cls+i});await sleep(60);if(P.stun>2)bug('skills','stun-stuck',nm+' สตันค้าง '+P.stun.toFixed(1)+' วิ',{key:'st'+cls+i});
    D.mobs=D.mobs.filter(m=>m!==dm7);for(const p of (typeof SK!=='undefined'?SK.balls||[]:[]))p.l=0;try{ULT.cast=null;ULT.fx.length=0;FLK.on=false;P.jump=null}catch(e){}}}}
 // ---------- 3) อัญเชิญรัว ----------
 prog('อัญเชิญ');try{gmCls('mage');gmWpn(W.mage&&ITEMS[W.mage]?W.mage:'staff0');closeAll();for(const where of ['field','zone']){toField();if(where!=='field')enterZone(0);await frame();MIN.length=0;
  const i=(CSKILLS.mage||[]).findIndex(s=>/โครงกระดูก/.test(s.n));if(i<0){bug('skills','no-summon-skill','ไม่พบสกิลอัญเชิญ',{key:'ns'});break}
  for(let k=0;k<20;k++){CS.cd[i]=0;P.mp=BAL.mp;P.stun=0;useSkill(i);await sleep(25)}await sleep(350);ST.skills+=20;
  const sk=MIN.filter(m=>m.k==='skel');if(sk.length>3)bug('skills','summon-over-cap','อัญเชิญเกินจำกัด: '+sk.length+' ตัว',{key:'cap'+where});if(PSTATE.isCasting)bug('skills','summon-state-stuck','isCasting ค้างหลังอัญเชิญรัว',{key:'sst'+where});
  if(P.stun>0.05)bug('skills','summon-stun-stuck','สตันไม่ถูกปล่อยหลังอัญเชิญ ('+P.stun.toFixed(2)+')',{key:'sss'+where});if(sk.some(m=>!isFinite(m.x)))bug('skills','summon-NaN','มินเนียนพิกัด NaN',{key:'sn'+where});
  const p0=sk.map(m=>[m.x,m.y]);P.x+=90;await sleep(900);if(sk.length&&!sk.some((m,j)=>Math.hypot(m.x-p0[j][0],m.y-p0[j][1])>8))bug('skills','summon-frozen','มินเนียนไม่ขยับ (ค้าง) ใน'+where,{key:'sf'+where})}}catch(e){bug('skills','summon-test-error',e.message,{key:'ste'})}
 // ---------- 4) NPC / บทสนทนา / ระบบในเมือง ----------
 prog('NPC');closeAll();try{toField();enterTown(1);await frame();for(const n of D.npcs.slice()){if(n.vis===false)continue;ST.npcs++;P.x=n.x;P.y=n.y+26;P.dir='u';if(staticHit(P.x,P.y)){P.y=n.y-26;P.dir='d'}if(staticHit(P.x,P.y)){unstick()}
   const b0=n.bub;n.bub=null;let ok=false;try{ok=interact()}catch(e){bug('ui','npc-interact-error','คุยกับ '+n.name+' แล้วพัง: '+e.message,{key:'ni'+n.name})}await frame();
   if(!ok&&!n.bub&&!DLG.open&&shopEl.hidden)bug('ui','npc-no-response','คุยกับ "'+n.name+'" ไม่ตอบสนอง (ยืนหน้า NPC กด E)',{x:n.x,y:n.y,key:'nr'+n.name,sev:'minor'});closeAll()}}catch(e){bug('ui','npc-test-error',e.message,{key:'nte'})}
 // ร้านค้า
 for(const id of Object.keys(SHOP_DATA)){if(/^st_/.test(id))continue;try{enterTown(1);enterShop(id);const o=D.owner;if(!o)continue;P.x=o.x;P.y=o.y+(id==='hall'?70:46);P.dir='u';await frame();const ok=interact();await frame();
   if(!ok&&!DLG.open&&shopEl.hidden&&!(typeof SHOPK!=='undefined'&&SHOPK))bug('ui','shop-no-response','เจ้าของร้าน '+id+' ไม่ตอบสนอง',{key:'sh'+id});closeAll()}catch(e){bug('ui','shop-error','ร้าน '+id+': '+e.message,{key:'she'+id})}}
 // สาวเสิร์ฟ
 try{enterTown(1);enterShop('inn');const o=D.owner;P.x=o.x;P.y=o.y+60;inv.coin+=999;innPick(INNMENU[0]);let clip=0,steps=0;const t1=performance.now();
  while(performance.now()-t1<16000){await sleep(50);const w=INN6.w;if(w&&w.vis){steps++;for(const tb of TABLES){if(Math.abs(w.x-tb.x)<36&&w.y>tb.y-14&&w.y<tb.y+12){clip++;bug('ui','waiter-table-clip','สาวเสิร์ฟเดินทับโต๊ะ ('+INN6.st+')',{x:w.x,y:w.y})}}}if(!INN6.st)break;if(INN6.st==='eat')P.sit=P.sit}
  if(INN6.st&&INN6.st!=='eat'&&INN6.st!=='back2')bug('ui','waiter-stuck','สาวเสิร์ฟค้างที่สถานะ '+INN6.st,{key:'ws'});closeAll();leaveShop()}catch(e){bug('ui','waiter-test-error',e.message,{key:'wte'})}
 // เควส / แลกของ / คราฟ / ตีบวก
 try{enterTown(1);qRefresh(1);QST.act.length=0;qTake(0);const q=QST.act[0];if(q.t==='item')inv[q.k]=(inv[q.k]|0)+q.n;else q.c=q.n;const c0=inv.coin;qClaim(0);if(QST.act.includes(q)||inv.coin<=c0)bug('ui','quest-claim-failed','ส่งเควสกิลด์ไม่สำเร็จ',{key:'qc'});closeAll()}catch(e){bug('ui','quest-error',e.message,{key:'qe'})}
 try{enterShop('gear');SMITH.u=0;SMITH.q=1;for(const [k,v] of Object.entries(SMQ[1].need))inv[k]=(inv[k]|0)+v;P.lv=Math.max(P.lv,SMQ[1].lv);smithDeliver7(1);if(SMITH.u!==1)bug('ui','smith-exchange-failed','แลกตำราช่างไม่สำเร็จ',{key:'se'});closeAll()}catch(e){bug('ui','smith-error',e.message,{key:'see'})}
 try{const id=Object.keys(ITEMS).find(k=>ITEMS[k].kind==='helm'&&ITEMS[k].tier===1)||'helm1';inv.ingot=(inv.ingot|0)+20;inv.wood=(inv.wood|0)+20;inv.ingSt=(inv.ingSt|0)+20;const g0=GEAR[id]|0;SMITH.u=Math.max(SMITH.u,1);
  P.x=CB7.x;P.y=CB7.y+26;craftGear(id);if((GEAR[id]|0)<=g0)bug('ui','craft-failed','คราฟ '+ITEMS[id].name+' ไม่สำเร็จ (มีวัตถุดิบพอ)',{key:'cf',sev:'minor'});closeAll()}catch(e){bug('ui','craft-error',e.message,{key:'cfe'})}
 try{try{localStorage.getItem('fm_enhtut7')}catch(e){}const id=Object.keys(ITEMS).find(k=>ITEMS[k].kind==='helm'&&ITEMS[k].tier===1)||'helm1';GEAR[id]=Math.max(1,GEAR[id]|0);inv.estone=(inv.estone|0)+50;inv.ingot=(inv.ingot|0)+50;inv.ingSt=(inv.ingSt|0)+50;inv.coin+=99999;P.x=ANV7.x-26;P.y=ANV7.y+4;
  ENHS.open=true;ENHS.sel=id;const l0=ENH[id]|0;enhStart7();const t1=performance.now();while((FRG.on||ENHS.busy)&&performance.now()-t1<8000)await sleep(100);
  if(FRG.on||ENHS.busy)bug('ui','enhance-stuck','ตีบวกค้าง (busy)',{key:'eb'});if((ENH[id]|0)===l0&&!ENHS.res)bug('ui','enhance-no-result','ตีบวกไม่มีผลลัพธ์: '+(ENHS.msg||'-'),{key:'en',sev:'minor'});closeAll();leaveShop()}catch(e){bug('ui','enhance-error',e.message,{key:'ee'})}
 // ---------- 5) UI stress ----------
 prog('UI');try{toField();enterTown(1);await frame();const ops=[[()=>{bagEl.hidden=false;renderBag()},()=>hideBag()],[()=>openChar(),()=>{chp.hidden=true}],[()=>openSkw('sk'),()=>closeSkw()],[()=>openShop('potion'),()=>closeShop()],
   [()=>gid('qbtn7')&&gid('qbtn7').click(),()=>gid('qbtn7')&&gid('qbtn7').click()],[()=>LoadingScreenManager.cover({title:'QA'},()=>{}),()=>{}],[()=>{menuEl.hidden=false},()=>{menuEl.hidden=true}],[()=>openDgMenu(),()=>closeZMenu()],[()=>icShow('mat','estone'),()=>icClose()]];
  for(let c=0;c<opt.uiCycles;c++){for(const [o,cl] of ops.sort(()=>Math.random()-.5)){ST.ui++;try{o()}catch(e){bug('ui','ui-open-error',e.message,{key:'uo'+String(o).slice(6,40)})}if(Math.random()<.5)await frame();try{cl()}catch(e){bug('ui','ui-close-error',e.message,{key:'uc'+String(cl).slice(6,40)})}}}
  closeAll();await sleep(900);const open=[['bag',!bagEl.hidden],['char',!chp.hidden],['skillbook',!skwEl.hidden],['shop',!shopEl.hidden],['menu',!menuEl.hidden],['loading',LoadingScreenManager.el.classList.contains('on')],['icard',!icEl.hidden],['dialog',!!DLG.open]].filter(q=>q[1]).map(q=>q[0]);
  if(open.length)bug('ui','overlay-not-closed','หน้าต่างค้างหลังเปิด-ปิดรัว: '+open.join(', '),{key:'oc'});
  for(const f of ['isCasting','isInteracting','isEquipping','inTransition'])if(PSTATE[f])bug('core','state-lock','สถานะ '+f+' ค้างเป็น true',{key:'sl'+f});
  if(PAUSED)bug('core','paused-lock','เกมค้าง PAUSED หลังปิดทุกหน้าต่าง',{key:'pl'});
  // ทดสอบว่าปุ่มเดินยังใช้ได้
  const x0=P.x,y0=P.y;dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowLeft'}));await sleep(350);dispatchEvent(new KeyboardEvent('keyup',{key:'ArrowLeft'}));dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowDown'}));await sleep(350);dispatchEvent(new KeyboardEvent('keyup',{key:'ArrowDown'}));
  if(Math.hypot(P.x-x0,P.y-y0)<4)bug('core','input-locked','กดปุ่มเดินแล้วตัวละครไม่ขยับ (input ถูกล็อก)',{key:'il'})}catch(e){bug('ui','ui-test-error',e.message,{key:'ute'})}
 // ---------- จบ ----------
 SP.setItem=_set;try{if(svGod!==null)GM7.god=svGod}catch(e){}closeAll();
 const R={bugs:BUGS,stats:Object.assign(ST,{ms:Math.round(performance.now()-t0)}),byModule:BUGS.reduce((a,b)=>{a[b.module]=(a[b.module]||0)+1;return a},{}),byType:BUGS.reduce((a,b)=>{a[b.type]=(a[b.type]||0)+1;return a},{})};
 window.QA_LAST=R;try{sessionStorage.setItem('qa7_last',JSON.stringify({stats:R.stats,byType:R.byType,bugs:BUGS.slice(0,300)}))}catch(e){}EventBus.emit(EV.VALIDATED,{qa:true,count:BUGS.length});prog('เสร็จ');return R};
