// =====================================================================
// ui.js — ห่อการเปิด/ปิดหน้าต่างด้วย Guard (isInteracting) · ส่ง UI_OPEN/UI_CLOSE · ป้ายอีเวนต์บน HUD · ร้านอีเวนต์ · แผง GM
// =====================================================================
(()=>{
 const W=(name,kind)=>{const f=window[name]||(MOD7.ui[name]&&MOD7.ui[name]());if(typeof f!=='function')return;const g=function(){const a=arguments,self=this;return Guard.run('ui.'+name,()=>{const r=f.apply(self,a);EventBus.emit(kind,{ui:name,arg:a[0]});return r},'isInteracting')};
  try{switch(name){case 'openShop':openShop=g;break;case 'closeShop':closeShop=g;break;case 'openForge':openForge=g;break;case 'closeForge':closeForge=g;break;case 'openChar':openChar=g;break;case 'openGuild':openGuild=g;break;case 'openClassMenu':openClassMenu=g;break;case 'icShow':icShow=g;break;case 'talk':talk=g;break;case 'dlgClose':dlgClose=g;break}}catch(e){}window[name]=g};
 for(const n of ['openShop','openForge','openChar','openGuild','openClassMenu','icShow','talk'])W(n,EV.UI_OPEN);
 for(const n of ['closeShop','closeForge','dlgClose'])W(n,EV.UI_CLOSE);
 {const _it=interact;interact=function(){return Guard.run('interact',()=>_it.apply(this,arguments),'isInteracting')};window.interact=interact}

 // ป้ายอีเวนต์บน HUD
 const st=document.createElement('style');st.textContent='#evb7{position:absolute;left:50%;top:calc(34px + var(--st,0px));transform:translateX(-50%);z-index:4;display:flex;gap:5px;pointer-events:none}#evb7[hidden]{display:none}#evb7 span{font:800 11px system-ui;color:#2a1406;background:linear-gradient(180deg,#ffe9a0,#e8b84a);border:1.5px solid #fff2c0;border-radius:10px;padding:2px 8px;box-shadow:0 2px 6px rgba(0,0,0,.5);animation:evb7 2s ease-in-out infinite}@keyframes evb7{50%{filter:brightness(1.15)}}';document.head.appendChild(st);
 const bar=document.createElement('div');bar.id='evb7';bar.hidden=true;(gid('wrap')||document.body).appendChild(bar);
 const paint=()=>Guard.run('evBadge',()=>{const L=EventSystem.active();bar.hidden=!L.length;bar.innerHTML=L.map(e=>'<span>'+(e.icon||'🎉')+' '+e.name+'</span>').join('')});
 EventBus.on(EV.EVENT_STARTED,d=>{paint();if(!d.boot){sysSay('🎉 อีเวนต์เริ่มแล้ว: '+(d.icon||'')+' '+d.name);try{chatAnn('อีเวนต์ '+d.name+' เริ่มแล้ว!')}catch(e){}}},'ui.evb');EventBus.on(EV.EVENT_ENDED,d=>{paint();sysSay('อีเวนต์ '+d.name+' จบแล้ว')},'ui.evb');setTimeout(paint,600);

 // ร้านอีเวนต์: ของจะขึ้นในร้านที่กำหนด (host) เฉพาะตอนอีเวนต์เปิด
 const DB=GAME_DATABASE;const evShopItems=host=>{const L=[];for(const E of EventSystem.active()){const S=E.eventShopId&&DB.ShopsData[E.eventShopId];if(!S||S.host!==host)continue;for(const it of S.items){const cost=Object.entries(it.cost||{}).map(([k,v])=>MN(k)+' '+v).join(' + ');L.push({id:it.id,name:'🎪 '+it.name,emoji:'🎪',price:it.price||0,item:it.give.item,mat:it.give.mat,note:it.note+(cost?' · ใช้ '+cost:''),ev7:it})}}return L};
 for(const host of new Set(Object.values(DB.ShopsData).map(s=>s.host))){const S=SHOP_DATA[host];if(!S)continue;const d=Object.getOwnPropertyDescriptor(S,'buy');let base=d&&('value' in d)?d.value:null;const g0=d&&d.get;
  Object.defineProperty(S,'buy',{configurable:true,get(){const b=g0?g0.call(this):base||[];const ev=evShopItems(host);return ev.length?b.concat(ev):b},set(v){base=v}})}
 {const _bi=buyItem;buyItem=function(id){let it=null;for(const S of Object.values(DB.ShopsData)){const q=S.items.find(x=>x.id===id);if(q){it=q;break}}if(!it)return _bi(id);
  return Guard.run('eventBuy',()=>{const ev=Object.values(DB.ShopsData).find(S=>S.items.includes(it));const on=EventSystem.active().some(E=>E.eventShopId&&DB.ShopsData[E.eventShopId]===ev);if(!on){say('อีเวนต์นี้จบแล้ว');return}
   for(const [k,v] of Object.entries(it.cost||{}))if((inv[k]|0)<v){say('ไม่พอ: '+MN(k)+' '+(inv[k]|0)+'/'+v);sfx('thud');return}if(inv.coin<(it.price||0)){say('เหรียญไม่พอ');sfx('thud');return}
   if(it.give.item){const c=canTakeGear(it.give.item);if(c!==true){noRoom(c);return}}else{const c=canTake(it.give.mat);if(c!==true){noRoom(c);return}}
   for(const [k,v] of Object.entries(it.cost||{}))inv[k]-=v;inv.coin-=it.price||0;if(it.give.item)GEAR[it.give.item]=(GEAR[it.give.item]|0)+1;else inv[it.give.mat]=(inv[it.give.mat]|0)+1;
   refreshInv();sfx('gem');say('🎪 ได้ '+it.name+' แล้ว!');try{handIn7(['🎪'],-1)}catch(e){}if(SHOPK)renderShop()})}}

 // แผง GM: อีเวนต์ / ตัวตรวจระบบ / ชั้นไม่สิ้นสุด
 {const _gr=gmRender;gmRender=function(){_gr();Guard.run('gmArch',()=>{const bd=gmW.querySelector('.bd');if(!bd)return;const B=(t,on,c)=>'<button class="bt'+(c?' '+c:'')+'" onclick="'+on+'">'+t+'</button>';
   bd.insertAdjacentHTML('beforeend','<div class="card"><b style="color:#ffe9a0">อีเวนต์ (EventSystem) · สถาปัตยกรรม v4.8</b><div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:6px">'
    +EventSystem.list().map(e=>B((e.active?'✅ ':'⬜ ')+e.icon+' '+e.name,"gmEv7('"+e.eventId+"')",e.active?'g':'')).join('')
    +B('🧪 SystemValidator',"gmSV7()")+B('🤖 QA Bot เล่นทั้งเกม',"gmQA7()",'r')+B('🌌 ชั้น 101',"p6close(gid('gmw'));dgGo7(101)")+B('🌌 ชั้น 150',"p6close(gid('gmw'));dgGo7(150)")+'</div><div id="gmsv7" style="font-size:11px;white-space:pre-wrap;margin-top:6px;max-height:160px;overflow:auto"></div></div>')})}}
 window.gmEv7=id=>{EventSystem.setActive(id,!EventSystem.isActive(id));try{gmRender()}catch(e){}};
 window.gmSV7=()=>{const R=SystemValidator.runChecks({ui:true});const el=gid('gmsv7');if(el)el.textContent=(R.ok?'✅ ผ่านทั้งหมด':'⚠️ พบปัญหา')+' · ตรวจ '+R.checks+' รายการ · ผิดพลาด '+R.errors.length+' · เตือน '+R.warnings.length+'\n'+R.errors.concat(R.warnings).join('\n');say(R.ok?'🧪 SystemValidator ผ่าน':'🧪 พบปัญหา '+R.errors.length+' รายการ')};
 Eldoria.register('ui',{loading:LoadingScreenManager});
})();
// แหล่งที่มาของของจากฐานข้อมูล (ไอเท็มอีเวนต์ / ตารางดรอปมอนใหม่)
{const _s=src7;src7=function(key){const DB=GAME_DATABASE;const id=String(key||'').replace(/^(item|mat):/,'');const out=[];
 try{for(const sid in DB.ShopsData){const S=DB.ShopsData[sid];if(S.items.some(it=>(it.give.item||it.give.mat)===id)){const E=DB.EventsData.find(e=>e.eventShopId===sid);out.push(['🎪',S.name+(E?' (ช่วงอีเวนต์ '+E.name+')':'')])}}
  for(const M of DB.MonstersData){const T=DB.LootTables[M.dropTableId];if(T&&T.rolls.some(r=>r.item===id))out.push(['👾',M.name+(M.eventOnly?' (อีเวนต์)':M.floors?' (ดันเจี้ยนชั้น '+M.floors[0]+'+)':'')])}}catch(e){}
 if(ITEMS[id]&&ITEMS[id].extra7)return out.length?out:[['🎪','ไอเท็มพิเศษ']];return out.concat(_s(key))}}

window.gmQA7=async()=>{const el=gid('gmsv7');if(!confirm7('QA Bot จะวาป/ปรับเลเวล/ให้ของเพื่อทดสอบ (ไม่เซฟลงเครื่อง) จบแล้วต้องโหลดเกมใหม่ เริ่มเลยไหม?'))return;
 p6close(gid('gmw'));const R=await SystemValidator.runFullGamePlaytest({onProgress:m=>say('🤖 QA: '+m)});
 p6open(gid('gmw'));gmRender();const e2=gid('gmsv7');if(e2)e2.innerHTML='<b>🤖 QA เสร็จ '+Math.round(R.stats.ms/1000)+' วิ · ฉาก '+R.stats.scenes+' · ชั้น '+R.stats.floors+' · ก้าว '+R.stats.steps+' · สกิล '+R.stats.skills+' · NPC '+R.stats.npcs+' · UI '+R.stats.ui+' · พบบั๊ก '+R.bugs.length+'</b>\n'+R.bugs.map(b=>'['+b.module+'] '+b.type+' @'+b.scene+' ('+b.x+','+b.y+') '+b.detail).join('\n')+'\n<button class="bt" onclick="location.reload()">🔄 โหลดเกมใหม่ (คืนสถานะเดิม)</button>'};
function confirm7(t){try{return window.confirm(t)}catch(e){return true}}
