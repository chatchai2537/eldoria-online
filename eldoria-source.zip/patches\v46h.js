
// =====================================================================
// v4.7 (ซ) : คฑา (STAFF) + ธนู (BOW) — ถือจริง · ร่ายเวท/ง้างยิง ทั้งตัว · ธนู+กระบอกลูกธนูบนหลัง 4 ทิศ
// ใช้แนวคิดเดียวกับดาบ (เตรียม → ทำ → ปะทะ/ปล่อย → follow-through → คืนตัว) — ไม่แตะดาบ/ขวาน/hitbox/damage/input
// ทำงานเฉพาะเมื่อสวม คฑา/ธนู (isRng) เท่านั้น
// =====================================================================
const rgOn7=()=>P.tool==='sword'&&P.draw&&isRng()&&!P.dead;
window.RNGARM7=()=>(P.tool==='sword'&&P.at>=0&&isRng())||!!window.FRG7on;   // ซ่อนแขนเดิมตอนร่าย/ยิง (เราวาดแขน 2 ท่อนเอง กันเป็น 3 แขน)
window.RNGHOLD7=()=>isRng();                              // หันข้าง: ถือคฑา/ธนูในมือ (ไม่ซ่อนแบบดาบ)
window.BOW7=1;                                            // ปิดตัววาดธนูข้างตัวแบบเก่า
const L7=(a,b,u)=>a+(b-a)*u,LP7=(a,b,u)=>[L7(a[0],b[0],u),L7(a[1],b[1],u)];
const rgF7=d=>d==='l'?-1:1,rgSide7=d=>d==='l'||d==='r';
// ลำดับการยิงต่อเนื่อง (ภาพเท่านั้น) : shot 1 → 2 → 3
{const _a=attack;attack=function(q){const a0=P.at;_a(q);if(isRng()&&a0<0&&P.at===0){const now=performance.now();P._rgN=(P._rgEnd&&now-P._rgEnd<700)?((P._rgN|0)+1)%3:0}}}

// ---------------- BOW / STAFF ON BACK ----------------
// ธนู: แนวคันเฉียงพาดหลัง (ปลายบนอยู่เหนือไหล่ซ้าย) · กระบอกลูกธนู: เหนือไหล่ขวา (มือขวาเอื้อมหยิบ)
const bowBackOffsetUp={x:-1,y:-27},bowBackOffsetDown={x:1,y:-27},bowBackOffsetLeft={x:5,y:-24},bowBackOffsetRight={x:-5,y:-24};
const bowBackRotationUp=-Math.PI/4,bowBackRotationDown=Math.PI/4,bowBackRotationLeft=.25,bowBackRotationRight=Math.PI-.25;
const bowBackLayerUp='over',bowBackLayerDown='behind',bowBackLayerLeft='behind',bowBackLayerRight='behind'; // over = ทับหลัง (เห็นเต็ม) · behind = หลังลำตัว (ลำตัวบัง)
const quiverOffset7={u:{x:7,y:-34,r:.35},d:{x:-7,y:-34,r:-.35},l:{x:5,y:-34,r:.3},r:{x:-5,y:-34,r:-.3}};
const quiverReach7=d=>{const q=quiverOffset7[d];return[q.x+Math.sin(q.r)*2,q.y-3]};
function drawQuiver7(x,y,r,n){ctx.save();ctx.translate(x,y);ctx.rotate(r);ctx.lineCap='round';
 // ลูกธนูโผล่ปากกระบอก (หาง/ขนนก)
 for(let i=0;i<(n==null?3:n);i++){const ox=-2+i*2;ctx.strokeStyle='#7a5a32';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(ox,2);ctx.lineTo(ox,-5);ctx.stroke();ctx.fillStyle=i===1?'#f2efe6':'#d84a3a';ctx.beginPath();ctx.moveTo(ox,-8);ctx.lineTo(ox-1.6,-4);ctx.lineTo(ox,-5);ctx.lineTo(ox+1.6,-4);ctx.closePath();ctx.fill()}
 ctx.fillStyle='#1a1008';ctx.fillRect(-4,0,8,19);ctx.fillStyle='#7a4a24';ctx.fillRect(-3,1,6,17);ctx.fillStyle='#a8703a';ctx.fillRect(-3,1,2,17);ctx.fillStyle='#c9a04a';ctx.fillRect(-4,0,8,2);ctx.fillRect(-4,13,8,1.5);ctx.restore()}
function bowBack7(x,by,side,f,d,phase){ // phase: 'pre' = เรียกก่อนลำตัว (d/side) · 'post' = หลังลำตัว (u)
 const tier=P.tier.sword|0,drawn=P.draw&&P.tool==='sword',q=quiverOffset7[d];
 const O={u:bowBackOffsetUp,d:bowBackOffsetDown,l:bowBackOffsetLeft,r:bowBackOffsetRight}[d],R={u:bowBackRotationUp,d:bowBackRotationDown,l:bowBackRotationLeft,r:bowBackRotationRight}[d];
 if(!drawn)drawBow6(x+O.x,by+O.y,R,tier,0,false,.82);
 const nq=(P.at>=0&&P.at<.12)?2:3;drawQuiver7(x+q.x,by+q.y,q.r,nq)}
{const _bs=backSword;backSword=function(x,by,side,f,d){if(!(P.armor.sword&&wKind()==='bow'))return _bs(x,by,side,f,d);bowBack7(x,by,side,f,d)}}

// ---------------- ท่าถือ (ยืน/เดิน) ----------------
// คฑา: จับช่วงล่างของด้าม ตั้งเกือบตรง ไม้แกว่งตามจังหวะเดิน · ธนู: ถือมือซ้ายข้างลำตัว คันตั้งแนวขา
const STF_GRIP7=-33; // วาดไอคอนคฑาให้มืออยู่ช่วงล่าง 1/4 ของด้าม
function staffAt7(hx,hy,ang,sc){ctx.save();ctx.translate(hx,hy);ctx.rotate(ang);if(sc)ctx.scale(sc,sc);ctx.drawImage(toolIcon('staff',P.tier.sword|0,64),-23,STF_GRIP7,46,46);ctx.restore()}
const STF_ORB7=27; // ระยะมือ→ลูกแก้ว (px)
function orbOf7(hx,hy,ang,sc){const r=STF_ORB7*(sc||1);return{x:hx+Math.sin(ang)*r,y:hy-Math.cos(ang)*r}}
{const _ts=toolSpr;toolSpr=function(hx,hy,ang){if(!(P.tool==='sword'&&isRng()&&P.at<0))return _ts(hx,hy,ang);
  const d=P.dir,f=rgF7(d),s=P.mv?Math.sin(P.t):0,kd=wKind(),tier=P.tier.sword|0;
  if(kd==='staff'){let a;if(rgSide7(d))a=f*(.1+.12*s);else a=(d==='d'?-.06:.06)+.05*s;staffAt7(hx,hy,a);const o=orbOf7(hx,hy,a);P.tip={x:o.x,y:o.y,t:performance.now()};
   ctx.fillStyle='#f1d2b0';ctx.fillRect(hx-3,hy-2.5,6,5);return}
  // ธนู: หน้า/หลัง ถือมือซ้ายตัวละคร (หน้า=ขวาจอ, หลัง=ซ้ายจอ) · ข้าง = มือข้างลำตัว
  let gx=hx,gy=hy,aim;if(d==='d'){gx=hx+(P.dash>0?32:22);aim=-.2}else if(d==='u'){gx=hx-(P.dash>0?32:22);aim=Math.PI+.2}else aim=f>0?.35+.08*s:Math.PI-.35-.08*s;
  drawBow6(gx,gy+1,aim,tier,0,false,.85);ctx.fillStyle='#f1d2b0';ctx.fillRect(gx-2.5,gy-1.5,5,5);P.tip={x:gx,y:gy,t:performance.now()}}}

// ---------------- ท่าโจมตี: ธนู ----------------
// จังหวะ (ยิงจริงที่ P.at=.34 ตามระบบเดิม): ยกธนู+เอื้อมหยิบลูก 0-.08 · พาดสาย .08-.16 · ง้าง .16-.30 · เล็งค้าง .30-.34 · ปล่อย .34-.42 · follow-through .42-.6 · คืนท่า .6-1
const BWPH=[.08,.16,.30,.34,.42,.6];
const BOWSHOT7=[{dy:0,tilt:0,deep:1,lean:[-1.5,1]},{dy:2,tilt:-.1,deep:1,lean:[-1,1.5]},{dy:0,tilt:0,deep:1.18,lean:[-3,2.5]}]; // shot 1 ปกติ · 2 ย่อต่ำ เงยนิด · 3 ง้างลึกแรงสุด
function bowPose7(d,p,n){const f=rgF7(d),sd=rgSide7(d),SH=BOWSHOT7[n%3],aim0=sd?(f>0?0:Math.PI):(d==='d'?Math.PI/2:-Math.PI/2),aim=aim0+(sd?-f*SH.tilt:0);
 const av=[Math.cos(aim),Math.sin(aim)],sc=d==='u'?.8:sd?.88:.9;
 const G=sd?[f*13,-24+SH.dy]:d==='d'?[3,-16+SH.dy]:[-2,-40+SH.dy*.5];             // ตำแหน่งกำคันธนูตอนเล็ง
 const I=sd?[f*5,-13]:d==='d'?[11,-12]:[-11,-12];                                     // ตำแหน่งมือถือธนูตอนพัก
 const aimI=sd?(f>0?.35:Math.PI-.35):d==='d'?-.2:Math.PI+.2;
 const H0=sd?[-f*2,-14]:d==='d'?[-11,-13]:[11,-13];                                    // มือดึงสายตอนพัก
 const Q=quiverReach7(d),nock=k=>[G[0]+av[0]*(-5-11*k)*sc,G[1]+av[1]*(-5-11*k)*sc];
 let g,a,h,pull=0,onStr=false,inHand=null,snap=0,lean=0;
 const raise=Math.min(1,e6o(p/.12)),back=p>BWPH[5]?e6io((p-BWPH[5])/(1-BWPH[5])):0;
 g=LP7(LP7(I,G,raise),I,back);a=L7(L7(aimI,aim,raise),aimI,back);
 if(p<BWPH[0]){h=LP7(H0,Q,e6o(p/BWPH[0]));inHand={k:0}}
 else if(p<BWPH[1]){const u=e6io((p-BWPH[0])/(BWPH[1]-BWPH[0]));h=LP7(Q,nock(0),u);inHand={k:u}}
 else if(p<BWPH[2]){const u=e6o((p-BWPH[1])/(BWPH[2]-BWPH[1]));pull=u*SH.deep;h=nock(pull);onStr=true;lean=SH.lean[0]*u}
 else if(p<BWPH[3]){pull=SH.deep;const tr=Math.sin(p*900)*.35;h=nock(pull);h[1]+=tr;onStr=true;lean=SH.lean[0]}
 else if(p<BWPH[4]){const u=(p-BWPH[3])/(BWPH[4]-BWPH[3]);snap=1-u;pull=-.18*Math.sin(u*Math.PI*3)*(1-u);const A=nock(SH.deep);h=[A[0]-av[0]*6*e6o(u),A[1]-av[1]*6*e6o(u)-3*e6o(u)];lean=L7(SH.lean[0],SH.lean[1],e6o(u))}
 else if(p<BWPH[5]){const A=nock(SH.deep);h=[A[0]-av[0]*6,A[1]-av[1]*6-3];lean=L7(SH.lean[1],0,(p-BWPH[4])/(BWPH[5]-BWPH[4]))}
 else{const A=nock(SH.deep);h=LP7([A[0]-av[0]*6,A[1]-av[1]*6-3],H0,back)}
 return{g,a,h,pull,onStr,inHand,snap,sc,aim,av,lean,dip:SH.dy}}
function drawArrow7(x,y,ang,len){ctx.save();ctx.translate(x,y);ctx.rotate(ang);ctx.lineCap='round';ctx.strokeStyle='#7a5a32';ctx.lineWidth=1.6;ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(len,0);ctx.stroke();
 ctx.fillStyle='#d8dce8';ctx.beginPath();ctx.moveTo(len+5,0);ctx.lineTo(len-1,-2.6);ctx.lineTo(len-1,2.6);ctx.closePath();ctx.fill();ctx.fillStyle='#e04a3a';ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(-3,-2.5);ctx.lineTo(3,0);ctx.lineTo(-3,2.5);ctx.closePath();ctx.fill();ctx.restore()}
// ไหล่: แขนจับคันธนู = แขนซ้ายตัวละคร · แขนดึงสาย = แขนขวา
const bowSh7=(x,by,d,f)=>rgSide7(d)?{bow:[x+f*2,by-25],dr:[x-f*1,by-24]}:d==='d'?{bow:[x+10,by-24],dr:[x-10,by-24]}:{bow:[x-10,by-24],dr:[x+10,by-24]};
function bowParts7(x,by,d,f,TOP,which){const n=P._rgN|0,p=P.at,q=bowPose7(d,p,n),gx=x+q.g[0],gy=by+q.g[1],hx=x+q.h[0],hy=by+q.h[1],S=bowSh7(x,by,d,f),tier=P.tier.sword|0;
 if(which!=='arms'){
  drawBow6(gx,gy,q.a,tier,Math.max(0,q.pull),false,q.sc);
  if(q.onStr){const sx=gx+q.av[0]*(-5-11*q.pull)*q.sc,sy=gy+q.av[1]*(-5-11*q.pull)*q.sc;drawArrow7(sx,sy,q.aim,24*q.sc);
   if(q.pull>.85){ctx.save();ctx.globalCompositeOperation='lighter';const tx=sx+q.av[0]*27*q.sc,ty=sy+q.av[1]*27*q.sc,g=ctx.createRadialGradient(tx,ty,0,tx,ty,7);g.addColorStop(0,'rgba(255,240,180,.85)');g.addColorStop(1,'rgba(255,200,80,0)');ctx.fillStyle=g;ctx.fillRect(tx-7,ty-7,14,14);ctx.restore()}
   P.tip={x:sx+q.av[0]*26*q.sc,y:sy+q.av[1]*26*q.sc,t:performance.now()}}
  if(q.snap>0){ctx.save();ctx.globalAlpha=.6*q.snap;ctx.strokeStyle='#fff';ctx.lineWidth=1;for(let i=1;i<=2;i++){ctx.beginPath();ctx.arc(gx,gy,10+i*5*(1-q.snap),q.aim-.6,q.aim+.6);ctx.stroke()}ctx.restore()}
  if(which==='bow'){swArm6(S.bow[0],S.bow[1],gx,gy,TOP,-1);ctx.fillStyle='#f1d2b0';ctx.fillRect(gx-2.5,gy-2.5,5,5);return}} // หันขึ้น: แขนจับคันอยู่หน้าตัว (หลังลำตัวจากมุมกล้อง)
 // แขนจับคันธนู → มือที่กำคัน · แขนดึงสาย → มือ (ถือลูกธนูตอนหยิบ/พาดสาย)
 if(which!=='arms'||d!=='u'){swArm6(S.bow[0],S.bow[1],gx,gy,TOP,d==='d'?1:d==='u'?-1:f);ctx.fillStyle='#f1d2b0';ctx.fillRect(gx-2.5,gy-2.5,5,5)}
 if(q.inHand){const k=q.inHand.k,ang=L7(d==='u'?-Math.PI/2-.3:-Math.PI/2+(rgSide7(d)?-f*.5:.4),q.aim,k);drawArrow7(hx-Math.cos(ang)*4,hy-Math.sin(ang)*4,ang,22*q.sc)}
 swArm6(S.dr[0],S.dr[1],hx,hy,TOP,d==='d'?-1:d==='u'?1:-f);ctx.fillStyle='#f1d2b0';ctx.fillRect(hx-2.5,hy-2.5,5,5)}

// ---------------- ท่าโจมตี: คฑา (ร่ายเวท) ----------------
// จังหวะ: เตรียม (ยกคฑา รวมพลังที่มือ) 0-.14 · ร่าย/ชี้ .14-.30 · ปล่อยเวท .30-.42 (กระสุนออก .34) · follow-through .42-.65 · คืนท่า .65-1
const STPH=[.14,.30,.42,.65];
// [มือถือคฑา x,y, มุมคฑา] / [มือว่าง x,y] — ข้างกำหนดสำหรับหันขวา แล้วสะท้อนด้วย f
const STK7={
 s:[{W:[-3,-27,-.45],S:[12,-24,1.15],F:[11,-22,1.0], fW:[2,-24],fS:[15,-28],fF:[13,-27], b:{W:[-2,1],S:[3,0]}},   // 1 แทงชี้ไปข้างหน้า
    {W:[-6,-16,-1.6],S:[11,-21,1.45],F:[10,-20,1.6], fW:[-4,-20],fS:[14,-24],fF:[12,-23],b:{W:[-2,2],S:[3,0]}},   // 2 กวาดจากด้านหลังผ่านเหนือหัว
    {W:[1,-40,-.2],  S:[12,-18,2.05],F:[12,-16,2.0], fW:[3,-40],fS:[8,-20],fF:[8,-19],  b:{W:[-1,-2],S:[4,3]}}],  // 3 ชูสูง → ฟาดลงพื้นข้างหน้า (แรงสุด)
 d:[{W:[-10,-28,-.35],S:[-3,-14,.25],F:[-3,-13,.2], fW:[6,-22],fS:[6,-27],fF:[6,-26], b:{W:[-1,-1],S:[0,2]}},
    {W:[-14,-20,-1.3],S:[6,-18,1.0],F:[7,-17,1.2],   fW:[8,-20],fS:[-2,-27],fF:[-2,-26],b:{W:[-2,1],S:[2,1]}},
    {W:[-6,-42,0],    S:[-2,-16,.1],F:[-2,-15,.1],   fW:[2,-42],fS:[5,-20],fF:[5,-19],  b:{W:[0,-2],S:[0,3]}}],
 // หันขึ้น (มองจากหลัง): มือยื่นไปข้างหน้า/ขึ้นเหนือไหล่ — วาดหลังลำตัว ไม่พับแขนมาทางกล้อง
 u:[{W:[9,-28,.35], S:[7,-42,-.1],F:[7,-40,-.05], fW:[-7,-28],fS:[-6,-41],fF:[-6,-39],b:{W:[1,-1],S:[0,1]}},
    {W:[13,-24,1.2],S:[-7,-40,-.9],F:[-8,-39,-1.0],fW:[-9,-26],fS:[5,-42],fF:[5,-40],b:{W:[2,1],S:[-2,1]}},
    {W:[5,-48,0],   S:[4,-40,0],F:[4,-39,0],       fW:[-3,-48],fS:[-5,-40],fF:[-5,-39],b:{W:[0,-2],S:[0,3]}}]};
function staffPose7(d,p,n){const sd=rgSide7(d),f=rgF7(d),K=STK7[sd?'s':d][n%3],I=sd?[5,-13,.1]:d==='d'?[-11,-13,-.06]:[11,-13,.06],fI=sd?[-2,-14]:d==='d'?[11,-13]:[-11,-13];
 const L3=(a,b,u)=>[L7(a[0],b[0],u),L7(a[1],b[1],u),L7(a[2],b[2],u)];let w,fh,b,ph;
 if(p<STPH[0]){const u=e6o(p/STPH[0]);w=L3(I,K.W,u);fh=LP7(fI,K.fW,u);b=[K.b.W[0]*u,K.b.W[1]*u];ph=0}
 else if(p<STPH[1]){const u=e6i((p-STPH[0])/(STPH[1]-STPH[0]));w=L3(K.W,K.S,u);fh=LP7(K.fW,K.fS,u);b=LP7(K.b.W,K.b.S,u);ph=1}
 else if(p<STPH[2]){const u=(p-STPH[1])/(STPH[2]-STPH[1]),r=Math.sin(u*Math.PI)*1.5;w=[K.S[0]-(sd?f:0)*r,K.S[1]+(sd?0:r*.6),K.S[2]];fh=K.fS.slice();b=K.b.S;ph=2}
 else if(p<STPH[3]){const u=e6o((p-STPH[2])/(STPH[3]-STPH[2]));w=L3(K.S,K.F,u);fh=LP7(K.fS,K.fF,u);b=LP7(K.b.S,[0,0],u);ph=3}
 else{const u=e6io((p-STPH[3])/(1-STPH[3]));w=L3(K.F,I,u);fh=LP7(K.fF,fI,u);b=[0,0];ph=4}
 if(sd){w[0]*=f;w[2]*=f;fh[0]*=f}return{w,fh,b,ph}}
const stSh7=(x,by,d,f)=>rgSide7(d)?{st:[x+f*1,by-24],fr:[x+f*2,by-25]}:d==='d'?{st:[x-10,by-24],fr:[x+10,by-24]}:{st:[x+10,by-24],fr:[x-10,by-24]};
function magicCol7(){const t=P.tier.sword|0,Q=TIERS[t]||TIERS[0];return Q.gl}
function staffParts7(x,by,d,f,TOP,which){const n=P._rgN|0,p=P.at,q=staffPose7(d,p,n),hx=x+q.w[0],hy=by+q.w[1],ang=q.w[2],S=stSh7(x,by,d,f),fx2=x+q.fh[0],fy2=by+q.fh[1],col=magicCol7();
 const sc=d==='u'&&q.ph>=1&&q.ph<4?.94:1;
 if(which!=='arms'){
  staffAt7(hx,hy,ang,sc);const o=orbOf7(hx,hy,ang,sc);P.tip={x:o.x,y:o.y,t:performance.now()};
  ctx.save();ctx.globalCompositeOperation='lighter';
  if(q.ph===0||q.ph===1){const k=q.ph===0?p/STPH[0]:1,g=ctx.createRadialGradient(o.x,o.y,0,o.x,o.y,6+6*k);g.addColorStop(0,'rgba(255,255,255,'+(.6*k)+')');g.addColorStop(1,'rgba(150,100,255,0)');ctx.fillStyle=g;ctx.fillRect(o.x-14,o.y-14,28,28);
   for(let i=0;i<4;i++){const a=p*20+i*1.57,r=14*(1-k)+3;ctx.fillStyle='rgba(200,170,255,'+(.7*k)+')';ctx.fillRect(o.x+Math.cos(a)*r-1,o.y+Math.sin(a)*r-1,2,2)}}
  if(q.ph===2){const u=(p-STPH[1])/(STPH[2]-STPH[1]),a=1-u,R=10+(n===2?22:14)*e6o(u),g=ctx.createRadialGradient(o.x,o.y,0,o.x,o.y,R);g.addColorStop(0,'rgba(255,255,255,'+a+')');g.addColorStop(.35,'rgba(190,150,255,'+(.8*a)+')');g.addColorStop(1,'rgba(120,60,255,0)');ctx.fillStyle=g;ctx.fillRect(o.x-R,o.y-R,R*2,R*2);
   ctx.globalAlpha=a;ctx.strokeStyle=col;ctx.lineWidth=2;ctx.beginPath();ctx.arc(o.x,o.y,R*.8,0,7);ctx.stroke();
   ctx.strokeStyle='#fff';ctx.lineWidth=1.2;for(let i=0;i<6;i++){const aa=i*1.047+u;ctx.beginPath();ctx.moveTo(o.x+Math.cos(aa)*R*.4,o.y+Math.sin(aa)*R*.4);ctx.lineTo(o.x+Math.cos(aa)*R*.95,o.y+Math.sin(aa)*R*.95);ctx.stroke()}
   if(n===2){ctx.globalAlpha=.6*a;ctx.strokeStyle=col;ctx.lineWidth=2.5;ctx.beginPath();ctx.ellipse(x,by+2,12+28*e6o(u),4+9*e6o(u),0,0,7);ctx.stroke();if(!window._drawingOther&&!P._rsh7){P._rsh7=1;try{shake(1.6,.1)}catch(e){}}}}
  ctx.restore();if(p<.1)P._rsh7=0;
  if(which==='staff')return}
 // มือว่าง: ตอนร่ายยื่นฝ่ามือไปทางเป้าหมาย มีแสงเวท
 swArm6(S.fr[0],S.fr[1],fx2,fy2,TOP,d==='d'?1:d==='u'?-1:f);ctx.fillStyle='#f1d2b0';ctx.fillRect(fx2-2.5,fy2-2.5,5,5);
 if(q.ph>=1&&q.ph<=2){ctx.save();ctx.globalCompositeOperation='lighter';const g=ctx.createRadialGradient(fx2,fy2,0,fx2,fy2,7);g.addColorStop(0,'rgba(230,210,255,.8)');g.addColorStop(1,'rgba(150,100,255,0)');ctx.fillStyle=g;ctx.fillRect(fx2-7,fy2-7,14,14);ctx.restore()}
 swArm6(S.st[0],S.st[1],hx,hy,TOP,d==='d'?-1:d==='u'?1:-f);ctx.fillStyle='#f1d2b0';ctx.fillRect(hx-3,hy-2.5,6,5)}

// ---------------- ต่อเข้ากับระบบเดิม ----------------
// slashFx: หน้า/ข้าง เรียกหลังลำตัว (วาดครบ) · หลัง(u) เรียกก่อนลำตัว (วาดเฉพาะอาวุธ แล้วแขน/มือวาดทับหลังลำตัวทีหลัง)
{const _sf=slashFx;slashFx=function(x,by,d,side,f,TOP,held){if(!(isRng()&&P.tool==='sword'))return _sf(x,by,d,side,f,TOP,held);
  if(P.at>.95)P._rgEnd=performance.now();const kd=wKind();
  if(d==='u'&&kd==='staff'){staffParts7(x,by,d,f,TOP,'all');return}   // คฑาหันขึ้น: คฑา+แขนอยู่หน้าตัว (หลังลำตัวจากมุมกล้อง)
  if(d==='u'){bowParts7(x,by,d,f,TOP,'bow');RG7.post={x,by,d,f,TOP,kd};return}
  (kd==='bow'?bowParts7:staffParts7)(x,by,d,f,TOP,'all')}}
const RG7={post:null};
{const _hb=heroBody;heroBody=function(){if(!(rgOn7()&&P.at>=0))return _hb();RG7.post=null;const d=P.dir,f=rgF7(d),side=rgSide7(d),p=P.at,kd=wKind();
  let lean=0,dip=0;if(kd==='bow'){const q=bowPose7(d,p,P._rgN|0);lean=q.lean;dip=(p<.12?e6o(p/.12):p>.6?1-e6io((p-.6)/.4):1)*q.dip}else{const q=staffPose7(d,p,P._rgN|0);lean=q.b[0];dip=q.b[1]}
  const hxo=side?f*lean:lean*.6,sq=1-Math.max(0,dip)*.012+Math.max(0,-dip)*.01;
  ctx.save();ctx.translate(P.x,P.y);ctx.transform(1,0,-hxo/44,1,0,0);ctx.scale(1,sq);ctx.translate(-P.x,-P.y);
  try{_hb();const o=RG7.post;if(o)(o.kd==='bow'?bowParts7:staffParts7)(o.x,o.by,o.d,o.f,o.TOP,'arms')}finally{ctx.restore();RG7.post=null}}}

// ---------------- ขนาดขวาน/ที่ขุดแร่ เท่ากันทุกท่า ----------------
window.AXS7=.85; // ทุกท่า (ถือ/ฟันขึ้น/ฟันข้าง/ฟันลง) ใช้สเกลเดียวกัน — เดิมถือ 0.7 แต่ฟันข้าง/ลง 1.0

// =====================================================================
// GM7 MODE (เฉพาะไอดี tiksi หรือปลดด้วยรหัส GM) — ปุ่ม GM7 บนจอ เปิดแผงทดสอบทุกระบบ
// =====================================================================
const GM7={god:false,nocd:false};
const GM_IDS=['tiksi','wiwekwin2537'];
const GM_HASH='90f635b045c05822acfc7626c6cebb5ecfd7102d522f777d030a9f0e2c4094a5'; // SHA-256 ของรหัส GM7 สำรอง (ไม่เก็บรหัสจริงในไฟล์)
function gmAllowed(){try{if(FM_ACCT&&GM_IDS.includes(String(FM_ACCT).toLowerCase()))return true;return sessionStorage.getItem('fm_gm7')==='1'}catch(e){return false}}
async function gmCode(c){try{const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode('eldoria-gm:'+String(c).trim()));const h=[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('');if(h===GM_HASH){sessionStorage.setItem('fm_gm7','1');gmBtn();say('🛠️ เปิดโหมด GM7 แล้ว');return true}}catch(e){}say('รหัส GM7 ไม่ถูกต้อง');return false}
window.gmCode=gmCode;
const gmW=mk6('gmw');
function gmBtn(){if(!gmAllowed())return;if(gid('gmb'))return;const b=document.createElement('button');b.id='gmb';b.textContent='GM';b.style.cssText='position:absolute;left:50px;top:65px;z-index:25;font:900 11px system-ui;padding:0 8px;width:auto;min-width:0;height:20px;min-height:0;line-height:18px;border-radius:9px;border:2px solid #ffe9a0;background:linear-gradient(180deg,#c0503a,#7a1a10);color:#fff;box-shadow:0 2px 6px #0008';
 b.addEventListener('pointerdown',e=>e.stopPropagation());b.onclick=()=>{gmRender();p6open(gmW)};gid('wrap').appendChild(b)}
const gmSafe=fn=>{try{fn()}catch(e){say('GM: '+e.message)}try{recalcStats()}catch(e){}try{refreshInv()}catch(e){}try{saveGame(true)}catch(e){}gmRender()};
const GMA={
 god:()=>{GM7.god=!GM7.god;say(GM7.god?'🛡️ อมตะ: เปิด':'🛡️ อมตะ: ปิด')},
 nocd:()=>{GM7.nocd=!GM7.nocd;say(GM7.nocd?'⏱️ ไม่มีคูลดาวน์/มานาไม่จำกัด: เปิด':'⏱️ ไม่มีคูลดาวน์: ปิด')},
 heal:()=>{P.hp=BAL.hp;P.mp=BAL.mp;P.fa=100;if('hu' in P)P.hu=100;P.dead=false},
 lv10:()=>{for(let i=0;i<10&&P.lv<99;i++)gainXp(need(P.lv)-P.xp+1)},
 lv99:()=>{while(P.lv<99)gainXp(need(P.lv)-P.xp+1)},
 coin:()=>{inv.coin=(inv.coin|0)+100000;say('💰 +100,000')},
 mats:()=>{for(const k of INVORDER){if(k==='coin')continue;inv[k]=Math.max(inv[k]|0,99)}P.bagLv=3;say('📦 วัตถุดิบทุกอย่าง ×99')},
 gear:()=>{for(const id in ITEMS)GEAR[id]=Math.max(GEAR[id]|0,1);say('⚔️ ได้อุปกรณ์ทุกชิ้นแล้ว (ดูในกระเป๋า)')},
 ult:()=>{try{ULT.v=100}catch(e){}for(let i=0;i<CS.cd.length;i++)CS.cd[i]=0},
 home:()=>{HOME.unlocked=1;HOME.house=HOUSE.length-1;for(const k of TOOLKEYS){HOME.tools[k]=5;inv['t_'+k]=1}saveHome();if(D&&D.home)homeObjects();say('🏡 ปลดล็อกที่ดิน · บ้านสูงสุด · เครื่องมือสูงสุด')},
 kill:()=>{let n=0;eachIn(P.x,P.y,700,e=>{hurtE(e,99999,{kb:10});n++});say('💀 กำจัด '+n+' ตัว')},
 town:()=>{p6close(gmW);enterTown()},
 homeGo:()=>{p6close(gmW);HOME.unlocked=1;enterHome()},
 save:()=>{saveGame(true);say('💾 เซฟแล้ว')}};
function gmCls(c){gmSafe(()=>{P.cls=c;saveCls();say('🎓 เปลี่ยนอาชีพเป็น '+CLS[c].n)})}
function gmWpn(id){gmSafe(()=>{GEAR[id]=Math.max(GEAR[id]|0,1);equipItem(id);P.tool='sword';P.draw=true;say('ถือ '+ITEMS[id].name)})}
function gmTime(t){gmSafe(()=>{DAY.t=t;try{_dayPt=t}catch(e){}})}
function gmZone(i){p6close(gmW);try{enterZone(i)}catch(e){say('GM: '+e.message)}}
window.gmA=k=>gmSafe(GMA[k]);window.gmCls=gmCls;window.gmWpn=gmWpn;window.gmTime=gmTime;window.gmZone=gmZone;
function gmRender(){if(!gmAllowed())return;const B=(t,on,cls)=>'<button class="bt'+(cls?' '+cls:'')+'" onclick="'+on+'">'+t+'</button>',row=(h,x)=>'<div class="card"><b style="color:#ffe9a0">'+h+'</b><div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:6px">'+x+'</div></div>';
 const wp=['sword0','sword3','sword5','bow0','bow1','staff0','staff1'].filter(id=>ITEMS[id]);
 gmW.innerHTML='<div class="w"><div class="hd"><b>🛠️ GM — '+(FM_ACCT||'ทดลอง')+' · Lv.'+P.lv+' · '+(CLS[P.cls]||{}).n+'</b><button onclick="p6close(gid(\'gmw\'))">✕</button></div><div class="bd" style="flex-direction:column;overflow-y:auto">'
 +row('ตัวละคร',B((GM7.god?'✅ ':'')+'🛡️ อมตะ',"gmA('god')",GM7.god?'g':'')+B((GM7.nocd?'✅ ':'')+'⏱️ ไม่มีคูลดาวน์',"gmA('nocd')",GM7.nocd?'g':'')+B('❤️ ฟื้นเต็ม',"gmA('heal')")+B('⬆️ +10 เลเวล',"gmA('lv10')")+B('⭐ Lv.99',"gmA('lv99')")+B('🌟 อัลติเต็ม',"gmA('ult')"))
 +row('ของ',B('💰 +100,000',"gmA('coin')")+B('📦 วัตถุดิบ ×99',"gmA('mats')")+B('⚔️ อุปกรณ์ทุกชิ้น',"gmA('gear')")+B('🏡 ที่ดิน/บ้าน/เครื่องมือสูงสุด',"gmA('home')"))
 +row('อาชีพ',['none','sword','mage','archer'].map(c=>B(CLS[c].e+' '+CLS[c].n,"gmCls('"+c+"')",P.cls===c?'g':'')).join(''))
 +row('ถืออาวุธ (เทสท่า)',wp.map(id=>B(ITEMS[id].name,"gmWpn('"+id+"')",P.armor.sword===id?'g':'')).join(''))
 +row('เวลา',B('🌅 เช้า',"gmTime(6)")+B('☀️ เที่ยง',"gmTime(12)")+B('🌇 เย็น',"gmTime(18.5)")+B('🌙 ดึก',"gmTime(23)"))
 +row('วาป / ต่อสู้',B('🏰 เมือง',"gmA('town')")+B('🏡 ที่ดิน',"gmA('homeGo')")+ZONES.map((z,i)=>B(z.e+' '+z.n,"gmZone("+i+")")).join('')+B('💀 ฆ่ามอนรอบตัว',"gmA('kill')",'r'))
 +row('ระบบ',B('💾 เซฟ',"gmA('save')"))+'</div></div>'}
{const _h=hurtPlayer;hurtPlayer=function(sl){if(GM7.god&&gmAllowed()){P.hp=BAL.hp;return}return _h(sl)}}
setInterval(()=>{try{if(!gmAllowed())return;gmBtn();if(GM7.god){P.hp=Math.max(P.hp,BAL.hp);P.dead=false}if(GM7.nocd){P.mp=BAL.mp;P.fa=100;for(let i=0;i<CS.cd.length;i++)CS.cd[i]=0}}catch(e){}},250);
// พิมพ์ในแชท: /gm รหัส  → ปลดล็อก GM7 ในไอดีอื่น/โหมดทดลอง (ข้อความนี้ไม่ถูกส่งออก)
{const _cs=chatSend;chatSend=function(){const ti=gid('chatTi'),t=(ti&&ti.value||'').trim();if(/^\/gm\b/i.test(t)){ti.value='';gmCode(t.replace(/^\/gm\s*/i,''));return}return _cs()}}

// [แก้จอดำ] เซฟที่สวมคฑา/ธนูอยู่: ตอนโหลดเซฟ ไอเท็มคฑา/ธนูยังไม่ถูกสร้าง (อยู่สคริปต์ถัดไป) → เกมพังทั้งหน้า
// ตอนโหลดจึงพักไอเท็มที่ยังไม่รู้จักไว้ก่อน แล้วคืนให้ตรงนี้ (ไอเท็มถูกสร้างครบแล้ว)
try{const Q=window.__PEND7;if(Q){window.__PEND7=null;let ch=0;const L8={a:{},g:{}};for(const k in Q.a)if(!ITEMS[Q.a[k]])L8.a[k]=Q.a[k];for(const id in Q.g)if(!ITEMS[id])L8.g[id]=Q.g[id];if(Object.keys(L8.a).length||Object.keys(L8.g).length)window.__PEND8=L8;for(const k in Q.a)if(ITEMS[Q.a[k]]){P.armor[k]=Q.a[k];ch=1}for(const id in Q.g)if(ITEMS[id]){GEAR[id]=Q.g[id];ch=1}
 if(ch){try{syncSword()}catch(e){}try{recalcStats()}catch(e){}try{applyBonus()}catch(e){}try{refreshInv()}catch(e){}}}}catch(e){}
