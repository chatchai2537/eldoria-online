// =====================================================================
// player.js — XP/เลเวล (ผ่าน Hooks('xp')) · สวมใส่ (Guard + ITEM_EQUIPPED) · สถานะผู้เล่น
// =====================================================================
(()=>{
 const _gx=gainXp;gainXp=function(n){return Guard.run('gainXp',()=>{const l0=P.lv;let v=Number(n)||0;v=Math.max(0,Math.round(Hooks.apply('xp',v)));_gx(v);EventBus.emit(EV.XP_GAINED,{amount:v,base:n,lv:P.lv});if(P.lv>l0)EventBus.emit(EV.LEVEL_UP,{from:l0,to:P.lv})})};
 window.gainXp=gainXp;
 const _eq=equipItem;equipItem=function(id){return Guard.run('equipItem',()=>{const before=JSON.stringify(P.armor);const r=_eq(id);if(JSON.stringify(P.armor)!==before||(QS&&QS.slots.includes(id)))EventBus.emit(EV.ITEM_EQUIPPED,{id,armor:Object.assign({},P.armor)});return r},'isEquipping',()=>{try{hideBag();CHS.sel=null;refreshInv()}catch(_){}})};
 window.equipItem=equipItem;
 const _ue=unequip;unequip=function(k){return Guard.run('unequip',()=>_ue(k),'isEquipping')};window.unequip=unequip;
 Eldoria.register('player',{state:()=>({lv:P.lv,hp:P.hp,mp:P.mp,cls:P.cls,armor:Object.assign({},P.armor),flags:Object.assign({},PSTATE)})});
})();
