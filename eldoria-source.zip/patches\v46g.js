
// =====================================================================
// v4.7 (ช) : ดาบสะพายหลังทุกทิศ · คอมโบดาบ 3 จังหวะทั้งตัว · ค้อนตอกตะปูตอนก่อสร้าง
// (ไม่แตะระบบขวาน / movement / input / hitbox / ขนาด sprite)
// =====================================================================

// ---------- A. SWORD ON BACK : ตำแหน่ง/มุม/เลเยอร์ แยกตามทิศ ----------
// UP / DOWN ใช้ค่าเดิมในฟังก์ชัน backSword (ไม่แก้) : Up=(x+4,by-34) หมุน -2.62 · Down=(x+8,by-33) หมุน -2.72
const swordBackOffsetUp={x:4,y:-34},swordBackOffsetDown={x:8,y:-33};
const swordBackRotationUp=-2.62,swordBackRotationDown=-2.72;
// LEFT / RIGHT : มุมมองด้านข้าง — ด้ามโผล่เหนือไหล่ด้านหลังศีรษะ ใบดาบพาดเฉียงลงตามแนวหลัง ปลายเลยสะโพกไปด้านหลัง
// x = ไปทางหลังตัวละคร (หันซ้าย หลังอยู่ขวา +x · หันขวา หลังอยู่ซ้าย -x)
const swordBackOffsetLeft={x:6,y:-37},swordBackOffsetRight={x:-6,y:-37};
const swordBackRotationLeft=Math.PI-.38,swordBackRotationRight=Math.PI+.38;
const SWORD_BACK_SIDE_SCALE=.86;
// เลเยอร์: DOWN = หลังตัว (วาดก่อนลำตัว · เดิม) · UP = ทับหลัง (วาดหลังลำตัว · เดิม) · LEFT/RIGHT = หลังลำตัว (วาดก่อนลำตัว แล้วศีรษะ/ลำตัวบังกลางดาบ)
const BK6={on:0};
function backWeaponSide(x,by,f){
 if(!P.armor.sword)return;const kd=wKind(),drawn=P.draw&&P.tool==='sword';
 if(drawn&&P.at>=0)return;                                            // กำลังฟัน = ดาบอยู่ในมือ
 if(drawn&&(kd==='bow'||kd==='staff'))return;      // คฑา/ธนูที่ถืออยู่ = อยู่ในมือ (ระบบ v46h) // ธนูถืออยู่ในมือ (มีตัววาดของมันแล้ว)
 const O=f<0?swordBackOffsetLeft:swordBackOffsetRight;let rot=f<0?swordBackRotationLeft:swordBackRotationRight,s=SWORD_BACK_SIDE_SCALE,ic,ox=O.x,oy=O.y;
 if(kd==='bow'){ic=toolIcon('bow',P.tier.sword|0,64);rot=f<0?Math.PI-.15:Math.PI+.15;ox=f<0?6:-6;oy=-22;s=.8}
 else if(kd==='staff'){ic=toolIcon('staff',P.tier.sword|0,64);rot=-f*.3;ox=f<0?5:-5;oy=-13;s=.86}
 else ic=toolIcon('sword',P.tier.sword,64);
 ctx.save();ctx.translate(Math.round(x+ox),Math.round(by+oy));ctx.rotate(rot);ctx.scale(s,s);ctx.drawImage(ic,-23,-36,46,46);ctx.restore();
 BK6.on=1;BK6.x=x;BK6.by=by;BK6.f=f;
 try{if(!drawn){const W=wAura();if(W&&DT)auraEmit(x-f*8,by-6,x-f*3,by-40,W,DT,.35)}}catch(e){}}
{const _bs=backSword;backSword=function(x,by,side,f,d){if(!side)return _bs(x,by,side,f,d);backWeaponSide(x,by,f)}}
// สายสะพายพาดบนลำตัวด้านข้าง (วาดหลังลำตัวเสร็จ) — ให้เห็นว่าดาบผูกติดหลัง ไม่ลอย
{const _hb=heroBody;heroBody=function(){BK6.on=0;_hb();if(BK6.on&&!(P.dash>0)){const x=BK6.x,by=BK6.by,f=BK6.f;ctx.save();ctx.strokeStyle='#4a3020';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(x-f*4,by-27);ctx.lineTo(x+f*3,by-14);ctx.stroke();ctx.restore()}BK6.on=0}}

// ---------- B. SWORD ATTACK 3-HIT COMBO (ทั้งร่างกาย) ----------
// เฟส: 0-.16 เตรียมท่า(anticipation) · .16-.28 ฟัน · .28-.42 แรงปะทะ(impact) · .42-.64 follow-through · .64-1 คืนตัว
// ท่าที่ 1 = ฟันเฉียงลงจากเหนือไหล่ · ท่าที่ 2 = ตวัดขึ้นย้อนแนว (backhand) · ท่าที่ 3 = เตรียมย่อ → หมุนตัวฟันรอบ → ฟาดค้าง → กลับ idle
// มุม: 0 = ใบดาบชี้ขึ้น, บวก = ตามเข็ม · ข้าง (ซ้าย/ขวา) กำหนดสำหรับหันขวา แล้วสะท้อนด้วย f
const SWC6={
 s:[{I:[4,-16,.9], W:[-4,-38,-1.0],S:[13,-20,2.25],F:[11,-14,2.65],R:[6,-18,1.6], b:{W:[-3,1,0],S:[4,1,0],F:[2,0,0]}},
    {I:[6,-18,1.6],W:[-6,-14,3.75],S:[10,-36,-.25],F:[6,-38,-.7], R:[5,-22,.6],  b:{W:[-2,2,0],S:[2,-1,0],F:[0,-1,0]}}],
 d:[{I:[-11,-13,-.5],W:[-12,-40,-.9],S:[3,-11,2.7],F:[5,-8,3.05],R:[0,-12,2.3],   b:{W:[0,-1,-2],S:[0,2,2],F:[0,1,1]}},
    {I:[0,-12,2.3],  W:[10,-22,1.2], S:[-12,-15,4.5],F:[-14,-17,4.9],R:[-11,-14,5.5],b:{W:[0,1,3],S:[0,1,-3],F:[0,0,-2]}}],
 u:[{I:[11,-13,.5],  W:[13,-38,1.3], S:[-7,-28,-1.5],F:[-9,-25,-2.0],R:[-4,-28,-1.0],b:{W:[0,-1,2],S:[0,1,-3],F:[0,0,-2]}},
    {I:[-4,-28,-1.0],W:[-10,-22,-2.2],S:[12,-36,1.4],F:[13,-33,1.9],R:[11,-20,.8], b:{W:[0,1,-3],S:[0,-1,3],F:[0,0,2]}}]};
const SWPH=[0,.16,.28,.42,.64,1];
const e6o=u=>1-Math.pow(1-u,3),e6i=u=>u*u*u,e6io=u=>u<.5?4*u*u*u:1-Math.pow(-2*u+2,3)/2;
const swOn6=()=>P.tool==='sword'&&P.at>=0&&!isRng()&&!P.dead;
function swKey6(d){return d==='l'||d==='r'?'s':d}
// คืนค่า [hx,hy,ang] (สัมพัทธ์กับ x,by) ของท่าฟันที่เวลา p
function swPose6(c,d,p){const K=SWC6[swKey6(d)][c],f=d==='l'?-1:1,sd=d==='l'||d==='r',L=(a,b,u)=>[a[0]+(b[0]-a[0])*u,a[1]+(b[1]-a[1])*u,a[2]+(b[2]-a[2])*u];let v;
 if(p<SWPH[1])v=L(K.I,K.W,e6o(p/SWPH[1]));
 else if(p<SWPH[2])v=L(K.W,K.S,e6i((p-SWPH[1])/(SWPH[2]-SWPH[1])));
 else if(p<SWPH[3]){v=K.S.slice()}
 else if(p<SWPH[4])v=L(K.S,K.F,e6o((p-SWPH[3])/(SWPH[4]-SWPH[3])));
 else v=L(K.F,K.R,e6io((p-SWPH[4])/(SWPH[5]-SWPH[4])));
 if(sd){v[0]*=f;v[2]*=f}return v}
// ท่าทางลำตัว [เอนไปข้างหน้า(px ศีรษะ), ย่อ(px), บิดซ้าย-ขวา(px ศีรษะ)]
function swBody6(c,d,p){const B=SWC6[swKey6(d)][c].b,Z=[0,0,0],L=(a,b,u)=>[a[0]+(b[0]-a[0])*u,a[1]+(b[1]-a[1])*u,a[2]+(b[2]-a[2])*u];
 if(p<SWPH[1])return L(Z,B.W,e6o(p/SWPH[1]));if(p<SWPH[2])return L(B.W,B.S,e6i((p-SWPH[1])/(SWPH[2]-SWPH[1])));
 if(p<SWPH[3])return B.S;if(p<SWPH[4])return L(B.S,B.F,e6o((p-SWPH[3])/(SWPH[4]-SWPH[3])));return L(B.F,Z,e6io((p-SWPH[4])/(SWPH[5]-SWPH[4])))}
// ท่าที่ 3 : เตรียมย่อตัว → หมุน 1 รอบเร็ว (เลยนิดหนึ่ง) → ฟาดค้าง → ค่อยลดดาบกลับ
const SP6=[.16,.7,.84];
spinInfo=function(){const p=P.at,sg=P.spinDir==='l'?-1:1,base=SPIN_BASE[P.spinDir||'d'];let e,q;
 if(p<SP6[0]){e=-.06*e6o(p/SP6[0]);q=0}
 else if(p<SP6[1]){const u=(p-SP6[0])/(SP6[1]-SP6[0]);e=-.06+1.1*e6io(u);q=u}
 else if(p<SP6[2]){const u=(p-SP6[1])/(SP6[2]-SP6[1]);e=1.04-.04*e6o(u);q=1}
 else{e=1;q=1}
 return{ang:base+sg*Math.PI*2*e,sg,q,e}};
function spinBody6(p){if(p<SP6[0]){const u=e6o(p/SP6[0]);return[-2*u,3*u,0]}if(p<SP6[1]){const u=(p-SP6[0])/(SP6[1]-SP6[0]);return[-2+4*u,3-4*u,0]}
 if(p<SP6[2]){const u=(p-SP6[1])/(SP6[2]-SP6[1]);return[2+2*Math.sin(u*Math.PI),-1+3*e6o(u),0]}const u=e6io((p-SP6[2])/(1-SP6[2]));return[2*(1-u),2*(1-u),0]}
// แขน 2 ท่อน (ต้นแขน+ปลายแขน) งอศอกตามระยะ ไม่ยืดไม่หด
function swArm6(sx,sy,hx,hy,TOP,out){const dx=hx-sx,dy=hy-sy,dd=Math.hypot(dx,dy)||1,seg=9.5,h=dd<seg*2?Math.sqrt(seg*seg-(dd/2)*(dd/2)):0;
 let nx=-dy/dd,ny=dx/dd;if(nx*out+ny*.6<0){nx=-nx;ny=-ny}const ex=(sx+hx)/2+nx*h,ey=(sy+hy)/2+ny*h;
 ctx.save();ctx.strokeStyle=TOP;ctx.lineCap='round';ctx.lineJoin='round';ctx.lineWidth=5.5;ctx.beginPath();ctx.moveTo(sx,sy);ctx.lineTo(ex,ey);ctx.lineTo(hx,hy);ctx.stroke();ctx.restore()}
// รอยดาบแบบริบบิ้น: สุ่มตำแหน่งปลายดาบย้อนหลังตามเส้นทางจริงของท่า
function swRibbon6(x,by,c,d,p,tier){const t0=SWPH[1]+.02;if(p<t0||p>SWPH[4])return;const span=.14,N=16,R=31,r0=12,al=p>SWPH[3]?1-(p-SWPH[3])/(SWPH[4]-SWPH[3]):1;
 const tp=[];for(let k=0;k<=N;k++){const t=Math.max(t0,Math.min(SWPH[3],p)-span*(1-k/N)),v=swPose6(c,d,t),sa=Math.sin(v[2]),ca=-Math.cos(v[2]);tp.push([x+v[0]+sa*R,by+v[1]+ca*R,x+v[0]+sa*r0,by+v[1]+ca*r0])}
 ctx.save();ctx.globalCompositeOperation='lighter';
 for(let k=0;k<N;k++){const a=tp[k],b=tp[k+1],w=(k+1)/N;ctx.globalAlpha=.75*al*w*w;ctx.fillStyle=tier.tr;ctx.beginPath();ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.lineTo(b[2],b[3]);ctx.lineTo(a[2],a[3]);ctx.closePath();ctx.fill()}
 ctx.lineCap='round';ctx.lineJoin='round';for(let k=0;k<N;k++){const a=tp[k],b=tp[k+1],w=(k+1)/N;ctx.globalAlpha=al*w*.55;ctx.strokeStyle=tier.gl;ctx.lineWidth=2+5*w;ctx.beginPath();ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.stroke();
  ctx.globalAlpha=al*w;ctx.strokeStyle='#fff';ctx.lineWidth=.8+1.6*w;ctx.stroke()}
 ctx.restore()}
function swFlash6(px,py,u,tier){if(u<0||u>1)return;ctx.save();ctx.globalCompositeOperation='lighter';ctx.globalAlpha=(1-u)*.9;ctx.fillStyle='#fff';ctx.translate(px,py);const s=3+7*e6o(u);
 ctx.beginPath();for(let i=0;i<8;i++){const a=i*Math.PI/4,r=i%2?s*.32:s;ctx.lineTo(Math.cos(a)*r,Math.sin(a)*r)}ctx.closePath();ctx.fill();ctx.globalAlpha=(1-u)*.5;ctx.strokeStyle=tier.gl;ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(0,0,s*1.3,0,7);ctx.stroke();ctx.restore()}
// ไหล่ที่จับดาบ: หน้า=ไหล่ขวาตัวละคร(ซ้ายจอ) · หลัง=ไหล่ขวา(ขวาจอ) · ข้าง=ไหล่ใกล้กล้อง
const swShoulder6=(x,by,d,f)=>d==='d'?[x-10,by-24]:d==='u'?[x+10,by-24]:[x+f*1,by-24];
{const _sf=slashFx;slashFx=function(x,by,d,side,f,TOP,held){if(!swOn6())return _sf(x,by,d,side,f,TOP,held);
  const p=P.at,tier=TIERS[(P.tier&&P.tier.sword)|0]||TIERS[0],[sx,sy]=swShoulder6(x,by,d,f);
  if(P.cmb===2){const {ang,sg,q}=spinInfo(),start=SPIN_BASE[P.spinDir||'d'],cx=x,cy=by-17;let rr=11,ry=7,da=0;
   if(p<SP6[0]){const u=e6o(p/SP6[0]);rr=11-4*u;ry=7-2*u;da=-sg*1.1*u}                    // เตรียม: ดึงดาบชิดตัว เอียงไปด้านหลัง
   else if(p<SP6[0]+.06){const u=(p-SP6[0])/.06;rr=7+4*u;ry=5+2*u;da=-sg*1.1*(1-u)}
   else if(p>SP6[2]){const u=e6io((p-SP6[2])/(1-SP6[2]));rr=11-3*u;da=sg*.7*u}           // คืนตัว: ลดดาบลง
   const hx=cx+Math.sin(ang)*rr,hy=cy-Math.cos(ang)*ry+(p>SP6[2]?3*e6io((p-SP6[2])/(1-SP6[2])):0);
   if(p>=SP6[0]&&p<SP6[2]+.06){const tail=ang-sg*Math.min(4.4,Math.abs(ang-start)),al=p>SP6[2]?1-(p-SP6[2])/.06:1;ctx.save();ctx.translate(cx,cy);ctx.scale(1,.68);slashTrail(0,0,tail,ang,44,tier,al);ctx.restore();if(p<SP6[1])tipSpark(cx,cy,ang,44,1,.68)}
   if(p>SP6[1]&&p<SP6[2]+.1){const u=(p-SP6[1])/(SP6[2]+.1-SP6[1]);ctx.save();ctx.globalAlpha=.5*(1-u);ctx.strokeStyle=tier.gl;ctx.lineWidth=3*(1-u)+1;ctx.beginPath();ctx.ellipse(x,by+2,14+30*e6o(u),5+10*e6o(u),0,0,7);ctx.stroke();ctx.restore();
    if(!window._drawingOther&&!P._sh6){P._sh6=1;try{shake(2.2,.12)}catch(e){}}}
   if(p<.1)P._sh6=0;
   swArm6(sx,sy,hx,hy,TOP,d==='d'?-1:d==='u'?1:f);held(hx,hy,ang+da);return}
  const c=P.cmb===1?1:0;let [ox,oy,ang]=swPose6(c,d,p);
  if(p>=SWPH[2]&&p<SWPH[3]){const u=(p-SWPH[2])/(SWPH[3]-SWPH[2]);const k=Math.sin(u*Math.PI*6)*(1-u)*.8;ox+=k;oy-=k*.5}   // แรงปะทะ: สั่นค้างเล็กน้อย
  const hx=x+ox,hy=by+oy;
  swRibbon6(x,by,c,d,p,tier);
  swArm6(sx,sy,hx,hy,TOP,d==='d'?-1:d==='u'?1:-f);
  held(hx,hy,ang);
  if(p>=SWPH[2]-.01){const R=31;swFlash6(hx+Math.sin(ang)*R,hy-Math.cos(ang)*R,(p-SWPH[2])/(SWPH[3]-SWPH[2]+.06),tier)}}}
// ท่าทางลำตัวระหว่างฟัน: เอน/ย่อ/บิด ทั้งตัว (ยึดเท้าไว้กับพื้น · ไม่ย้ายตำแหน่งตัวละครจริง)
{const _hb=heroBody;heroBody=function(){if(!swOn6())return _hb();const d=P.dir,f=d==='l'?-1:1,side=d==='l'||d==='r',p=P.at;
  const b=P.cmb===2?spinBody6(p):swBody6(P.cmb===1?1:0,d,p);const lean=b[0],dip=b[1],tw=b[2];
  const hxo=side?f*lean:tw,sq=1-Math.max(0,dip)*.012+Math.max(0,-dip)*.01;
  ctx.save();ctx.translate(P.x,P.y);ctx.transform(1,0,-hxo/44,1,0,0);ctx.scale(1,sq);ctx.translate(-P.x,-P.y);try{_hb()}finally{ctx.restore()}}}

// ---------- C. ค้อน: เอาออกจากช่องลัด · ใช้อัตโนมัติตอนก่อสร้าง (ท่าตอกตะปู) ----------
{const _qc=qCands;qCands=function(){return _qc().filter(c=>c.id!=='t_hamr')}}
{const _q=quickUseId;quickUseId=function(id){if(id==='t_hamr'){const i=QS.slots.indexOf(id);if(i>=0)QS.slots[i]=null;try{updQuick()}catch(e){}say('🔨 ค้อนจะหยิบใช้เองตอนสร้างบ้าน/สิ่งก่อสร้าง');return}return _q(id)}}
function hamClean6(){try{let ch=0;for(let i=0;i<QS.slots.length;i++)if(QS.slots[i]==='t_hamr'){QS.slots[i]=null;ch=1}if(QS.cur==='t_hamr')QS.cur=null;if(P.tool==='hamr'){P.tool=P.armor.sword?'sword':'axe';P.draw=false;ch=1}if(ch)updQuick()}catch(e){}}
setInterval(hamClean6,1500);
// รื้อของตกแต่ง (เดิมใช้ค้อนชี้) → หันหน้าเข้าหาแล้วกดปุ่มใช้/คุย
{const _ha=homeAct;homeAct=function(){const r=_ha();if(r)return r;try{const [tx,ty]=target(),Zm=ZCACHE[300],o=Zm&&Zm.oreAt[ty*HW+tx];if(o&&o.type==='bld'&&BLD[o.b.k]&&BLD[o.b.k].deco){askRemove(o.b);return true}}catch(e){}return false}}
// ท่าตอกตะปู: ระหว่างตอก ให้ระบบเดิมถือว่า "กำลังใช้เครื่องมือ" (ซ่อนแขนข้างที่ถือ ไม่ให้เป็น 3 แขน) แล้ววาดท่าตอกแทนท่าฟัน
const HAM6={on:0,t0:0,dur:1.5,x:0,y:0,n:-1};
function hamStart6(){HAM6.on=1;HAM6.t0=performance.now();HAM6.x=P.x;HAM6.y=P.y;HAM6.n=-1}
function hamLive6(){if(!HAM6.on)return false;const t=(performance.now()-HAM6.t0)/1000;if(t>HAM6.dur||Math.hypot(P.x-HAM6.x,P.y-HAM6.y)>3||P.dead||(D&&!D.home)){HAM6.on=0;return false}return true}
function hamPose6(x,by,d,f){const t=(performance.now()-HAM6.t0)/1000,per=.3,k=(t%per)/per,n=Math.floor(t/per);
 // ยกค้อน (0-.6) → ตอกลง (.6-.75) → ค้างแรงกระแทก (.75-1)
 const lift=k<.6?e6o(k/.6):k<.75?1-e6i((k-.6)/.15):0;let hx,hy,rot,nx,ny;
 if(d==='l'||d==='r'){hx=x+f*(7-2*lift);hy=by-12-9*lift;rot=f*(Math.PI/2-.05-1.25*lift);nx=x+f*27;ny=by-1}
 else if(d==='d'){hx=x+7;hy=by-14-9*lift;rot=.25+2.6*(1-lift);nx=x+12;ny=by+7}
 else{hx=x+9;hy=by-16-14*lift;rot=.1+.25*(1-lift);nx=x+5;ny=by-17}
 return{hx,hy,rot,nx,ny,n,k}}
{const _sf=slashFx;slashFx=function(x,by,d,side,f,TOP,held){if(!(HAM6.on&&P.tool==='hamr'&&!window._drawingOther))return _sf(x,by,d,side,f,TOP,held);
  const q=hamPose6(x,by,d,f),dn=Math.min(3,q.n*.8);
  // แผ่นไม้ + ตะปู (ตะปูจมลงทีละนิดตามจำนวนครั้งที่ตอก)
  ctx.fillStyle='#8a5a30';ctx.fillRect(q.nx-7,q.ny-1,14,3);ctx.fillStyle='#5a3a1c';ctx.fillRect(q.nx-7,q.ny+1,14,1);
  ctx.fillStyle='#c9ccd4';ctx.fillRect(q.nx-.5,q.ny-5+dn,1.5,4-dn);ctx.fillStyle='#e8eaf0';ctx.fillRect(q.nx-1.5,q.ny-5+dn,3.5,1);
  if(d==='d'){ctx.fillStyle=TOP;ctx.fillRect(x-14,by-26,6,12);ctx.fillStyle='#f1d2b0';ctx.fillRect(x-14,by-15,6,4)} // มืออีกข้างวางข้างตัว (ไม่หาย)
  const [sx,sy]=d==='d'?[x+10,by-24]:d==='u'?[x+10,by-24]:[x+f*1,by-24];swArm6(sx,sy,q.hx,q.hy,TOP,d==='l'||d==='r'?f:d==='u'?-1:1);
  ctx.save();ctx.translate(q.hx,q.hy);ctx.rotate(q.rot);if(f<0&&(d==='l'))ctx.scale(-1,1);ctx.drawImage(farmTool('hamr',HOME.tools.hamr|0),-21,-30,42,42);ctx.restore();
  ctx.fillStyle='#f1d2b0';ctx.fillRect(q.hx-3,q.hy-2,6,4);
  if(q.n!==HAM6.n&&q.k>=.75){HAM6.n=q.n;try{nz(.05,.45,2400,900,3);sfx('chop')}catch(e){}for(let i=0;i<5;i++)rfxP(q.nx,q.ny-4,(Math.random()-.5)*60,-30-Math.random()*40,.3,'255,230,160',1.6,'spark')}}}
{const _hb=heroBody;heroBody=function(){if(window._drawingOther||!hamLive6())return _hb();const d0=P.draw,t0=P.tool,a0=P.at;P.draw=true;P.tool='hamr';P.at=.001;
  try{_hb()}finally{P.draw=d0;P.tool=t0;P.at=a0}}}
{const _b=buildHouse;buildHouse=function(){const h0=HOME.house;_b();if(HOME.house>h0)setTimeout(hamStart6,120)}}
{const _c=confirmPlace;confirmPlace=function(){const n0=HOME.builds.length;_c();if(HOME.builds.length>n0)hamStart6()}}
