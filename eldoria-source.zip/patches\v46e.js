
// =====================================================================
// v4.6 (จ) : เล่นออนไลน์กับเพื่อนผ่านลิงก์หน้าเว็บ (ห้องสดของ claude.ai) — ไม่ต้องตั้งเซิร์ฟเวอร์
// =====================================================================
const RM={r:null,seen:{},chatN:0,joinT:0,names:{}};
const cleanS=(v,n)=>String(v==null?'':v).replace(/[\u0000-\u001f\u007f<>]/g,'').slice(0,n);
const numC=(v,a,b)=>{v=+v;return isFinite(v)?Math.max(a,Math.min(b,v)):0};
function roomSnap(){const r=RM.r;if(!r)return;const sc=netScene(),ps=[];let on=0;
 for(const p of r.peers()){const s=p.presence&&p.presence.s;if(!s||typeof s!=='object')continue;on++;if(p.sameTab)continue;if(s.sc!==sc)continue;
  const ar={};if(s.armor&&typeof s.armor==='object')for(const k of ['sword','helm','chest','pants','arm','neck','ring'])if(typeof s.armor[k]==='string'&&ITEMS[s.armor[k]])ar[k]=s.armor[k];
  ps.push({id:p.peer,x:numC(s.x,-1e5,1e5),y:numC(s.y,-1e5,1e5),dir:['u','d','l','r'].includes(s.dir)?s.dir:'d',mv:!!s.mv,run:!!s.run,at:numC(s.at,-1,1),cmb:numC(s.cmb,0,3)|0,tool:cleanS(s.tool,8),draw:!!s.draw,armor:ar,tier:{sword:numC(s.tier&&s.tier.sword,0,5)|0},lv:numC(s.lv,1,999)|0,name:cleanS(s.name,16)||'ผู้กล้า',dead:!!s.dead,cls:cleanS(s.cls,8)})}
 netMsg({t:'snap',on:Math.max(1,on),ps})}
function roomChat(change){for(const p of [...change.joined,...change.updated]){const c=p.presence&&p.presence.c;if(!c||typeof c!=='object')continue;const last=RM.seen[p.peer];RM.seen[p.peer]=c.i;
  if(last===undefined&&performance.now()-RM.joinT<4000&&!p.sameTab)continue;if(last===c.i||p.sameTab)continue;const s=p.presence.s||{};const nm=cleanS(s.name,16)||'ผู้กล้า';
  const txt=typeof chatClean==='function'?chatClean(cleanS(c.txt,140)):cleanS(c.txt,140);if(!txt)continue;
  try{_rmChatSay(c.ch==='guild'?'guild':'gen',nm+(p.guest?' (แขก)':''),txt,p.sameTab?'#fff0b0':'#9fd8ff')}catch(e){}
  if(!p.sameTab){const o=NET.others.get(p.peer);if(o)o.bub={txt:txt.slice(0,60),until:performance.now()+4500}}}
 for(const p of change.joined)if(!p.sameTab&&p.presence&&p.presence.s&&performance.now()-RM.joinT>3000)sysSay('🌐 '+(cleanS(p.presence.s.name,16)||'เพื่อน')+' เข้ามาเล่นแล้ว');
 for(const p of change.left){const s=p.presence&&p.presence.s;if(s)sysSay('🌐 '+(cleanS(s.name,16)||'เพื่อน')+' ออกจากเกม');NET.others.delete(p.peer);delete RM.seen[p.peer]}}
const _rmChatSay=chatSay;
function roomStart(r){RM.r=r;RM.joinT=performance.now();
 const shim={readyState:1,send(str){let d;try{d=JSON.parse(str)}catch(e){return}
   if(d.t==='st'){delete d.t;r.presence({s:d}).catch(()=>{})}
   else if(d.t==='chat'){RM.chatN++;r.presence({c:{i:RM.chatN+'-'+Date.now(),ch:d.ch==='guild'?'guild':'gen',txt:cleanS(d.txt,140)}}).catch(()=>{})}},close(){}};
 const live=()=>!SET.server;
 const up=()=>{if(!live())return;if(!NET.ws||NET.ws===shim){NET.ws=shim;NET.on=r.connected();netStatus()}};
 r.onConnection(c=>{if(!live())return;const was=NET.on;up();if(c&&!was&&!RM.hello){RM.hello=1;sysSay('🌐 ออนไลน์แล้ว! เพื่อนที่เปิดหน้านี้อยู่จะเห็นเราและแชทกันได้')}},()=>{if(NET.ws===shim){NET.ws=null;NET.on=false;NET.others.clear();netStatus()}});
 r.onPeers(ch=>{if(!live())return;up();roomChat(ch);roomSnap()},()=>{});
 setInterval(()=>{if(live()&&NET.ws===shim)roomSnap()},500)}
(async()=>{try{if(!window.claude||!claude.use)return;const r=await claude.use('room');if(!r)return;roomStart(r)}catch(e){}})();
// แชทระหว่างออนไลน์ผ่านห้อง: ข้อความของตัวเองแสดงตอนได้รับกลับ (กันซ้ำ)
{const st=document.createElement('style');st.textContent='#netb.on{box-shadow:0 0 0 2px #5ad06a,0 0 10px #5ad06a}';document.head.appendChild(st)}
setTimeout(()=>{try{const s=gid('netst');if(s&&s.parentNode&&!gid('nethint')){const h=document.createElement('div');h.id='nethint';h.style.cssText='font-size:11px;opacity:.85;margin:2px 0 6px;line-height:1.45';h.textContent='💡 เล่นกับเพื่อนง่ายสุด: แชร์ลิงก์หน้านี้ให้เพื่อน (เพื่อนต้องล็อกอิน Claude) ทุกคนที่เปิดหน้าเดียวกันจะเห็นกันและแชทกันได้ทันที — ไม่ต้องใส่ที่อยู่เซิร์ฟเวอร์';s.after(h)}}catch(e){}},1500);
