// =====================================================================
// v4.7.8 — รวมแก้ตามรายการ (UI/อุปกรณ์ · สกิล · ไอเท็ม/คราฟ · เกมเพลย์)
// หลัก: แก้เฉพาะจุด · ห่อด้วย try/catch · คืนสถานะใน finally · มีตัวตรวจ (validator)
// =====================================================================
function safe7(tag,fn){try{return fn()}catch(e){try{console.warn('[v478] '+tag,e)}catch(_){}return undefined}}
const FIN7=v=>typeof v==='number'&&isFinite(v);

// ---------- [ระบบชน] ใช้ชนให้ถูกฉาก: ดันเจี้ยนโซน=zHit · ในเมือง/ร้าน=dhit · ทุ่งหญ้า=hit ----------
function wHit7(x,y){try{if(!FIN7(x)||!FIN7(y))return true;if(D&&D.zone&&typeof zHit==='function')return zHit(x,y);if(D)return dhit(x,y);return hit(x,y)}catch(e){return false}}
window.wHit7=wHit7;

// =====================================================================
// 1) UI & อุปกรณ์
// =====================================================================
{const st=document.createElement('style');st.textContent=`
#set6{display:none!important}
#acts #atk{width:92px!important;height:92px!important;right:9px!important;bottom:9px!important;font-size:40px!important}
#ult6.nocls7{display:none!important}
/* เมนูตั้งค่า: กรอบไม้ขอบทอง */
#menu{background:linear-gradient(180deg,#3a2614 0%,#2a1a0c 100%)!important;border:3px solid #c8a24a!important;border-radius:14px!important;
 box-shadow:0 0 0 2px #5a3a14,0 0 0 5px #1a0f06,inset 0 0 0 1px rgba(255,233,160,.35),inset 0 0 26px rgba(0,0,0,.55),0 10px 30px rgba(0,0,0,.6)!important;padding-top:6px!important}
#menu .smh7{margin:-2px -6px 4px;padding:8px 10px 7px;text-align:center;font:900 15px/1 Georgia,'Times New Roman',serif;letter-spacing:3px;color:#ffe9a0;
 background:linear-gradient(180deg,#7a4a1c,#4a2a0e);border:2px solid #e8c14a;border-radius:10px;text-shadow:0 2px 0 #2a1406,0 0 8px rgba(255,200,80,.5);box-shadow:inset 0 1px 0 rgba(255,240,200,.4),0 2px 0 #1a0f06}
#menu .smh7 small{display:block;font:700 10px system-ui;letter-spacing:1px;color:#e8c890;opacity:.85;margin-top:3px}
#menu button{background:linear-gradient(180deg,#8a5a2a,#5a3414)!important;color:#ffe9c0!important;border:1.5px solid #e8c14a!important;border-radius:9px!important;
 box-shadow:0 3px 0 #2a1406,inset 0 1px 0 rgba(255,240,200,.45)!important;text-shadow:0 1px 0 #2a1406;transition:transform .06s}
#menu button:active{transform:translateY(2px);box-shadow:0 1px 0 #2a1406,inset 0 1px 0 rgba(255,240,200,.3)!important}
#menu .tabs6 button.on{background:linear-gradient(180deg,#ffe9a0,#d8b050)!important;color:#3a2408!important}
#menu select{background:#1e130a!important;border:1px solid #c8a24a!important;color:#ffe9c0!important}
#menu .sec{border-top:1px solid rgba(232,193,74,.45)!important;color:#ffd87a}
/* หน้าต่างเลือกอาชีพแบบการ์ด 3 ใบ */
#shop .cls7{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:7px;margin-top:6px}
#shop .cc7{position:relative;display:flex;flex-direction:column;gap:4px;padding:8px 7px;border-radius:12px;background:linear-gradient(180deg,rgba(255,255,255,.07),rgba(0,0,0,.25));border:2px solid var(--cc);text-align:left;min-width:0}
#shop .cc7.on{box-shadow:0 0 0 2px #fff,0 0 14px var(--cc)}
#shop .cc7 .ch{display:flex;align-items:center;gap:6px}#shop .cc7 .ch .e{font-size:26px;line-height:1;filter:drop-shadow(0 2px 2px #000)}
#shop .cc7 .ch b{color:var(--cc);font-size:14px;line-height:1.15}#shop .cc7 .ds{font-size:11px;opacity:.85;line-height:1.3}
#shop .cc7 .tt7{font:800 10.5px system-ui;color:#ffe9a0;margin-top:2px}
#shop .cc7 .sk{display:flex;gap:4px;flex-wrap:wrap}#shop .cc7 .sk span{display:flex;align-items:center;gap:3px;font-size:10px;background:rgba(0,0,0,.3);border-radius:6px;padding:2px 4px}
#shop .cc7 .sk img{width:18px;height:18px;border-radius:4px}
#shop .cc7 .ps small{display:block;font-size:10px;line-height:1.3;opacity:.95}#shop .cc7 .ps small.lk{opacity:.55}
#shop .cc7 button{margin-top:auto!important;width:100%!important;padding:6px!important;font-weight:800}
@media (max-width:560px){#shop .cls7{grid-template-columns:1fr}}
/* ไอคอนตำราสกิล */
.bk7{position:relative;display:inline-block;width:100%;height:100%}.bk7 img{position:absolute;inset:0;width:100%!important;height:100%!important}
.bk7 img.ov,.bk7 i.ov{inset:auto;left:27%;top:20%;width:46%!important;height:46%!important;border-radius:5px;box-shadow:0 0 0 1px #e8c14a,0 0 6px rgba(255,220,120,.6)}
.bk7 i.ov{position:absolute;font-style:normal;font-size:16px;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.35)}
/* เควสกิลด์ใต้เควสหลัก */
#qtrack .gq7{margin-top:5px;padding-top:4px;border-top:1px dashed rgba(255,233,160,.35)}
#qtrack .gq7 div{display:flex;justify-content:space-between;gap:6px;font-size:11px;line-height:1.35}#qtrack .gq7 div.ok{color:#9dff9a}
#qtrack .gq7 b{font-size:10.5px;color:#9fd8ff}
/* ส่งของเควส: ไอคอนบิน */
.fly7{position:absolute;z-index:60;width:30px;height:30px;pointer-events:none;transition:transform .7s cubic-bezier(.3,.1,.3,1),opacity .7s;filter:drop-shadow(0 0 6px #ffe9a0)}
.fly7.e{font-size:24px;display:flex;align-items:center;justify-content:center}
/* แท่นคริสตัลอรุณ */
#shop .alt7 .bar{height:12px;border-radius:7px;background:rgba(0,0,0,.4);border:1px solid #9fd8ff;overflow:hidden;margin:6px 0}#shop .alt7 .bar i{display:block;height:100%;background:linear-gradient(90deg,#ffe9a0,#9fd8ff)}
#shop .alt7 .gems{display:flex;gap:6px;justify-content:center;font-size:22px;margin:4px 0}#shop .alt7 .gems span.off{filter:grayscale(1);opacity:.35}
/* แลกของกิลด์: รายการวัตถุดิบ */
#shop .gx7{display:flex;flex-direction:column;gap:2px;font-size:11.5px;background:rgba(0,0,0,.25);border-radius:8px;padding:5px 7px}#shop .gx7 .ok{color:#9dff9a}#shop .gx7 .no{color:#ff9a8a}
`;document.head.appendChild(st)}

// ซ่อนวงแหวนพาสซีฟ/อัลติรอบรูปโปรไฟล์จนกว่าจะเลือกอาชีพ
setInterval(()=>safe7('ult6',()=>{const u=gid('ult6');if(u)u.classList.toggle('nocls7',P.cls==='none')}),300);

// หัวเมนูตั้งค่า "SYSTEM MENU"
function menuHead7(){safe7('menuHead',()=>{if(!menuEl||menuEl.querySelector('.smh7'))return;const h=document.createElement('div');h.className='smh7';h.innerHTML='⚜ SYSTEM MENU ⚜<small>ตั้งค่าเกม · ELDORIA</small>';menuEl.insertBefore(h,menuEl.firstChild);
 const b=menuEl.querySelector(':scope > b');if(b&&/ตั้งค่าเกม/.test(b.textContent))b.style.display='none'})}
menuHead7();setInterval(()=>{if(menuEl&&!menuEl.hidden)menuHead7()},400);

// สวมใส่: ใส่ช่องที่ถูกต้องอัตโนมัติ (เครื่องมือ→ช่องลัด) · ปิดหน้าต่างเลือก/กระเป๋า · รีเฟรช UI
{const _eq=equipItem;equipItem=function(id){let done=false;
 try{const it=ITEMS[id];if(!it)return;
  if(it.kind==='axe'||it.kind==='pick'){if(!(GEAR[id]>0)){say('ไม่มี'+it.name+'ในกระเป๋า');return}
   let j=QS.slots.indexOf(id);if(j<0){j=QS.slots.findIndex(s=>s&&ITEMS[s]&&ITEMS[s].kind===it.kind)}if(j<0)j=QS.slots.indexOf(null);if(j<0)j=QS.slots.length-1;
   for(let q=0;q<QS.slots.length;q++)if(q!==j&&QS.slots[q]===id)QS.slots[q]=null;QS.slots[j]=id;try{updQuick()}catch(e){}sfx('ui');say('🧰 ใส่'+it.name+'ในช่องลัด '+(j+1)+' แล้ว');done=true;return}
  const before=JSON.stringify(P.armor);_eq(id);done=JSON.stringify(P.armor)!==before}
 catch(e){console.warn('[v478] equip',e)}
 finally{if(done){try{CHS.sel=null}catch(e){}try{hideBag()}catch(e){}try{icClose()}catch(e){}try{if(typeof chp!=='undefined'&&!chp.hidden)renderChar()}catch(e){}try{refreshInv()}catch(e){}try{updQuick()}catch(e){}}}}}
window.equipItem=equipItem;

// เลือกอาชีพ: การ์ด 3 ใบ (สกิล + พาสซีฟอยู่ในการ์ด)
openClassMenu=function(){try{ZM.open=false;SHOPK=null;STN.open=null;hideBag();sfx('ui');const cur=P.cls;
 let h='<button class="mini x xclose" onclick="closeClassMenu()">✕</button><b>🎓 ปรมาจารย์อาชีพ — เลือกเส้นทางของเจ้า</b><small>อาชีพปัจจุบัน: '+CLS[cur].e+' '+CLS[cur].n+(cur==='none'?' · เลือกครั้งแรกฟรี':' · เปลี่ยนอาชีพ 500 🪙')+(P.lv<CLASS_LV?' · <span style="color:#ffd84a">🔒 ต้อง Lv.'+CLASS_LV+' (ตอนนี้ Lv.'+P.lv+')</span>':'')+'</small><div class="cls7">';
 for(const k of ['sword','mage','archer']){const C=CLS[k],L=CSKILLS[k]||[],PL=PASSIVE[k]||[];
  const sk=L.map(s=>{let u=null;try{u=skillIcon(s.n)}catch(e){}return '<span title="'+s.n+'">'+(u?'<img src="'+u+'">':s.e)+s.n+' <i style="opacity:.6;font-style:normal">Lv.'+s.lv+'</i></span>'}).join('');
  const ps=PL.map(p=>'<small class="'+(cur===k&&P.lv>=p.lv?'':'lk')+'">'+(cur===k&&P.lv>=p.lv?'🌟':'◇')+' '+p.n+' (Lv.'+p.lv+') — '+p.d+'</small>').join('');
  h+='<div class="cc7'+(cur===k?' on':'')+'" style="--cc:'+C.col+'"><div class="ch"><span class="e">'+C.e+'</span><b>'+C.n+'<br><small style="color:#fff;opacity:.7;font-weight:600">อาวุธ: '+WNAME[NEEDW[k]]+'</small></b></div>'
   +'<div class="ds">'+C.d+'</div><div class="tt7">🌟 ติดตัว: '+(C.pas||'-')+'</div><div class="tt7">⚔️ สกิล</div><div class="sk">'+sk+'</div><div class="tt7">🛡️ พาสซีฟ</div><div class="ps">'+ps+'</div>'
   +(cur===k?'<button class="mini" disabled>✓ อาชีพปัจจุบัน</button>':'<button class="mini ok" onclick="pickClass(\''+k+'\')">'+(cur==='none'?'เลือกเส้นทางนี้':'เปลี่ยน (500🪙)')+'</button>')+'</div>'}
 h+='</div>';shopEl.innerHTML=h;shopEl.hidden=false;CM.open=true}catch(e){console.warn('[v478] classMenu',e);try{CM.open=false;shopEl.hidden=true}catch(_){}}};
window.openClassMenu=openClassMenu;

// ร้านสกิล: ไม่ขายสกิลซ้ำกับสกิลอาชีพ · ซื้อซ้ำไม่ได้ · ไอคอนเป็น "ตำรา" + ไอคอนสกิลจริง
{const d=Object.getOwnPropertyDescriptor(SHOP_DATA.skill,'buy');if(d&&d.get){const g0=d.get;Object.defineProperty(SHOP_DATA.skill,'buy',{configurable:true,get(){let L=[];try{L=g0.call(this)}catch(e){L=[]}
  if(P.cls!=='none')L=L.filter(q=>!/^bsk[01]$/.test(q.id));return L.map(q=>{const m=/^bsk(\d)$/.exec(q.id);if(m&&SK.own[+m[1]])return Object.assign({},q,{price:0,note:'✅ เรียนแล้ว — '+q.note});return q})}})}}
{const _bi=buyItem;buyItem=function(id){const m=/^bsk(\d)$/.exec(id||'');if(m){const i=+m[1];if(SK.own[i]){say('✅ เรียนสกิลนี้แล้ว — ซื้อซ้ำไม่ได้');sfx('thud');return}
  if(P.cls!=='none'&&i<2){say('สกิลนี้ซ้ำกับสกิลอาชีพของคุณ — ไม่ต้องเรียนแล้ว');sfx('thud');return}}return _bi(id)}}
let BOOK7=null;function bookURL7(i){try{if(!BOOK7)BOOK7={};if(BOOK7[i])return BOOK7[i];const c=document.createElement('canvas');c.width=c.height=64;const q=c.getContext('2d'),col=['#7a2a8a','#a8341c','#2a7a4a'][i%3];
  q.fillStyle='rgba(0,0,0,.3)';q.beginPath();q.ellipse(32,58,22,4,0,0,7);q.fill();q.fillStyle='#f4ead0';q.fillRect(14,10,40,44);q.fillStyle='#d8c8a0';for(let k=0;k<5;k++)q.fillRect(16,14+k*8,36,1);
  q.fillStyle=col;q.strokeStyle='#1a0f06';q.lineWidth=2;q.beginPath();q.moveTo(10,8);q.lineTo(50,8);q.lineTo(50,52);q.lineTo(10,52);q.closePath();q.fill();q.stroke();
  q.fillStyle='rgba(0,0,0,.3)';q.fillRect(10,8,6,44);q.strokeStyle='#e8c14a';q.lineWidth=1.6;q.strokeRect(19,12,27,36);for(const [x,y] of [[10,8],[50,8],[10,52],[50,52]]){q.fillStyle='#e8c14a';q.beginPath();q.arc(x,y,3,0,7);q.fill()}
  q.fillStyle='rgba(255,255,255,.18)';q.fillRect(17,9,4,42);return BOOK7[i]=c.toDataURL()}catch(e){return ''}}
{const _bimg=bImg7;bImg7=function(b){const m=b&&/^bsk(\d)$/.exec(b.id||'');if(!m)return _bimg(b);const i=+m[1],S=(CSKILLS.none||[])[i]||{};let u=null;try{u=skillIcon(S.n)}catch(e){}
  return '<span class="bk7"><img src="'+bookURL7(i)+'">'+(u?'<img class="ov" src="'+u+'">':'<i class="ov">'+(S.e||'📖')+'</i>')+'</span>'}}

// เควสกิลด์ (เควสรอง) แสดงใต้เควสหลักแบบเรียลไทม์
function gqHTML7(){try{if(!QST||!QST.act||!QST.act.length)return '';return '<div class="gq7"><b>📜 เควสกิลด์</b>'+QST.act.map(q=>{const pr=q.t==='item'?Math.min(inv[q.k]|0,q.n):Math.min(q.c|0,q.n),ok=pr>=q.n;return '<div class="'+(ok?'ok':'')+'"><span>'+(ok?'✅ ':'• ')+q.d+'</span><span>'+pr+'/'+q.n+'</span></div>'}).join('')+'</div>'}catch(e){return ''}}
function gqUpd7(){safe7('gq',()=>{if(!qtEl)return;let g=qtEl.querySelector('.gq7');const h=gqHTML7();if(!h){if(g)g.remove();return}if(g){if(g.outerHTML!==h)g.outerHTML=h}else qtEl.insertAdjacentHTML('beforeend',h)})}
{const _ut=updTrack;updTrack=function(){const r=_ut.apply(this,arguments);gqUpd7();return r}}
setInterval(gqUpd7,500);

// ชื่อ/บทพูด NPC ร้านค้าแบบแฟนตาซีสากล (คงชื่อเล่นเดิมไว้ให้เนื้อเรื่องต่อเนื่อง)
safe7('names',()=>{const S=SHOP_DATA,set=(id,n,greet,lines)=>{const o=S[id]&&S[id].owner;if(!o)return;o.name=n;if(greet)o.greet=greet;if(lines)o.lines=lines};
 set('gear','บอริน "หนวดเหล็ก"',['ยินดีต้อนรับสู่โรงตีเหล็กของบอริน! เหล็กทุกชิ้นที่นี่ผ่านไฟร้อนแรงมาแล้ว','ฮึ่ม… อาวุธเจ้าบิ่นนะ อยากให้ข้าดูหน่อยไหม?','ค้อนข้ามีเรื่องเล่ามากกว่าที่เจ้าคิด'],
  ['แท่นตีบวกอยู่ขวามือ ส่วนโต๊ะคราฟอยู่ข้างหุ่นเกราะ','เหล็กดีต้องตีขณะยังแดง','อย่าลืมหินอวยพร ถ้าจะตีเกิน +5','ทุกตำนานเริ่มที่ทั่งตีเหล็ก']);
 set('potion','เอลาร่า นักปรุงยา',['สวัสดีค่ะนักเดินทาง ยาของเอลาร่าปรุงจากสมุนไพรแสงจันทร์','บาดเจ็บมาหรือคะ? ขวดนี้ช่วยได้แน่'],['ขนนกฟีนิกซ์หายากนะคะ ใช้ให้คุ้ม','ยามานาสีน้ำเงิน ยาเลือดสีแดง จำง่าย ๆ']);
 set('skill','อาร์คเมจไซเรียน',['ผู้แสวงหาความรู้… ตำราของข้าพร้อมแล้ว','เวทมนตร์ไม่ใช่พลัง แต่คือความเข้าใจ'],['ตำราพื้นฐานเหมาะกับผู้ยังไม่มีอาชีพ','เมื่อเลือกอาชีพ เจ้าจะได้สกิลเฉพาะสายเอง','เยียวยาใช้ได้ทุกอาชีพ']);
 set('store','มาร์ธา (ป้าแดง)',['มาจ้ะ ร้านของมาร์ธามีของใช้ครบ','จะออกผจญภัยต้องพกเสบียงนะลูก']);
 set('inn','โธมัส เจ้าของโรงเตี๊ยม',['เข้ามาก่อน! เบียร์เย็น ๆ กับสตูว์ร้อน ๆ รออยู่','โรงเตี๊ยมบัวหลวงยินดีต้อนรับนักผจญภัยเสมอ']);
 set('guild','ไอริส (พนักงานกิลด์)');set('fashion','มาดามโรส',['ยินดีต้อนรับสู่บูติกของมาดามโรสค่ะ ความงามคือพลังอย่างหนึ่ง'])});

// =====================================================================
// 2) สกิล
// =====================================================================
// อัญเชิญโครงกระดูก: จำกัด 3 ตัว · กัน NaN · ห่อ try/catch · ปล่อยสตันผู้เล่นทันที
const MaxSummonLimit=3;window.SUMREL7=0;
safe7('mspec',()=>{if(MSPEC.skel)MSPEC.skel.cap=MaxSummonLimit});
{const _s=summon;summon=function(k,n){try{if(!MSPEC[k])return;if(!FIN7(P.x)||!FIN7(P.y))return;n=Math.max(0,Math.min(MaxSummonLimit,(+n)|0));if(!n)return;
  _s(k,n);
  if(k==='skel'){const L=MIN.filter(m=>m.k==='skel');while(L.length>MaxSummonLimit){const o=L.shift();const j=MIN.indexOf(o);if(j>=0)MIN.splice(j,1)}}
  for(let i=MIN.length-1;i>=0;i--){const m=MIN[i];if(!m||!FIN7(m.x)||!FIN7(m.y)||!FIN7(m.l))MIN.splice(i,1)}}
 catch(e){console.warn('[v478] summon',e)}finally{window.SUMREL7=k==='skel'?2:1}}}
{const _mt=minTick;minTick=function(dt){try{if(!FIN7(dt))return;for(let i=MIN.length-1;i>=0;i--){const m=MIN[i];if(!m||!FIN7(m.x)||!FIN7(m.y)){MIN.splice(i,1);continue}if(m.tg&&(!FIN7(m.tg.x)||!FIN7(m.tg.y)))m.tg=null}
  _mt(dt)}catch(e){console.warn('[v478] minTick',e);try{for(let i=MIN.length-1;i>=0;i--){const m=MIN[i];if(!m||!FIN7(m.x)||!FIN7(m.y))MIN.splice(i,1);else{m.st='idle';m.tg=null}}}catch(_){}}}}
{const _p=playerTick;playerTick=function(dt){if(window.SUMREL7){window.SUMREL7--;if(!window.SUMREL7){P.stun=Math.min(P.stun,0);P.cast=Math.min(P.cast||0,.15)}}return _p(dt)}}

// ฟันวาปสายฟ้า: วาปเข้าใกล้เป้า (แก้ระบบชนในทุ่ง) + ฟ้าผ่า + ฟันรัว
{const _fs=flkStep;flkStep=function(){const ox=P.x,oy=P.y,mode=FLK.mode;try{_fs()}catch(e){console.warn('[v478] flk',e);FLK.on=false;P.stun=0;return}
 safe7('flkfx',()=>{if(mode==='bow'||(P.x===ox&&P.y===oy))return;let e=null,bd=60;for(const q of enemies()){const d=Math.hypot(q.x-P.x,q.y-P.y);if(d<bd){bd=d;e=q}}if(!e)return;
  const tx=e.x,ty=e.y;RFX.push({k:'bolt',x:tx+(Math.random()-.5)*20,y:ty-230,x2:tx,y2:ty-12,t:0,l:.22,rgb:'210,240,255'});RFX.push({k:'bolt',x:tx+(Math.random()-.5)*40,y:ty-200,x2:tx,y2:ty-12,t:0,l:.16,rgb:'150,200,255'});
  RFX.push({k:'ring',x:tx,y:ty,t:0,l:.3,rgb:'190,240,255',s:34});for(let i=0;i<3;i++){const a=Math.random()*6.28;vfx('slashline',tx-Math.cos(a)*16,ty-Math.sin(a)*10,.18+i*.04,{dx:Math.cos(a),dy:Math.sin(a)})}
  for(let i=0;i<8;i++)rfxP(tx,ty-14,(Math.random()-.5)*220,(Math.random()-.5)*160,.25,'230,250,255',2,'spark');tone(2400,600,.08,'square',.025)})}}
{const _ft=flkTick;flkTick=function(dt){try{return _ft(dt)}catch(e){console.warn('[v478] flkTick',e);FLK.on=false;P.stun=0}}}

// กระทืบปฐพี: กระโดด 3 ครั้งติดกันเข้าหามอนที่ใกล้สุด · คลื่นกระแทกขยายใหญ่ขึ้นทุกครั้ง
const SLAM7={j:null,land:false};
{const _p=playerTick;playerTick=function(dt){try{safe7('slam',()=>{const L=SLAM7.j,j=P.jump;
  if(L&&L.land&&!SLAM7.land){SLAM7.land=true;const n=L.n7|0;if(n>=2){const R=105+45*(n-1);vfx('shock',P.x,P.y,.6,{r:R});RFX.push({k:'ring',x:P.x,y:P.y,t:0,l:.5,rgb:'255,210,140',s:R});shake(4+n*2,.3);
    eachIn(P.x,P.y,R,e=>{const d=Math.hypot(e.x-P.x,e.y-P.y);if(d>100)hurtE(e,1.8*(1+.2*(n-1))*(L.mm7||1),{kb:200,stun:1})})}}
  if(L&&j!==L){// ท่าก่อนหน้าจบแล้ว
   SLAM7.j=null;if(!j&&(L.n7|0)<3&&!P.dead&&P.hp>0&&!(D&&(D.town||D.shop))){P.jump={t:0,l:.48,land:false,n7:(L.n7|0)+1,mm7:L.mm7};P.stun=Math.max(P.stun,.5);sfx('dash')}}
  if(P.jump&&P.jump!==SLAM7.j){if(!P.jump.n7)P.jump.n7=1;SLAM7.j=P.jump;SLAM7.land=!!P.jump.land}})}catch(e){}return _p(dt)}}

// อัลติเมท: ลดดาเมจพื้นฐาน + สะสม Fury จากการตีโดน (ยิ่งโดนมากยิ่งแรง)
const ULTM7={base:.55,per:.06,max:15};if(typeof ULT!=='undefined'){ULT.fury7=0;ULT.fT7=0}
{const _cu=castUlt;castUlt=function(){const was=!!ULT.cast;_cu.apply(this,arguments);if(!was&&ULT.cast){ULT.fury7=0;ULT.fT7=4}};window.castUlt=castUlt}
{const _h=hurtE;hurtE=function(e,mult,o){if(o&&o.ult&&FIN7(mult)){const f=Math.min(ULTM7.max,ULT.fury7|0);mult*=ULTM7.base*(1+f*ULTM7.per);const r=_h(e,mult,o);if(r){ULT.fury7=Math.min(ULTM7.max,(ULT.fury7|0)+1);ULT.fT7=3}return r}return _h(e,mult,o)}}
{const _h=hero;hero=function(){_h();safe7('fury',()=>{if(!(ULT.fT7>0)||!(ULT.fury7>0))return;ULT.fT7-=DT||.016;const f=ULT.fury7,x=P.x,y=P.y-70,a=Math.min(1,ULT.fT7);ctx.save();ctx.globalAlpha=a;ctx.font='900 12px system-ui';ctx.textAlign='center';
  ctx.lineWidth=3;ctx.strokeStyle='#2a0800';const s='🔥 FURY ×'+f+(f>=ULTM7.max?' MAX':'');ctx.strokeText(s,x,y);ctx.fillStyle=f>=ULTM7.max?'#ffe24a':'#ff9a4a';ctx.fillText(s,x,y);ctx.restore()})}}

// =====================================================================
// 3) ไอเท็ม / คราฟ
// =====================================================================
// ตัวอย่างสกินอาวุธ (มาดามโรส): หันหน้าเข้ากล้อง ถือดาบในมือ (ถ้าถือคทา/ธนู จะสลับเป็นดาบชั่วคราวเฉพาะภาพตัวอย่าง)
{const _fp=fashPreview;fashPreview=function(kind,id){if(kind==='body')return _fp(kind,id);
 const c=document.createElement('canvas');c.width=150;c.height=96;const k=c.getContext('2d'),sv=ctx,svW=FASH.wpn,sx=P.x,sy=P.y,sd=P.dir,sm=P.mv,sdr=P.draw,stl=P.tool,smo=MOUNT.on,ssw=P.armor.sword,sat=P.at;
 try{const g=k.createRadialGradient(75,70,4,75,60,80);g.addColorStop(0,'#5a4a7a');g.addColorStop(1,'#1a1428');k.fillStyle=g;k.fillRect(0,0,150,96);ctx=k;k.translate(75,88);k.scale(1.6,1.6);
  if(!ssw||isRng()){const sid=['sword0','sword1','sword2'].find(q=>ITEMS[q]&&ITEMS[q].kind==='sword')||Object.keys(ITEMS).find(q=>ITEMS[q].kind==='sword');if(sid)P.armor.sword=sid}
  P.x=0;P.y=0;P.dir='d';P.mv=false;P.draw=true;P.tool='sword';P.at=-1;MOUNT.on=false;FASH.wpn=id;hero()}
 catch(e){console.warn('[v478] fashPreview',e)}
 finally{ctx=sv;FASH.wpn=svW;P.x=sx;P.y=sy;P.dir=sd;P.mv=sm;P.draw=sdr;P.tool=stl;MOUNT.on=smo;P.armor.sword=ssw;P.at=sat}return c}}
// ดาบบนหลังใช้สกินอาวุธที่ตั้งไว้ด้วย
window.BACKSW7=0;
{const _bs=backSword;backSword=function(x,by,side,f,d){window.BACKSW7++;try{return _bs(x,by,side,f,d)}finally{window.BACKSW7--}}}
{const _ti=toolIcon;toolIcon=function(type,tier,sz){if(window.BACKSW7>0&&type==='sword'&&FASH.wpn&&typeof FWPN!=='undefined'&&FWPN[FASH.wpn]&&!isRng()){try{return fashSword(FASH.wpn)}catch(e){}}return _ti(type,tier,sz)}}

// แลกของกิลด์: ปุ่ม "🔁 แลก" + แสดงวัตถุดิบที่ต้องใช้ ✅/❌ · ราคาขนนกฟีนิกซ์ใหม่
const GX7={gx_estone:{core:2,dust:2},gx_estone2:{bone:6,rag:4},gx_bless:{scale:3},gx_phoenix:{wing:8,pelt:4}};
safe7('phoenixPrice',()=>{const p=SD.potion.buy.find(q=>q.id==='phoenix');if(p)p.price=600;
 const d=Object.getOwnPropertyDescriptor(SD.guild,'buy');if(d&&d.get){const g0=d.get;Object.defineProperty(SD.guild,'buy',{configurable:true,get(){return g0.call(this).map(q=>q.id==='gx_phoenix'?Object.assign({},q,{price:150,note:'ใช้ ปีกค้างคาว 8 + หนังหมาป่า 4 + 150 เหรียญ'}):q)}})}});
const gxMats7=id=>{const X=GX7[id];if(!X)return '';return '<div class="gx7"><b>🔁 วัตถุดิบที่ต้องใช้</b>'+Object.entries(X).map(([k,v])=>{const h=inv[k]|0;return '<span class="'+(h>=v?'ok':'no')+'">'+(h>=v?'✅ ':'❌ ')+MN(k)+' '+Math.min(h,v)+'/'+v+'</span>'}).join('')+'</div>'};
{const _bl=buyList;buyList=function(S){let h=_bl(S);try{const id=SHOP7.sel;if(id&&GX7[id]){const b=S.buy.find(q=>q.id===id);h=h.replace(/🛒 ซื้อ ×(\d+) · 🪙 ([\d,]+)/,'🔁 แลก ×$1 · 🪙 $2').replace('<div class="rw">',gxMats7(id)+'<div class="rw">')}}catch(e){}return h}}

// ตัวตรวจฐานข้อมูลไอเท็ม: ชื่อซ้ำ / ไอคอนซ้ำ / ค่าสเตตัสซ้ำ / ข้อมูลขาด
function validateItemDB7(){const R={items:0,mats:0,dupNames:[],dupIcons:[],dupStats:[],missing:[]};
 try{const byN={},byI={},byS={};for(const id in ITEMS){const it=ITEMS[id];R.items++;if(!it||!it.name||!it.kind){R.missing.push(id);continue}
   (byN[it.name]=byN[it.name]||[]).push(id);
   if(it.stat){const s=it.kind+'|'+it.stat;(byS[s]=byS[s]||[]).push(id)}
   let u='';try{u=iconURL('item:'+id)}catch(e){R.missing.push(id+':icon')}if(u)(byI[u]=byI[u]||[]).push(id)}
  for(const k in INVMETA){R.mats++;const m=INVMETA[k];if(!m||!m[0]){R.missing.push('mat:'+k);continue}(byN['mat:'+m[0]]=byN['mat:'+m[0]]||[]).push(k)}
  for(const n in byN)if(byN[n].length>1)R.dupNames.push(n.replace(/^mat:/,'')+' → '+byN[n].join(','));
  for(const u in byI)if(byI[u].length>1){const ns=new Set(byI[u].map(i=>ITEMS[i].name));if(ns.size>1)R.dupIcons.push(byI[u].join(','))}
  for(const s in byS)if(byS[s].length>1){const ns=new Set(byS[s].map(i=>ITEMS[i].name));if(ns.size>1)R.dupStats.push(s.split('|')[1]+' → '+byS[s].join(','))}}
 catch(e){R.error=String(e)}R.ok=!R.error&&!R.dupNames.length&&!R.missing.length;return R}
window.validateItemDB7=validateItemDB7;
// ตัวตรวจ UI: หน้าต่างต้องปิดได้และไม่ค้างสถานะ
function validateUI7(){const out=[];const chk=(n,f)=>{try{out.push([n,f()?'ok':'FAIL'])}catch(e){out.push([n,'ERR '+e.message])}};
 chk('bag ปิดได้',()=>{hideBag();return bagEl.hidden});chk('icard ปิดได้',()=>{icClose();return icEl.hidden});
 chk('shop ปิดได้',()=>{if(SHOPK)closeShop();return !SHOPK});chk('dialog ปิดได้',()=>{dlgClose(true);return !DLG.open});
 chk('ตีบวกไม่ค้าง',()=>!(ENHS.busy&&!FRG.on));chk('ไม่ PAUSED ค้าง',()=>{const m=!menuEl.hidden||!!document.querySelector('.p6w:not([hidden])');return m||!PAUSED});return out}
window.validateUI7=validateUI7;
{const _gr=gmRender;gmRender=function(){_gr();safe7('gmRow',()=>{const bd=gmW.querySelector('.bd');if(!bd)return;bd.insertAdjacentHTML('beforeend','<div class="card"><b style="color:#ffe9a0">ตัวตรวจระบบ (v4.7.8)</b><div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:6px"><button class="bt" onclick="gmIDB7()">🧪 ตรวจฐานข้อมูลไอเท็ม</button><button class="bt" onclick="gmUI7()">🧪 ตรวจการปิดหน้าต่าง</button><button class="bt" onclick="gmA(\'shards7\')">💎 เศษรูน ×30</button></div><div id="gmrep7" style="font-size:11px;white-space:pre-wrap;margin-top:6px;max-height:150px;overflow:auto"></div></div>')})}}
window.gmIDB7=()=>{const R=validateItemDB7(),el=gid('gmrep7');const t='ไอเท็ม '+R.items+' · วัตถุดิบ '+R.mats+'\nชื่อซ้ำ: '+(R.dupNames.join('\n')||'-')+'\nไอคอนซ้ำ (ต่างชื่อ): '+(R.dupIcons.join('\n')||'-')+'\nสเตตัสซ้ำ (ต่างชื่อ): '+(R.dupStats.join('\n')||'-')+'\nข้อมูลขาด: '+(R.missing.join(', ')||'-')+(R.error?'\nERROR '+R.error:'');if(el)el.textContent=t;say(R.ok?'🧪 ฐานข้อมูลไอเท็มผ่าน':'🧪 พบรายการที่ควรตรวจ — ดูในหน้า GM')};
window.gmUI7=()=>{const r=validateUI7(),el=gid('gmrep7');if(el)el.textContent=r.map(x=>x[1]+' · '+x[0]).join('\n');say('🧪 ตรวจ UI: '+r.filter(x=>x[1]==='ok').length+'/'+r.length+' ผ่าน')};
safe7('gmShard',()=>{GMA.shards7=()=>{inv.rshard=(inv.rshard|0)+30;refreshInv();say('💎 เศษรูน +30')}});

// ป้ายชื่อลอยเหนือวัตถุ
function plate7(txt,x,y,col){ctx.save();ctx.font='800 10.5px system-ui,"Noto Sans Thai",sans-serif';const w=ctx.measureText(txt).width+14,bob=Math.sin(performance.now()/500)*1.2;y+=bob;
 ctx.fillStyle='rgba(20,12,6,.82)';ctx.beginPath();if(ctx.roundRect)ctx.roundRect(x-w/2,y-11,w,16,8);else ctx.rect(x-w/2,y-11,w,16);ctx.fill();ctx.strokeStyle=col||'#e8c14a';ctx.lineWidth=1.3;ctx.stroke();
 ctx.fillStyle='#ffe9c0';ctx.textAlign='center';ctx.fillText(txt,x,y+1);ctx.restore()}

// ร้านตีเหล็ก: ทั่งขวา = แท่นตีบวก (ตีบวกอย่างเดียว) · หุ่นเกราะข้าง ๆ = โต๊ะคราฟ (สร้างของ)
const CB7={x:OX+14*T+16,y:6*T+30};
const CB7S={k:'anvil',craft:true,n:'🛠️ โต๊ะคราฟ · สร้างอุปกรณ์',x:CB7.x,y:CB7.y,py:CB7.y-8};
safe7('anvName',()=>{const s=SHOP_STN.gear.find(s=>s.k==='anvil');if(s){s.n='⚒️ แท่นตีบวก';s.py=ANV7.y}});
{const _sn=stnNear;stnNear=function(){try{if(D&&D.shop==='gear'&&!P.sit&&Math.hypot(P.x-CB7.x,P.y-CB7.y)<42&&Math.hypot(P.x-ANV7.x,P.y-ANV7.y)>=Math.hypot(P.x-CB7.x,P.y-CB7.y))return CB7S}catch(e){}return _sn()}}
{const _sa=shopAct;shopAct=function(){try{const s=stnNear();if(s&&s.craft&&!P.sit){if(!(typeof ENHS!=='undefined'&&ENHS.busy)){STN.tab='st';openForge('anvil')}return true}}catch(e){console.warn('[v478] bench',e)}return _sa()}}
function drawBench7(x,y){ctx.save();ctx.fillStyle='rgba(0,0,0,.3)';ctx.beginPath();ctx.ellipse(x,y+1,24,5,0,0,7);ctx.fill();
 ctx.fillStyle='#4a2c14';for(const lx of [-20,16])ctx.fillRect(x+lx,y-14,4,14);ctx.fillStyle='#3a2210';ctx.fillRect(x-19,y-6,36,3);
 const g=ctx.createLinearGradient(0,y-22,0,y-14);g.addColorStop(0,'#a8743e');g.addColorStop(1,'#6a4220');ctx.fillStyle=g;ctx.fillRect(x-24,y-22,48,8);ctx.strokeStyle='#24140a';ctx.lineWidth=1.2;ctx.strokeRect(x-23.5,y-21.5,47,7);
 ctx.fillStyle='rgba(0,0,0,.2)';for(const q of [-12,0,12])ctx.fillRect(x+q,y-21,1,6);
 ctx.fillStyle='#e8dcb8';ctx.save();ctx.translate(x-10,y-24);ctx.rotate(-.12);ctx.fillRect(-8,-4,16,7);ctx.strokeStyle='#8a6a3a';ctx.lineWidth=.6;for(let i=0;i<3;i++){ctx.beginPath();ctx.moveTo(-6,-2+i*2);ctx.lineTo(5,-2+i*2);ctx.stroke()}ctx.restore();
 ctx.fillStyle='#6b3f1f';ctx.fillRect(x+4,y-27,12,2.4);ctx.fillStyle='#8b97ab';ctx.fillRect(x+13,y-29,6,6);ctx.strokeStyle='#15161b';ctx.lineWidth=.8;ctx.strokeRect(x+13,y-29,6,6);
 ctx.fillStyle='#c8ccd6';ctx.beginPath();ctx.moveTo(x+2,y-23);ctx.lineTo(x+10,y-23);ctx.lineTo(x+9,y-25);ctx.closePath();ctx.fill();
 ctx.fillStyle='#5a3a1c';ctx.fillRect(x-22,y-36,3,14);ctx.fillStyle='#b8c0cc';ctx.fillRect(x-24,y-38,7,3);ctx.restore()}
{const _dm=drawMannequin;drawMannequin=function(x,y){if(D&&D.shop==='gear'&&Math.abs(x-CB7.x)<3&&Math.abs(y-CB7.y)<3){try{drawBench7(x,y)}catch(e){}return}return _dm(x,y)}}
{const _h=hero;hero=function(){_h();if(!(D&&D.shop==='gear'))return;safe7('plates',()=>{const ns=stnNear();plate7('⚒️ แท่นตีบวก',ANV7.x,ANV7.y-44,ns&&ns.k==='anvil'&&!ns.craft?'#fff':'#e8c14a');plate7('🛠️ โต๊ะคราฟ',CB7.x,CB7.y-46,ns&&ns.craft?'#fff':'#9fd8ff')})}}
// ปิดทางลัดคราฟในหน้าตีบวก (คราฟที่โต๊ะคราฟเท่านั้น)
safe7('enhCraftOff',()=>{window.enhCraft7=()=>say('🛠️ คราฟอุปกรณ์ได้ที่ "โต๊ะคราฟ" ข้างหุ่นเกราะ')});
// กันค้าง: เอฟเฟกต์/สถานะตีบวกต้องไม่ค้างหลังจบ
{const _fs=forgeStart7;forgeStart7=function(id,ok){try{return _fs(id,ok)}catch(e){console.warn('[v478] forgeStart',e);FRG.on=false;window.FRG7on=false;ENHS.busy=false;try{enhW.hidden=false}catch(_){}}}}
{const _fe=forgeEnd7;forgeEnd7=function(){try{return _fe()}catch(e){console.warn('[v478] forgeEnd',e)}finally{FRG.on=false;window.FRG7on=false;ENHS.busy=false;setTimeout(()=>{try{if(!FRG.on)FRG.sp.length=0}catch(e){}},900)}}}
setInterval(()=>safe7('frgWatch',()=>{if(FRG.on&&performance.now()-FRG.t0>(frgTotal()+2.5)*1000)forgeEnd7();if(!FRG.on&&ENHS.busy&&!window.FRG7on){ENHS.busy=false}}),500);

// =====================================================================
// รูน: ดรอปเป็น "เศษรูน" → รวม 5 เป็นรูนขั้น I ธาตุที่เลือก · หลอมได้ถึงขั้น V
// =====================================================================
RGR.push('IV','V');
safe7('runeV',()=>{for(const el in RUNE_EL)for(const g of [4,5]){const k='r_'+el+g,R=RUNE_EL[el];if(!RKEYS.includes(k))RKEYS.push(k);if(inv[k]===undefined)inv[k]=0;WT[k]=.1;
  INVMETA[k]=['รูน'+R.n+' '+RGR[g],'ใส่ในช่องรูนของอุปกรณ์ · อาวุธ: '+R.d+' · ชุดเกราะ: '+R.st.toUpperCase()+' +'+(g*2)+(g<5?' · รวม 3 ชิ้นเป็นขั้นถัดไปได้':' · ขั้นสูงสุด')];if(!INVORDER.includes(k))INVORDER.push(k)}
 for(const el in RUNE_EL)for(const g of [1,2,3]){const k='r_'+el+g;if(INVMETA[k])INVMETA[k][1]=INVMETA[k][1].replace('รวม 3 ชิ้นเป็นขั้นถัดไปได้','รวม 3 ชิ้นเป็นขั้นถัดไปได้ (สูงสุดขั้น V)')}
 if(inv.rshard===undefined)inv.rshard=0;WT.rshard=.02;INVMETA.rshard=['เศษรูน','เศษพลังรูนจากมอนสเตอร์ · รวม 5 ชิ้น สร้างรูนขั้น I ธาตุที่เลือกได้ (แตะในกระเป๋า)'];if(!INVORDER.includes('rshard'))INVORDER.push('rshard');
 SHOP_DATA.guild.sell=SHOP_DATA.guild.sell.concat([['rshard','เศษรูน',12]]).concat(Object.keys(RUNE_EL).flatMap(el=>[['r_'+el+'4',MN('r_'+el+'4'),2400],['r_'+el+'5',MN('r_'+el+'5'),7000]]))});
{const _pr=paintRune;paintRune=function(k,el,g){if(g<=3)return _pr(k,el,g);_pr(k,el,3);const R=RUNE_EL[el];k.save();const rim=g===4?'#c070ff':'#ffffff';
 k.strokeStyle=rim;k.lineWidth=2.2;k.beginPath();k.moveTo(24,3);k.lineTo(40,11);k.lineTo(42,31);k.lineTo(24,44);k.lineTo(6,31);k.lineTo(8,11);k.closePath();k.stroke();
 if(g===5){const gl=k.createRadialGradient(24,23,4,24,23,24);gl.addColorStop(0,'rgba(255,255,255,0)');gl.addColorStop(.7,'rgba('+R.rgb+',.0)');gl.addColorStop(1,'rgba('+R.rgb2+',.55)');k.fillStyle=gl;k.beginPath();k.arc(24,23,24,0,7);k.fill();
  k.fillStyle='#fff';for(const [x,y] of [[24,1],[44,22],[4,22]]){k.beginPath();k.moveTo(x,y-3);k.lineTo(x+1,y);k.lineTo(x,y+3);k.lineTo(x-1,y);k.closePath();k.fill()}}
 k.fillStyle=rim;k.fillRect(8,36,32,6);k.fillStyle='rgba(0,0,0,.6)';k.fillRect(9,37,30,4);k.fillStyle=rim;for(let i=0;i<g;i++){k.beginPath();k.arc(24+(i-(g-1)/2)*5.5,39,1.6,0,7);k.fill()}k.restore()}}
{const _mi=matIcon;matIcon=function(key){if(key!=='rshard')return _mi(key);const c=document.createElement('canvas');c.width=c.height=48;const k=c.getContext('2d');k.lineJoin='round';
 k.fillStyle='rgba(0,0,0,.25)';k.beginPath();k.ellipse(24,40,13,4,0,0,7);k.fill();const cols=['#ff6a2a','#7fd8ff','#ffe24a','#7be04a','#ff3a5a'];
 [[14,24,-.4],[27,18,.3],[22,32,.1],[33,30,-.2]].forEach(([x,y,r],i)=>{k.save();k.translate(x,y);k.rotate(r);const g=k.createLinearGradient(-6,-9,6,9);g.addColorStop(0,'#9a9aa8');g.addColorStop(1,'#3a3a46');k.fillStyle=g;k.strokeStyle='#16161c';k.lineWidth=1.4;
  k.beginPath();k.moveTo(0,-10);k.lineTo(7,-2);k.lineTo(3,9);k.lineTo(-6,6);k.lineTo(-7,-3);k.closePath();k.fill();k.stroke();k.strokeStyle=cols[i%5];k.lineWidth=1.6;k.beginPath();k.moveTo(-2,-5);k.lineTo(2,0);k.lineTo(-1,5);k.stroke();k.restore()});
 const gl=k.createRadialGradient(24,24,1,24,24,20);gl.addColorStop(0,'rgba(220,200,255,.45)');gl.addColorStop(1,'rgba(220,200,255,0)');k.fillStyle=gl;k.fillRect(0,0,48,48);return c}}
safe7('runeImg',()=>{for(const k of RKEYS.concat(['rshard'])){if(DROPIMG[k]&&k.slice(-1)<'4')continue;const im=new Image();im.src=iconURL('mat:'+k);DROPIMG[k]=im}});
{const _ad=addDrop;addDrop=function(type,x,y){try{const m=/^r_([a-z]+)(\d)$/.exec(type||'');if(m&&RUNE_EL[m[1]]){const n=+m[2]>=2?3:1;for(let i=0;i<n;i++)_ad('rshard',x,y);return}}catch(e){}return _ad(type,x,y)}}
function runeFromShard7(el){try{if(!RUNE_EL[el])return;if((inv.rshard|0)<5){say('ต้องมีเศษรูน 5 ชิ้น (มี '+(inv.rshard|0)+')');sfx('thud');return}const k='r_'+el+'1',c=canTake(k);if(c!==true){noRoom(c);return}
 inv.rshard-=5;inv[k]=(inv[k]|0)+1;refreshInv();sfx('gem');const R=RUNE_EL[el];say(R.e+' สร้าง'+MN(k)+'สำเร็จ!');for(let i=0;i<22;i++)rfxP(P.x,P.y-30,(Math.random()-.5)*160,-40-Math.random()*120,.8,R.rgb,2.4,'spark');try{handIn7(['mat:rshard'],1)}catch(e){}icShow('mat',(inv.rshard|0)>0?'rshard':k)}
 catch(e){console.warn('[v478] shard',e)}}
window.runeFromShard7=runeFromShard7;
fuseRune=function(k){try{const r=runeOf(k);if(!r||r.g>=5)return;const cost=150*r.g;if((inv[k]|0)<3){say('ต้องมี '+MN(k)+' 3 ชิ้น');sfx('thud');return}if(inv.coin<cost){say('ต้องใช้ '+cost+' เหรียญ');sfx('thud');return}
 inv[k]-=3;inv.coin-=cost;const nk='r_'+r.el+(r.g+1);inv[nk]=(inv[nk]|0)+1;refreshInv();sfx('chest');say('💠 หลอมรวมสำเร็จ! ได้ '+MN(nk));for(let i=0;i<30+r.g*6;i++)rfxP(P.x,P.y-30,(Math.random()-.5)*200,-40-Math.random()*150,.9,RUNE_EL[r.el].rgb,2.5,'spark');icShow('mat',(inv[k]>0)?k:nk)}
 catch(e){console.warn('[v478] fuse',e)}};window.fuseRune=fuseRune;
{const _ic=icShow;icShow=function(t,k,ro,at){const r0=_ic.apply(this,arguments);safe7('icRune',()=>{if(ro||t!=='mat')return;let add='';const r=runeOf(k);
  if(k==='rshard'){add=Object.keys(RUNE_EL).map(el=>'<button class="'+((inv.rshard|0)>=5?'ok':'no')+'" onclick="runeFromShard7(\''+el+'\')">'+RUNE_EL[el].e+' รูน'+RUNE_EL[el].n+' I (5 เศษ)</button>').join('')}
  else if(r&&(r.g===3||r.g===4))add='<button class="'+((inv[k]|0)>=3?'ok':'no')+'" onclick="fuseRune(\''+k+'\')">💠 หลอม 3 → '+RGR[r.g+1]+' ('+150*r.g+'🪙)</button>';
  if(!add)return;let ib=icEl.querySelector('.ib');if(!ib){ib=document.createElement('div');ib.className='ib';icEl.appendChild(ib)}ib.insertAdjacentHTML('beforeend',add)});return r0}}

// =====================================================================
// 4) เกมเพลย์
// =====================================================================
// แอนิเมชันส่งของเควส: ไอคอนบิน + เอฟเฟกต์/เสียง (dir 1 = ส่งออกจากกระเป๋า, -1 = ได้รับรางวัล)
function handIn7(keys,dir){try{const wr=gid('wrap');if(!wr||!keys||!keys.length)return;const W=wr.clientWidth,H=wr.clientHeight;
 keys.slice(0,6).forEach((key,i)=>{let el;if(/^(item|mat):/.test(key)){el=document.createElement('img');try{el.src=iconURL(key)}catch(e){return}}else{el=document.createElement('div');el.className='e';el.textContent=key}el.classList.add('fly7');
  const sx=dir>0?W*.5-15:W*.5-15+(i-keys.length/2)*26,sy=dir>0?H-70:H*.32,ex=dir>0?W*.5-15+(i-keys.length/2)*20:W*.5-15,ey=dir>0?H*.3:H-70;
  el.style.left=sx+'px';el.style.top=sy+'px';el.style.transform='scale(.6)';el.style.opacity='0';wr.appendChild(el);
  setTimeout(()=>{el.style.opacity='1';el.style.transform='translate('+(ex-sx)+'px,'+(ey-sy)+'px) scale(1.15) rotate('+(dir>0?-20:20)+'deg)'},40+i*90);
  setTimeout(()=>{el.style.opacity='0';el.style.transform+=' scale(.4)'},760+i*90);setTimeout(()=>{try{el.remove()}catch(e){}},1500+i*90)});
 for(let i=0;i<18;i++)rfxP(P.x+(Math.random()-.5)*30,P.y-20-Math.random()*20,(Math.random()-.5)*120,-60-Math.random()*90,.8,'255,230,140',2.2,'spark');
 RFX.push({k:'ring',x:P.x,y:P.y,t:0,l:.5,rgb:'255,230,140',s:40});sfx('coin');setTimeout(()=>sfx('gem'),380);tone(660,990,.25,'triangle',.04,.2)}catch(e){console.warn('[v478] handIn',e)}}
window.handIn7=handIn7;
{const _qc=qClaim;qClaim=function(i){const q=QST.act[i],n0=QST.act.length;const keys=q?(q.t==='item'?['mat:'+q.k]:['📜']):[];_qc(i);if(QST.act.length<n0){handIn7(keys,1);setTimeout(()=>handIn7(['🪙','✨'].concat(q&&q.es?['mat:estone']:[]),-1),650)}}}

// เควสช่าง (ตำราช่าง): ข้อความสั้น · รายการของ ✅/❌ · แลกได้เมื่อครบเท่านั้น
function smList7(n){return Object.entries(SMQ[n].need).map(([k,v])=>{const h=inv[k]|0;return (h>=v?'✅ ':'❌ ')+MN(k)+' '+Math.min(h,v)+'/'+v}).join('\n')}
function smOk7(n){return Object.entries(SMQ[n].need).every(([k,v])=>(inv[k]|0)>=v)}
smithQuest=function(){try{const o=D.owner,n=smNext(),nm=(SD.gear.owner&&SD.gear.owner.name)||'ช่างหนวดเหล็ก';if(!n){talk(o,'เจ้าเรียนตำราครบทุกระดับแล้ว!',[BYE]);return}const Q=SMQ[n];
 if(P.lv<Q.lv){talk(o,'ตำรา'+TNAMES[n]+' ต้อง Lv.'+Q.lv+' ก่อนนะ',[BYE]);return}
 if(SMITH.q!==n){SMITH.q=n;saveSmith();sysSay('⚒️ เควสช่าง: '+Q.n)}
 const ok=smOk7(n);talk(o,'📜 '+Q.n+'\n'+smList7(n)+(ok?'\n\nของครบแล้ว! ส่งมาได้เลย':''),ok?[{t:'⚒️ ส่งของ แลกตำรา',c:'go',f:()=>smithDeliver7(n)},BYE]:[{t:'🗺️ หาของได้ที่ไหน',stay:true,f:()=>talk(o,Q.w,[BYE])},BYE],nm)}
 catch(e){console.warn('[v478] smithQuest',e)}};
function smithDeliver7(n){try{if(smNext()!==n||!smOk7(n)){say('ของยังไม่ครบ');return}const Q=SMQ[n],keys=Object.keys(Q.need).map(k=>'mat:'+k);
 for(const [k,v] of Object.entries(Q.need))inv[k]-=v;SMITH.u=n;SMITH.q=0;saveSmith();refreshInv();sfx('chest');shake(2,.2);handIn7(keys,1);
 try{banner('⚒️ ปลดล็อก'+Q.n.replace('ตำราช่าง: ',''),'คราฟชุด/อาวุธระดับ'+TNAMES[n]+'ได้ที่โต๊ะคราฟ','')}catch(e){}
 talk(D.owner,'ฝีมือใช้ได้! ตอนนี้เจ้าตีของระดับ'+TNAMES[n]+'ได้แล้ว — ไปที่โต๊ะคราฟข้างหุ่นเกราะ',[BYE])}catch(e){console.warn('[v478] smithDeliver',e)}}
window.smithQuest=smithQuest;window.smithDeliver7=smithDeliver7;
safe7('ch2',()=>{STCH[2].intro='ดาบหินสู้อสูรในเหมืองไม่ไหวแล้ว! ไปหาบอริน "หนวดเหล็ก" ที่โรงตีเหล็ก รับตำราช่าง แล้วตีอาวุธเหล็กด้วยมือเจ้าเอง (Lv.5)';STCH[2].d='Lv.5 + รับตำราช่าง แล้วตีอาวุธเหล็กเอง'});

// พระราชา: กันรับรางวัลซ้ำ (ปิดหน้าต่างก่อนจบแล้วคุยใหม่ จะไม่ได้รางวัลซ้ำ)
function kingRw7(r){try{STORY.paid=STORY.paid||{};const ch=STORY.ch;if(STORY.paid[ch]){const L=[];if(r){if(r.coin)L.push('🪙 '+r.coin+' (รับแล้ว)')}return L}
  STORY.paid[ch]=1;saveStory();const L=giveRw(r);if(L&&L.length)setTimeout(()=>handIn7(['🪙','✨','📜'],-1),300);return L}catch(e){console.warn('[v478] kingRw',e);return []}}
window.kingRw7=kingRw7;

// มอนติดแร่/สิ่งกีดขวาง: ไถลไปด้านข้างเมื่อเดินชน
{const _mv=mvM;mvM=function(m,dx,dy){const x0=m.x,y0=m.y;_mv(m,dx,dy);try{if(m.x===x0&&m.y===y0&&(dx||dy)){const L=Math.hypot(dx,dy)||1,s=m.sl7||(m.sl7=Math.random()<.5?-1:1),px=-dy/L*s*L,py=dx/L*s*L;
  if(!zHit(m.x+px,m.y+py)){m.x+=px;m.y+=py;m.slT7=.4}else{m.sl7=-s}}else if(m.slT7>0)m.slT7-=.016}catch(e){}}}

// แยก NPC ในเมืองไม่ให้ยืนซ้อนกัน
setInterval(()=>safe7('npcSep',()=>{if(!(D&&D.town&&D.npcs))return;const N=D.npcs;for(let i=0;i<N.length;i++)for(let j=i+1;j<N.length;j++){const a=N[i],b=N[j];if(!a||!b||a.vis===false||b.vis===false)continue;const dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy);
  if(d<18){const ux=d?dx/d:1,uy=d?dy/d:0,push=(18-d)/2;for(const [n,sg] of [[a,-1],[b,1]]){if(n.fixed||n===DLG.n)continue;const nx=n.x+ux*push*sg,ny=n.y+uy*push*sg;if(!dhit(nx,ny)){n.x=nx;n.y=ny}}}}}),120);

// ม้า: หันขึ้น/ลง วาดม้าแบบหน้า/หลัง (ย่อส่วน) + ผู้ขี่มุมหน้า/หลัง · คูลดาวน์ขึ้น-ลง 1.2 วิ
function drawSteedUD7(k,x,y,dir,A,ph){try{const K=MPAL[k]||MPAL.horse,t=performance.now()/1000,g=t*(A?9.5:0),wolf=k==='wolf';ctx.save();ctx.translate(x,y);ctx.lineJoin='round';
 if(ph===0){ctx.fillStyle='rgba(0,0,0,.28)';ctx.beginPath();ctx.ellipse(0,1,17,5,0,0,7);ctx.fill();
  [[-9,0,1],[9,Math.PI,1],[-4,Math.PI*.5,.85],[4,Math.PI*1.5,.85]].sort((a,b)=>a[2]-b[2]).forEach(([lx,ph2,s])=>{const lift=A?Math.max(0,Math.sin(g*2+ph2))*3.5:0;ctx.fillStyle=s<1?K.s:K.leg;ctx.fillRect(lx-2.2,-19*s-lift,4.4,19*s);ctx.fillStyle='#1a120c';ctx.fillRect(lx-2.4,-3*s-lift,4.8,3)});
  if(dir==='u'&&!wolf){ctx.fillStyle=K.b;ctx.beginPath();ctx.ellipse(0,-50,5.5,8,0,0,7);ctx.fill();ctx.fillStyle=K.m;ctx.fillRect(-1.5,-58,3,14);ctx.fillStyle=K.b;for(const s of [-1,1]){ctx.beginPath();ctx.moveTo(s*2,-56);ctx.lineTo(s*5,-63);ctx.lineTo(s*6,-55);ctx.closePath();ctx.fill()}}
  if(dir==='u'&&wolf){ctx.fillStyle=K.b;for(const s of [-1,1]){ctx.beginPath();ctx.moveTo(s*2,-50);ctx.lineTo(s*6,-60);ctx.lineTo(s*8,-49);ctx.closePath();ctx.fill()}}
  const bg=ctx.createRadialGradient(-4,-34,2,0,-27,15);bg.addColorStop(0,K.hi);bg.addColorStop(.6,K.b);bg.addColorStop(1,K.s);ctx.fillStyle=bg;ctx.strokeStyle='rgba(0,0,0,.45)';ctx.lineWidth=1.2;ctx.beginPath();ctx.ellipse(0,-27,13,14,0,0,7);ctx.fill();ctx.stroke();
  ctx.fillStyle='#6a3a1a';ctx.beginPath();ctx.ellipse(0,-37,12.5,4.5,0,0,7);ctx.fill();ctx.fillStyle='#c89a3a';ctx.fillRect(-12,-37.5,24,1.4)}
 else{if(dir==='d'){const nod=A?Math.sin(g*2)*1.2:0;ctx.translate(0,nod);
   if(wolf){ctx.fillStyle=K.b;ctx.beginPath();ctx.ellipse(0,-38,9,9,0,0,7);ctx.fill();for(const s of [-1,1]){ctx.beginPath();ctx.moveTo(s*3,-45);ctx.lineTo(s*8,-55);ctx.lineTo(s*9,-42);ctx.closePath();ctx.fill()}ctx.fillStyle=K.hi;ctx.beginPath();ctx.ellipse(0,-32,5,4.5,0,0,7);ctx.fill();ctx.fillStyle='#111';ctx.beginPath();ctx.arc(0,-33,1.6,0,7);ctx.fill();for(const s of [-1,1]){ctx.fillStyle='#9fd8ff';ctx.fillRect(s*4-1,-40,2.4,2)}}
   else{ctx.fillStyle=K.b;ctx.strokeStyle='rgba(0,0,0,.45)';ctx.lineWidth=1.1;ctx.beginPath();ctx.moveTo(-6,-50);ctx.quadraticCurveTo(-8,-38,-5,-27);ctx.quadraticCurveTo(0,-22,5,-27);ctx.quadraticCurveTo(8,-38,6,-50);ctx.quadraticCurveTo(0,-54,-6,-50);ctx.closePath();ctx.fill();ctx.stroke();
    ctx.fillStyle=K.s;ctx.beginPath();ctx.ellipse(0,-27.5,5,3.6,0,0,7);ctx.fill();ctx.fillStyle='#120a06';for(const s of [-1,1]){ctx.beginPath();ctx.arc(s*2,-27,1,0,7);ctx.fill();ctx.beginPath();ctx.arc(s*5.6,-43,1.2,0,7);ctx.fill()}
    for(const s of [-1,1]){ctx.fillStyle=K.b;ctx.beginPath();ctx.moveTo(s*3,-51);ctx.lineTo(s*6,-59);ctx.lineTo(s*7,-50);ctx.closePath();ctx.fill();ctx.stroke()}
    ctx.fillStyle=K.m;ctx.beginPath();ctx.moveTo(-4,-52);ctx.quadraticCurveTo(0,-46,4,-52);ctx.quadraticCurveTo(0,-55,-4,-52);ctx.fill();
    ctx.strokeStyle='#3a2210';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(-6,-33);ctx.lineTo(6,-33);ctx.stroke();
    if(k==='unicorn'){ctx.fillStyle='#ffd23a';ctx.beginPath();ctx.moveTo(-1.6,-53);ctx.lineTo(0,-64);ctx.lineTo(1.6,-53);ctx.closePath();ctx.fill()}}}
  else{const sw=A?Math.sin(g)*3:Math.sin(t*2)*1.5;ctx.strokeStyle=K.m;ctx.lineWidth=wolf?5:4;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(0,-26);ctx.quadraticCurveTo(sw,-16,sw*1.4,-7);ctx.stroke()}}
 ctx.restore()}catch(e){try{ctx.restore()}catch(_){}}}
window.drawSteedUD7=drawSteedUD7;
{let lastM=0;const _tm=toggleMount;toggleMount=function(){const n=performance.now();if(n-lastM<1200)return;lastM=n;return _tm()};try{mountB.onclick=()=>toggleMount()}catch(e){}}

// สัตว์เลี้ยง: ซ่อนตอนขี่ม้า · เพิ่มค่าสเตตัส + แสดงโบนัสในหน้าสเตตัส
{const _dp=drawPet;drawPet=function(p,x,y){if(typeof MOUNT!=='undefined'&&MOUNT.on&&HOME.mount&&x===PET.x)return;return _dp(p,x,y)}}
const PETST7={dog:{str:2,vit:2},cat:{agi:2,int:2}};
{const _cb=calcBonus;calcBonus=function(){const b=_cb();try{const s=HOME.pet&&PETST7[HOME.pet];if(s)for(const k in s)b[k]=(b[k]|0)+s[k]}catch(e){}return b}}
{let lp=null;setInterval(()=>safe7('petBonus',()=>{const p=HOME.pet||null;if(p!==lp){lp=p;applyBonus();try{recalcStats()}catch(e){}refreshInv()}}),700)}
{const _rc=renderChar;renderChar=function(){_rc();safe7('petCard',()=>{if(!HOME.pet)return;const el=gid('chl');if(!el)return;const s=PETST7[HOME.pet]||{},x=PAX(),nm={str:'STR',vit:'VIT',agi:'AGI',int:'INT',end:'END'};
  const L=Object.entries(s).map(([k,v])=>nm[k]+' +'+v);const xs=[['crit','คริ'],['cdmg','คริแรง'],['dmg','ดาเมจ'],['pen','เจาะบอส'],['dr','ลดดาเมจ'],['cres','ต้านคริ']].filter(([k])=>x[k]).map(([k,n])=>n+' +'+Math.round(x[k]*100)+'%');
  el.insertAdjacentHTML('beforeend','<div class="sp on" style="flex-direction:column;align-items:flex-start">🐾 โบนัสสัตว์เลี้ยง ('+(HOME.pet==='dog'?'หมาชิบะ':HOME.pet==='cat'?'แมวส้ม':HOME.pet)+')<small style="opacity:.9">'+(L.concat(xs).join(' · ')||'-')+'</small></div>')})}}

// GM วาปไปเหมือง: ปิดหน้าต่าง/ลงจากม้า/ลุกจากที่นั่งก่อน แล้วตรวจว่าเข้าโซนจริง
{const _gz=gmZone;gmZone=function(i){try{try{dlgClose(true)}catch(e){}try{if(SHOPK)closeShop()}catch(e){}P.sit=null;if(MOUNT.on){MOUNT.on=false;try{mountB.classList.remove('on')}catch(e){}}
  _gz(i);if(!(D&&D.zone&&!D.home))say('GM: วาปไม่สำเร็จ ลองอีกครั้ง');else say('GM: วาปไป '+ZONES[i].n+' แล้ว')}catch(e){say('GM: '+e.message)}};window.gmZone=gmZone}

// ขอบเมืองด้านขวา → ที่ดินผู้กล้า (กำแพงล่องหนจนกว่าจะปราบบอสสุดท้าย)
const homeOpen7=()=>!!(HOME.unlocked||STORY.done);
{let lastMsg=0;const _dh=dhit;dhit=function(x,y){if(D&&D.town&&!homeOpen7()&&x+7>=(TW-1)*T&&y>14*T&&y<19*T){const n=performance.now();if(n-lastMsg>2500){lastMsg=n;say('🔒 ทางไปที่ดินผู้กล้า — เปิดหลังปราบบอสสุดท้าย ('+ABYSS.n+')');sfx('thud')}return true}return _dh(x,y)}}
{const _ex=exitD;exitD=function(){if(D&&D.town&&P.x>(TW-3)*T){if(homeOpen7()){try{if(!HOME.unlocked){HOME.unlocked=1;try{saveHome()}catch(e){}}const sv=dsav;exitD.busy7=1;enterHome();if(sv&&sv.length&&!(dsav&&dsav.length))dsav=sv}catch(e){console.warn('[v478] toHome',e)}finally{exitD.busy7=0}}else{P.x=(TW-2)*T}return}return _ex()}}

// ระยะคุยกับเจ้าของร้านสั้นลง + ปิดร้าน/บทสนทนาอัตโนมัติเมื่อเดินออกห่าง
let SHOPOPN7=false;
{const _os=openShop;openShop=function(id){const r=_os(id);try{SHOPOPN7=!!(D&&D.shop&&id===D.shop&&shopNear())}catch(e){SHOPOPN7=false}return r}}
setInterval(()=>safe7('autoClose',()=>{
 if(SHOPK&&SHOPOPN7&&D&&D.shop&&D.owner){const o=D.owner;if(Math.hypot(P.x-o.x,P.y-o.y)>(D.shop==='hall'?140:100)){SHOPOPN7=false;closeShop()}}
 if(DLG.open&&DLG.n&&FIN7(DLG.n.x)&&DLG.D===D&&!(typeof CINE!=="undefined"&&CINE.L&&!cineEl.hidden)&&!(INN6&&INN6.st)){if(Math.hypot(P.x-DLG.n.x,P.y-DLG.n.y)>130)dlgClose(true)}}),300);

// ออร่าชุดเกราะระดับสูง: วงแหวนสวรรค์ด้านหลังตัวละคร (แทนปีก/รัศมีเดิม)
{const _af=armorFx;armorFx=function(){const a=_af();if(window.AURACAP7&&a&&a.L>35)a.L=35;return a}}
{const _da=drawArmorAura;drawArmorAura=function(back){let A=null;try{A=_af7()}catch(e){}
 if(back&&A&&A.n>0&&A.L>=21){window.AURACAP7=1;try{_da(back)}finally{window.AURACAP7=0}safe7('ring',()=>{const t=performance.now()/1000,x=P.x,y=P.y-30,rgb=A.rgb,lv=A.L,R=19+Math.min(9,(lv-21)*.25),al=Math.min(.85,.35+(lv-21)*.015);
   ctx.save();ctx.globalCompositeOperation='lighter';ctx.translate(x,y);
   const gl=ctx.createRadialGradient(0,0,R*.4,0,0,R*1.5);gl.addColorStop(0,'rgba('+rgb+',0)');gl.addColorStop(.6,'rgba('+rgb+','+(al*.35)+')');gl.addColorStop(1,'rgba('+rgb+',0)');ctx.fillStyle=gl;ctx.beginPath();ctx.arc(0,0,R*1.5,0,7);ctx.fill();
   ctx.strokeStyle='rgba(255,245,210,'+al+')';ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,0,R,0,7);ctx.stroke();ctx.strokeStyle='rgba('+rgb+','+al*.8+')';ctx.lineWidth=1;ctx.beginPath();ctx.arc(0,0,R-4,0,7);ctx.stroke();
   ctx.save();ctx.rotate(t*.6);ctx.fillStyle='rgba(255,250,230,'+al+')';for(let i=0;i<12;i++){ctx.rotate(Math.PI/6);ctx.fillRect(R-2.5,-.8,5,1.6)}ctx.restore();
   ctx.save();ctx.rotate(-t*.9);for(let i=0;i<(lv>=40?6:4);i++){const a=i/(lv>=40?6:4)*6.283;ctx.fillStyle='rgba(255,255,255,'+al+')';ctx.beginPath();ctx.arc(Math.cos(a)*(R+4),Math.sin(a)*(R+4),1.8,0,7);ctx.fill()}ctx.restore();
   if(lv>=52){ctx.strokeStyle='rgba(255,230,150,'+(al*.7)+')';ctx.setLineDash([3,4]);ctx.lineDashOffset=-t*20;ctx.beginPath();ctx.arc(0,0,R+9,0,7);ctx.stroke();ctx.setLineDash([])}
   ctx.restore()});return}
 return _da(back)}}
function _af7(){return armorFx()}

// แท่นคริสตัลอรุณ (ท้องพระโรง): แสดงความคืบหน้าเศษผลึกอรุณ (STORY.shards/5)
const ALT7={x:OX+4.6*T,y:9.3*T,open:false};
function drawAltar7(){const x=ALT7.x,y=ALT7.y,t=performance.now()/1000,n=Math.max(0,Math.min(5,STORY.shards|0));ctx.save();
 ctx.fillStyle='rgba(0,0,0,.3)';ctx.beginPath();ctx.ellipse(x,y+1,22,6,0,0,7);ctx.fill();
 const g=ctx.createLinearGradient(x-16,0,x+16,0);g.addColorStop(0,'#8a8a9a');g.addColorStop(.5,'#e8e8f0');g.addColorStop(1,'#7a7a8a');ctx.fillStyle=g;ctx.strokeStyle='#3a3a48';ctx.lineWidth=1.2;
 ctx.beginPath();ctx.moveTo(x-20,y);ctx.lineTo(x+20,y);ctx.lineTo(x+16,y-6);ctx.lineTo(x-16,y-6);ctx.closePath();ctx.fill();ctx.stroke();ctx.fillRect(x-10,y-26,20,20);ctx.strokeRect(x-10,y-26,20,20);
 ctx.beginPath();ctx.moveTo(x-16,y-26);ctx.lineTo(x+16,y-26);ctx.lineTo(x+13,y-31);ctx.lineTo(x-13,y-31);ctx.closePath();ctx.fill();ctx.stroke();ctx.fillStyle='#c8a24a';ctx.fillRect(x-10,y-18,20,2);
 for(let i=0;i<5;i++){const a=-Math.PI/2+i/5*6.283+t*.4,px=x+Math.cos(a)*15,py=y-48+Math.sin(a)*6,on=i<n;ctx.fillStyle=on?'#ffe9a0':'rgba(120,130,150,.6)';ctx.beginPath();ctx.moveTo(px,py-4);ctx.lineTo(px+2.5,py);ctx.lineTo(px,py+4);ctx.lineTo(px-2.5,py);ctx.closePath();ctx.fill()}
 ctx.globalCompositeOperation='lighter';const fy=y-48+Math.sin(t*2)*2,gl=ctx.createRadialGradient(x,fy,1,x,fy,20+n*3);gl.addColorStop(0,'rgba(255,240,190,'+(.35+n*.1)+')');gl.addColorStop(1,'rgba(160,215,255,0)');ctx.fillStyle=gl;ctx.beginPath();ctx.arc(x,fy,20+n*3,0,7);ctx.fill();
 ctx.globalCompositeOperation='source-over';ctx.fillStyle=n>=5?'#fff6d0':'#bfe4ff';ctx.strokeStyle='#4a6a9a';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x,fy-11);ctx.lineTo(x+6,fy-2);ctx.lineTo(x,fy+9);ctx.lineTo(x-6,fy-2);ctx.closePath();ctx.fill();ctx.stroke();
 ctx.fillStyle='rgba(255,255,255,.7)';ctx.beginPath();ctx.moveTo(x,fy-9);ctx.lineTo(x-4,fy-2);ctx.lineTo(x,fy-1);ctx.closePath();ctx.fill();ctx.restore()}
{const _h=hero;hero=function(){if(!(D&&D.shop==='hall'))return _h();try{if(ALT7.y<=P.y+3){drawAltar7();_h()}else{_h();drawAltar7()}plate7('💎 แท่นคริสตัลอรุณ',ALT7.x,ALT7.y-68,Math.hypot(P.x-ALT7.x,P.y-ALT7.y)<46?'#fff':'#9fd8ff')}catch(e){console.warn('[v478] altar',e)}}}
{const _es=enterShop;enterShop=function(id){const r=_es(id);try{if(id==='hall'&&typeof dm!=='undefined'){const tx=Math.floor(ALT7.x/T),ty=Math.floor((ALT7.y-4)/T);if(dm[ty])dm[ty][tx]=WL}}catch(e){}return r}}
function openAltar7(){try{const n=Math.max(0,Math.min(5,STORY.shards|0));SHOPK=null;STN.open=null;hideBag();sfx('ui');
 shopEl.innerHTML='<div class="alt7"><button class="mini x xclose" onclick="closeAltar7()">✕</button><b>💎 แท่นคริสตัลอรุณ</b><small>แท่นศักดิ์สิทธิ์ที่รอเศษผลึกอรุณทั้งห้า เมื่อครบ แสงอรุณจะกลับมาปกป้องเอลโดเรีย</small>'
  +'<div class="gems">'+[0,1,2,3,4].map(i=>'<span class="'+(i<n?'':'off')+'">💎</span>').join('')+'</div><div class="bar"><i style="width:'+(n/5*100)+'%"></i></div><small>เศษผลึกอรุณ '+n+'/5 · '+(n>=5?'✨ ครบแล้ว! พลังอรุณตื่นขึ้น':'ได้จากการทำภารกิจหลักของพระราชา')+'</small></div>';
 shopEl.hidden=false;ALT7.open=true}catch(e){console.warn('[v478] openAltar',e);ALT7.open=false}}
function closeAltar7(){ALT7.open=false;try{shopEl.hidden=true}catch(e){}sfx('ui')}
window.openAltar7=openAltar7;window.closeAltar7=closeAltar7;
{const _sa=shopAct;shopAct=function(){if(D&&D.shop==='hall'&&!P.sit&&Math.hypot(P.x-ALT7.x,P.y-ALT7.y)<46){if(ALT7.open)closeAltar7();else openAltar7();return true}return _sa()}}
setInterval(()=>{if(ALT7.open&&!(D&&D.shop==='hall'&&Math.hypot(P.x-ALT7.x,P.y-ALT7.y)<80))closeAltar7()},300);
// ปุ่มกด E ใกล้แท่น: ป้ายกระพริบ
{const _h=hero;hero=function(){_h();if(D&&D.shop==='hall'&&!ALT7.open&&Math.hypot(P.x-ALT7.x,P.y-ALT7.y)<46)safe7('altChip',()=>plate7('กด E / ⚔️ ดูแท่น',ALT7.x,ALT7.y+18,'#ffe27a'))}}

// เวอร์ชัน
try{window.FM_VER='4.7.8'}catch(e){}
// แผงแท่นคริสตัลไม่ถูกปิดโดยระบบปิดร้านอัตโนมัติ (ระยะเจ้าของร้าน)
{const _us=updShop;updShop=function(dt){_us(dt);if(ALT7.open&&shopEl.hidden&&D&&D.shop==='hall')shopEl.hidden=false}}
// บทสนทนาขึ้นบรรทัดใหม่ได้ (รายการของเควส)
{const st=document.createElement('style');st.textContent='#dlg .dtxt{white-space:pre-line}';document.head.appendChild(st)}
// โต๊ะคราฟ: เปิดเฉพาะแท็บคราฟ (ตีบวกต้องไปที่แท่นตีบวก)
window.BENCH7=false;
{const _of=openForge;openForge=function(k){const r=_of(k);safe7('benchTabs',()=>{let s=null;try{s=stnNear()}catch(e){}window.BENCH7=!!(k==='anvil'&&s&&s.craft);if(!window.BENCH7)return;
  if(STN.tab!=='st'&&STN.tab!=='bag'){STN.tab='st';return _of(k)}
  for(const b of shopEl.querySelectorAll('button'))if(/ตีบวก/.test(b.textContent)&&!/คราฟ/.test(b.textContent))b.remove();
  const h=shopEl.querySelector('b');if(h&&/ทั่งตีเหล็ก/.test(h.textContent))h.textContent='🛠️ โต๊ะคราฟ — สร้างอุปกรณ์'});return r}}
