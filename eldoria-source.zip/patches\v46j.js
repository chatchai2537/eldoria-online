
// =====================================================================
// v4.7 (ญ) : แก้บั๊ก/ปรับตามรายงาน — ของไม่ไหลตามเมื่อกระเป๋าเต็ม · กระทืบปฐพีกระโดดเข้าหามอน · ปุ่มสกิลเรียงโค้ง
//  เมนูโปรไฟล์ (ไอคอน) · ทั่งตีเหล็กตั้งพื้นตีได้จริง · ชำนาญสกิล (พาสซีฟผูกกับสกิล) · ร้านค้า/ตีบวกแบบช่องไอคอน + "หาได้จาก"
// =====================================================================
// ---------- 1) ของตก: ไม่ดูดเข้าหาตัวถ้ากระเป๋ารับไม่ได้ ----------
window.dropOK7=d=>{try{const ik=DROPMAP[d.type]||d.type;return ik==='coin'||canTake(ik)===true}catch(e){return true}};

// ---------- 2) กระทืบปฐพี: กระโดดพุ่งเข้าหามอนใกล้สุด แล้วลงกระแทกตรงนั้น ----------
{const _p=playerTick;playerTick=function(dt){const j=P.jump;
  if(j&&!j.tg7){j.tg7=1;let best=null,bd=230;for(const e of enemies()){if(e.dead)continue;const d=Math.hypot(e.x-P.x,e.y-P.y);if(d<bd){bd=d;best=e}}
   const v=DIRV[P.dir];let tx=P.x+v[0]*60,ty=P.y+v[1]*60;if(best){const d=bd||1;const stop=Math.max(0,d-16);tx=P.x+(best.x-P.x)/d*stop;ty=P.y+(best.y-P.y)/d*stop;P.dir=Math.abs(best.x-P.x)>Math.abs(best.y-P.y)?(best.x<P.x?'l':'r'):(best.y<P.y?'u':'d')}
   j.sx=P.x;j.sy=P.y;j.tx=tx;j.ty=ty}
  if(j&&j.tg7&&!j.land){const u=Math.min(1,(j.t+dt)/(j.l*.8)),e=1-Math.pow(1-u,2),nx=j.sx+(j.tx-j.sx)*e,ny=j.sy+(j.ty-j.sy)*e;if(!hit(nx,P.y))P.x=nx;if(!hit(P.x,ny))P.y=ny}
  const prev=window.CURSK7;if(j&&j.mm7)window.CURSK7={m:j.mm7};try{return _p(dt)}finally{window.CURSK7=prev}}}

// ---------- 3) ปุ่มสกิลเรียงโค้งรอบปุ่มโจมตี · ปุ่มขวาบนไม่ทับสกิล ----------
{const st=document.createElement('style');st.textContent=`
#acts #dashb{right:97px!important;bottom:3px!important}
#acts #sk1{right:147px!important;bottom:29px!important}#acts #sk2{right:134px!important;bottom:83px!important}
#acts #sk3{right:100px!important;bottom:123px!important}#acts #sk5{right:49px!important;bottom:145px!important}
#acts #sk4{right:82px!important;bottom:82px!important}
#acts #ultb{right:195px!important;bottom:71px!important;pointer-events:auto}
#setb{display:none!important}
#gmb{z-index:3!important}`;document.head.appendChild(st)}
setTimeout(()=>{try{const u=gid('ultb'),a=gid('acts');if(u&&a&&u.parentNode!==a)a.appendChild(u)}catch(e){}},500);
// คอลัมน์ขวา: กระเป๋า · เสียง · ออโต้ · ออนไลน์ เรียงชิดกัน (ตั้งค่าย้ายไปเมนูโปรไฟล์)
function rcol7(){try{const b=gid('bagb');if(!b)return;const h=b.offsetHeight||48,t=b.offsetTop;let i=1;for(const id of ['muteb','autob','netb']){const e=gid(id);if(!e)continue;e.style.setProperty('top',(t+i*(h+6))+'px','important');i++}}catch(e){}}
addEventListener('resize',()=>setTimeout(rcol7,100));setTimeout(rcol7,600);setInterval(rcol7,3000);

// ---------- 4) กดรูปโปรไฟล์ → เมนูไอคอน (สถานะ · สกิล · พาสซีฟ · กระเป๋า · เควส · ตั้งค่า · ออกเกม) ----------
{const st=document.createElement('style');st.textContent=`
#pm7{position:absolute;z-index:28;left:calc(8px + var(--sl,0px));top:calc(64px + var(--st,0px));display:grid;grid-template-columns:repeat(4,58px);gap:6px;padding:8px;border-radius:14px;background:linear-gradient(180deg,rgba(40,30,60,.96),rgba(18,14,28,.96));border:2px solid #e8c14a;box-shadow:0 8px 24px rgba(0,0,0,.6);animation:pm7in .14s ease-out}
#pm7[hidden]{display:none}@keyframes pm7in{from{transform:translateY(-6px);opacity:0}to{transform:none;opacity:1}}
#pm7 button{width:58px!important;height:58px!important;min-width:0!important;padding:4px 0 0!important;border-radius:12px;border:1.5px solid rgba(232,193,74,.55);background:radial-gradient(circle at 50% 35%,#4a3a6a,#1e1830);color:#fff;font-size:22px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;cursor:pointer}
#pm7 button small{font:700 9.5px system-ui,"Noto Sans Thai",sans-serif;opacity:.95}
#pm7 button:active{transform:scale(.94)}#pm7 button.out{border-color:#ff8a7a;background:radial-gradient(circle at 50% 35%,#6a2a2a,#2a1010)}`;document.head.appendChild(st)}
const pm7=document.createElement('div');pm7.id='pm7';pm7.hidden=true;gid('wrap').appendChild(pm7);pm7.addEventListener('pointerdown',e=>e.stopPropagation());
const PM7=[['👤','สถานะ',()=>toggleChar()],['⚔️','สกิล',()=>openSkw('sk')],['🌟','พาสซีฟ',()=>openSkw('pas')],['🎯','ชำนาญ',()=>openSkw('msk')],['🎒','กระเป๋า',()=>toggleBag()],['📜','เควส',()=>openJournal()],['⚙️','ตั้งค่า',()=>toggleMenu()],['🚪','ออกเกม',()=>exitGame7(),'out']];
pm7.innerHTML=PM7.map((m,i)=>'<button data-i="'+i+'" class="'+(m[3]||'')+'">'+m[0]+'<small>'+m[1]+'</small></button>').join('');
pm7.onclick=e=>{const b=e.target.closest('button');if(!b)return;pm7.hidden=true;sfx('ui');try{PM7[+b.dataset.i][2]()}catch(er){}};
faceEl.onclick=e=>{e.stopPropagation();pm7.hidden=!pm7.hidden;sfx('ui')};
addEventListener('pointerdown',e=>{if(!pm7.hidden&&!pm7.contains(e.target)&&e.target!==faceEl)pm7.hidden=true});
function exitGame7(){talk({name:'ออกจากเกม',c:'#c0503a'},'บันทึกเกมแล้วกลับไปหน้าแรกไหม?',[{t:'🚪 บันทึกและออก',c:'go',f:()=>{try{saveGame(true)}catch(e){}setTimeout(()=>location.reload(),250)}},BYE],'🚪 ออกเกม')}

// ---------- 5) "หาได้จากที่ไหน" (แหล่งของ: มอนที่ดรอป · เหมือง · ร้าน · คราฟ) ----------
function mobsOf7(fam){const L=[];for(const z of ZONES)for(const m of z.mobs)if(m[0]===fam)L.push(m[1]+' · '+z.e+' '+z.n);
 if(['skeleton','zombie','bat'].includes(fam))L.push('มอนในดันเจี้ยน (ทุกชั้น)');if(fam==='drake')L.push('มังกรในดันเจี้ยนชั้นลึก');return L}
function src7(key){const S=[],add=(i,t)=>S.push([i,t]);
 if(key.startsWith('item:')){const it=ITEMS[key.slice(5)];if(!it)return S;add('⚒️','คราฟที่ทั่งตีเหล็ก (ร้านอุปกรณ์) — ปลดล็อกระดับด้วยเควสช่าง');if(it.tier===0)add('🏪','ซื้อที่ร้านอุปกรณ์');add('🎁','สมบัติในดันเจี้ยน / รางวัลเควส');return S}
 const k=key.replace(/^mat:/,'');
 if(k==='coin'){add('⚔️','มอนสเตอร์ทุกตัว');add('💰','ขายของที่ร้าน · รางวัลเควส');return S}
 if(k==='gel'){add('🟢','สไลม์ · ทุ่งหญ้ารอบเมือง');return S}
 if(k==='wood'||k==='apple'){add('🪓','ตัดต้นไม้ด้วยขวาน (ทุ่งหญ้า)');return S}
 if(k==='coal'){add('🔥','เผาไม้ที่เตาหลอม');return S}
 if(k==='gem'){add('💎','ขุดแร่เพชร');const z=ZONES.find(z=>z.id==='diamond');if(z)add('👑',z.boss.n+' · '+z.n);return S}
 const zr=ZONES.filter(z=>z.ores.some(o=>o[0]===k));for(const z of zr)add('⛏️','ขุดแร่ใน '+z.e+' '+z.n+' (Lv.'+z.lv[0]+'–'+z.lv[1]+')');
 for(const z of ZONES)if(z.raw===k||z.ing===k)add('👑','บอส '+z.boss.n+' · '+z.n);
 const ti=MATKEY.indexOf(k);if(ti>=0)add('🔥','หลอมแร่ที่เตาหลอม (ร้านอุปกรณ์)');
 if(JUNK[k])for(const m of mobsOf7(JUNK[k][3]))add('⚔️',m);
 if(k==='hpp'||k==='mpp')add('⚗️','ปรุงเองที่หม้อปรุงยา (ร้านยาหมอใจดี)');
 if(k==='estone'){add('🏰','มอนในดันเจี้ยน (ยิ่งลึกยิ่งดรอปบ่อย)');add('📜','รางวัลเควสกิลด์ · ช่างหนวดเหล็ก');add('🔁','แลกที่กิลด์ (แกนหินเวท + ผงวิญญาณ / กระดูก + ผ้า)')}
 if(k==='bless'){add('📜','รางวัลเควสเนื้อเรื่อง/เควสกิลด์');add('🔁','แลกที่กิลด์ (เกล็ดมังกร ×3)')}
 if(k==='phoenix'){add('👑','บอส 35% · มอนอีลิท 3%');add('🔁','แลกที่กิลด์')}
 if(/^r_/.test(k))add('👑','บอส · มอนอีลิท · มอนในดันเจี้ยน');
 if(/^pa_/.test(k))add('🐾','บอส/อีลิทในดันเจี้ยน · หายากจากสไลม์');
 if(/^sd_/.test(k))add('🏪','ร้านฟาร์ม (ลุงบุญมี) ที่ดินผู้กล้า');
 if(typeof CROPS!=='undefined'&&CROPS[k])add('🌱','ปลูกในที่ดินผู้กล้า');
 if(typeof FISHES!=='undefined'&&FISHES[k])add('🎣','ตกปลา (บ่อในที่ดิน/แหล่งน้ำ)');
 for(const id in SD2){const s=SD2[id];if(!s||!s.buy)continue;for(const b of (Array.isArray(s.buy)?s.buy:[]))if(b.mat===k||b.id===k||b.item===k){add('🏪','ซื้อที่ '+(s.name||id));break}}
 if(!S.length)add('❔','ยังไม่มีข้อมูลแหล่งที่มา');return S}
function srcHTML7(key){return '<div class="src7">'+src7(key).map(s=>'<div><span>'+s[0]+'</span>'+s[1]+'</div>').join('')+'</div>'}
window.srcToggle7=function(btn,key){const n=btn.nextElementSibling;if(n&&n.classList.contains('src7')){n.remove();btn.classList.remove('on');return}btn.insertAdjacentHTML('afterend',srcHTML7(key));btn.classList.add('on');sfx('ui')};
const srcBtn7=key=>'<button class="srcb7" onclick="event.stopPropagation();srcToggle7(this,\''+key+'\')">📍 หาได้จากที่ไหน</button>';
{const st=document.createElement('style');st.textContent=`
.srcb7{font:800 11.5px system-ui,"Noto Sans Thai",sans-serif;padding:4px 9px;border-radius:9px;border:1px solid #6ab0e8;background:#13304a;color:#bfe4ff;cursor:pointer;margin-top:4px}.srcb7.on{background:#bfe4ff;color:#13304a}
.src7{margin-top:5px;display:flex;flex-direction:column;gap:3px;font-size:11.5px;text-align:left}.src7 div{display:flex;gap:6px;align-items:flex-start;padding:4px 7px;border-radius:8px;background:rgba(80,140,200,.14)}.src7 span{flex:none}`;document.head.appendChild(st)}
// ใส่ปุ่มในการ์ดรายละเอียดไอเท็มเดิม (กดของในกระเป๋า)
{const _ic=icShow;icShow=function(t,k,ro,at){_ic(t,k,ro,at);try{if(icEl.hidden||icEl.querySelector('.srcb7'))return;const key=(t==='gear'?'item:':'mat:')+k;const host=icEl.querySelector('.ib,.ic-b,.body')||icEl.firstElementChild||icEl;host.insertAdjacentHTML('beforeend',srcBtn7(key))}catch(e){}}}

// ---------- 6) ร้านค้า: ของในร้านเป็นช่องไอคอน · แตะเพื่อดูรายละเอียด/ซื้อ ----------
{const st=document.createElement('style');st.textContent=`
#shop .bgrid7{display:grid;grid-template-columns:repeat(auto-fill,minmax(54px,1fr));gap:6px;padding:2px}
#shop .bg7{position:relative;aspect-ratio:1;border-radius:10px;border:2px solid rgba(232,193,74,.45);background:radial-gradient(circle at 50% 40%,#4a3a5a,#1a1424);display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:24px}
#shop .bg7 img{width:78%;height:78%}#shop .bg7 em{position:absolute;right:2px;bottom:0;font:800 10px system-ui;font-style:normal;color:#ffe9a0;text-shadow:0 1px 2px #000}
#shop .bg7.sel{border-color:#fff;box-shadow:0 0 0 2px #ffe9a0,0 0 10px #ffe9a0}
#shop .bdet7{display:flex;flex-direction:column;gap:5px;padding:8px;border-radius:12px;background:rgba(255,233,160,.08);border:1.5px solid #e8c14a;margin-bottom:6px}
#shop .bdet7 .h{display:flex;gap:8px;align-items:center}#shop .bdet7 .h .ic{width:44px;height:44px;flex:none;border-radius:10px;background:radial-gradient(circle,#5a4a7a,#1a1428);display:flex;align-items:center;justify-content:center;font-size:24px}#shop .bdet7 .h .ic img{width:38px;height:38px}
#shop .bdet7 b{color:#fff}#shop .bdet7 small{opacity:.85}#shop .bdet7{text-align:left;padding:6px 8px;gap:4px}#shop .bdet7 .h>div:last-child{font-size:12px;line-height:1.35}#shop .bdet7 .rw{display:flex;gap:5px;align-items:center}#shop .bdet7 .rw button{width:auto!important;min-width:34px;padding:4px 10px!important;margin:0!important}#shop .bdet7 .mini.ok{padding:6px!important;margin:0!important}#shop .srcb7,#icard .srcb7{align-self:flex-start;height:auto!important;line-height:1.3!important;width:auto!important;display:inline-block!important;padding:4px 9px!important;margin:4px 0 0!important;font-size:11.5px!important;background:#13304a!important;color:#bfe4ff!important;border:1px solid #6ab0e8!important;min-height:0!important}#shop .srcb7.on{background:#bfe4ff!important;color:#13304a!important}#shop .src7{max-height:120px;overflow-y:auto}`;document.head.appendChild(st)}
const SHOP7={sel:null,q:1};
function bImg7(b){const u=b.item?iconURL('item:'+b.item):b.mat?iconURL('mat:'+b.mat):null;return u?'<img src="'+u+'">':(b.emoji||'📦')}
buyList=function(S){if(!S.buy.length)return '<small>ร้านนี้ไม่มีของขาย</small>';if(SHOP7.sel&&!S.buy.some(b=>b.id===SHOP7.sel))SHOP7.sel=null;let h='';
 const b=SHOP7.sel&&S.buy.find(q=>q.id===SHOP7.sel);
 if(b){const key=b.item?'item:'+b.item:b.mat?'mat:'+b.mat:null,have=b.item?(GEAR[b.item]|0):b.mat?(inv[b.mat]|0):b.id==='scroll'?(inv.scroll|0):null;
  h+='<div class="bdet7"><div class="h"><div class="ic">'+bImg7(b)+'</div><div><b>'+b.name+'</b><br><small>'+b.note+'</small>'+(have!=null?'<br><small>มีอยู่ ×'+have+'</small>':'')+'</div></div>'
   +'<div class="rw"><button class="mini sm" onclick="shopQ7(-1)">−</button><b class="q">'+SHOP7.q+'</b><button class="mini sm" onclick="shopQ7(1)">+</button><button class="mini sm" onclick="shopQ7(5)">+5</button></div>'
   +'<button class="mini ok" onclick="shopBuy7()">🛒 ซื้อ ×'+SHOP7.q+' · 🪙 '+(b.price*SHOP7.q).toLocaleString()+'</button>'+(key?srcBtn7(key):'')+'</div>'}
 else h+='<small style="display:block;margin:2px 0 6px;opacity:.8">แตะช่องสินค้าเพื่อดูรายละเอียด</small>';
 h+='<div class="bgrid7">'+S.buy.map(q=>'<div class="bg7'+(q.id===SHOP7.sel?' sel':'')+'" title="'+q.name+'" onclick="shopSel7(\''+q.id+'\')">'+bImg7(q)+'<em>🪙'+q.price+'</em></div>').join('')+'</div>';return h};
window.shopSel7=id=>{SHOP7.sel=SHOP7.sel===id?null:id;SHOP7.q=1;sfx('ui');renderShop()};
window.shopQ7=d=>{SHOP7.q=Math.max(1,Math.min(99,SHOP7.q+d));sfx('ui');renderShop()};
window.shopBuy7=()=>{const id=SHOP7.sel;if(!id)return;const n=SHOP7.q;let c0=inv.coin;for(let i=0;i<n;i++){const before=inv.coin;buyItem(id);if(inv.coin>=before)break}if(SHOPK)renderShop()};
// แถบขาย: เพิ่ม "หาได้จากที่ไหน"
{const _sb=sellBar;sellBar=function(){const h=_sb();try{const s=SHOPUI.sel;if(!h||!s)return h;return h.replace(/<\/div>$/,srcBtn7((s.t==='gear'?'item:':'mat:')+s.k)+'</div>')}catch(e){return h}}}
{const _cs=closeShop;closeShop=function(){SHOP7.sel=null;return _cs()}}

// ---------- 7) ตีบวก: ช่องใหญ่ซ้าย (ของที่จะตี) · กระเป๋าเป็นช่องไอคอนขวา · ของที่ใช้มาจากเกมจริง ----------
// ค่าใช้จ่าย: Gold + 💎หินเสริมพลัง + แท่งแร่ตามระดับไอเท็ม (หลอมจากเตา) · +10 ขึ้นไปใช้ 🐉เกล็ดมังกรเพิ่ม
ENHCFG.cost=l=>({gold:50*(l+1)*(l+2),stone:ENH_EST(l),ing:1+(l>>2),scale:l>=9?l-8:0});
const enhMats7=(id,l)=>{const it=ITEMS[id],c=ENHCFG.cost(l),L=[{k:'coin',n:c.gold,nm:'Gold'},{k:'estone',n:c.stone,nm:'หินเสริมพลัง'},{k:MATKEY[it.tier],n:c.ing,nm:MATN[it.tier]}];if(c.scale)L.push({k:'scale',n:c.scale,nm:'เกล็ดมังกร'});return L};
{const _ck=enhCheck7;enhCheck7=function(id){const r=_ck(id);if(r)return r;const l=enhLv7(id);for(const m of enhMats7(id,l))if((inv[m.k]|0)<m.n)return 'วัตถุดิบไม่เพียงพอ — '+m.nm+' ต้องใช้ '+m.n+' มี '+(inv[m.k]|0);return null}}
{const _es=enhStart7;enhStart7=function(){const id=ENHS.sel;if(ENHS.busy||!id||enhCheck7(id)){return _es()}const l=enhLv7(id),ms=enhMats7(id,l).filter(m=>m.k!=='coin'&&m.k!=='estone');
  _es();if(ENHS.busy)for(const m of ms)inv[m.k]=Math.max(0,(inv[m.k]|0)-m.n);try{refreshInv();saveGame(true)}catch(e){}}}
{const st=document.createElement('style');st.textContent=`
#enhw .ebd{flex:1;min-height:0;display:flex;gap:10px;padding:10px}
#enhw .eL{width:46%;display:flex;flex-direction:column;gap:6px;min-width:0;overflow-y:auto}
#enhw .eR{flex:1;display:flex;flex-direction:column;gap:6px;min-width:0}
#enhw .bigslot{position:relative;flex:none;width:118px;height:118px;border-radius:18px;border:3px solid var(--ec,#8a7040);background:radial-gradient(circle at 50% 45%,#6a5a8a,#1a1428 75%);box-shadow:inset 0 0 18px rgba(0,0,0,.6),0 0 16px var(--eg,transparent);display:flex;align-items:center;justify-content:center}
#enhw .bigslot img{width:92px;height:92px;image-rendering:pixelated}#enhw .bigslot.empty::after{content:"วางอุปกรณ์\\Aที่จะตีบวก";white-space:pre;text-align:center;font-size:11px;opacity:.6}
#enhw .bigslot .lv{position:absolute;right:6px;top:4px;font:900 16px system-ui;text-shadow:0 1px 3px #000}
#enhw .mats{display:flex;gap:6px;justify-content:center;flex-wrap:wrap}
#enhw .mt{position:relative;width:50px;height:50px;border-radius:10px;border:2px solid #8fe08a;background:radial-gradient(circle,#3a3050,#141020);display:flex;align-items:center;justify-content:center}
#enhw .mt.no{border-color:#ff7a6a}#enhw .mt img{width:36px;height:36px}#enhw .mt em{position:absolute;left:0;right:0;bottom:-13px;text-align:center;font:800 10px system-ui;font-style:normal;white-space:nowrap}
#enhw .mt.no em{color:#ff9a8a}#enhw .mt em b{color:#ffe9a0}
#enhw .grid7{flex:1;overflow-y:auto;display:grid;grid-template-columns:repeat(auto-fill,minmax(52px,1fr));gap:6px;align-content:start;padding:2px}
#enhw .gs{position:relative;aspect-ratio:1;border-radius:10px;border:2px solid var(--tc,#555);background:radial-gradient(circle at 50% 40%,#3e3456,#161222);cursor:pointer;display:flex;align-items:center;justify-content:center}
#enhw .gs img{width:80%;height:80%}#enhw .gs em{position:absolute;right:3px;top:0;font:900 10.5px system-ui;font-style:normal;text-shadow:0 1px 2px #000}
#enhw .gs i{position:absolute;left:3px;bottom:1px;font:800 9px system-ui;font-style:normal;color:#8fe08a}#enhw .gs.sel{box-shadow:0 0 0 2px #fff,0 0 12px #ffe9a0}#enhw .gs.pk{outline:2px dashed #ffe9a0}
#enhw .pop7{padding:8px;border-radius:12px;background:rgba(0,0,0,.35);border:1.5px solid rgba(255,233,160,.4);display:flex;flex-direction:column;gap:4px}
#enhw .etop{display:flex;gap:10px;align-items:center}#enhw .einf{display:flex;flex-direction:column;gap:2px;min-width:0}#enhw .pop7 .srcb7{align-self:flex-start;padding:3px 8px;font-size:11px;background:#13304a;color:#bfe4ff;border-color:#6ab0e8}#enhw .pop7 .rw7{display:flex;gap:6px;flex-wrap:wrap}#enhw .pop7 button{font:800 12px system-ui,"Noto Sans Thai",sans-serif;padding:6px 10px;border-radius:9px;border:1px solid #c8a24a;background:#3a2c18;color:#ffe9c0;cursor:pointer}#enhw .pop7 button.g{background:linear-gradient(180deg,#f2c14a,#b8781a);color:#3a2008}
@media (max-height:440px){#enhw .bigslot{width:84px;height:84px}#enhw .bigslot img{width:64px;height:64px}#enhw .mt{width:40px;height:40px}#enhw .mt img{width:28px;height:28px}#enhw .gs{min-height:0}}`;document.head.appendChild(st)}
ENHS.pick=null; // ช่องที่แตะในกระเป๋า (ยังไม่วางลงทั่ง)
const _er7=enhRender7;
enhRender7=function(){if(!ENHS.open)return;if(ENHS.res)return _er7();
 const all=enhList7(),id=ENHS.sel&&all.some(o=>o.id===ENHS.sel)?ENHS.sel:null;if(!id)ENHS.sel=null;
 let h='<div class="w"><div class="hd"><b>⚒️ ตีบวกอุปกรณ์ · ENHANCEMENT</b><button onclick="closeEnh7()">✕</button></div><div class="ebd"><div class="eL">';
 if(id){const it=ITEMS[id],l=enhLv7(id),K=ENHCFG.kinds[it.kind],mx=l>=MAX_ENHANCEMENT,ec=enhCol(l),why=enhCheck7(id);
  h+='<div class="etop"><div class="bigslot" style="--ec:'+ec+';--eg:'+(l>=3?ec:'transparent')+'" title="แตะเพื่อเอาออก" onclick="enhUnset7()"><img src="'+ico7(id)+'"><span class="lv" style="color:'+ec+'">+'+l+'</span></div>'
   +'<div class="einf"><b style="font-size:14px">'+it.name+'</b><small>'+(GKIND[it.kind]||it.kind)+' · ขั้น '+(it.tier+1)+' ('+TNAMES[it.tier]+')</small>'
   +'<div class="lvl" style="font-size:22px;text-align:left">'+(mx?'<span style="color:'+ec+'">+'+l+' MAX</span>':'<span style="color:'+ec+'">+'+l+'</span><span class="arr">→</span><span style="color:'+enhCol(l+1)+'">+'+(l+1)+'</span>')+'</div></div></div>';
  h+='<div class="mat"><span>'+K.ic+' '+K.n+'</span><span><b>'+enhStat7(id,l)+'</b>'+(mx?'':' <span class="arr">→</span> <span class="ok">'+enhStat7(id,l+1)+'</span>')+'</span></div>';
  if(!mx){h+='<small style="text-align:center;opacity:.8">ของที่ต้องใช้ (โอกาสสำเร็จ '+ENHCFG.rate(l)+'%)</small><div class="mats">'+enhMats7(id,l).map(m=>{const hv=inv[m.k]|0,ok=hv>=m.n;
    return '<div class="mt'+(ok?'':' no')+'" title="'+m.nm+'" onclick="enhSrc7(\''+m.k+'\')"><img src="'+iconURL('mat:'+m.k)+'"><em>'+(m.k==='coin'?m.n.toLocaleString():'<b>'+hv+'</b>/'+m.n)+'</em></div>'}).join('')+'</div><div style="height:12px"></div>'}
  if(ENHS.srcK)h+='<div class="pop7"><b style="font-size:12px">📍 '+(INVMETA[ENHS.srcK]?INVMETA[ENHS.srcK][0]:ENHS.srcK)+' หาได้จาก</b>'+srcHTML7('mat:'+ENHS.srcK)+'</div>';
  h+='<div class="why">'+(ENHS.msg||why||'')+'</div><button class="go" '+(why?'disabled':'')+' onclick="enhStart7()">⚒️ ตีบวก</button>'}
 else h+='<div class="bigslot empty"></div><small style="text-align:center;opacity:.8">แตะอุปกรณ์ในกระเป๋าทางขวา<br>แล้วกด "⚒️ ตีบวก" เพื่อวางลงบนทั่ง</small>';
 h+='</div><div class="eR"><div class="gtab">'+ENHCFG.groups.map(([g,n])=>'<button class="'+(ENHS.grp===g?'on':'')+'" onclick="enhGrp7(\''+g+'\')">'+n+'</button>').join('')+'</div>';
 const L=all.filter(o=>ENHS.grp==='all'||ENHCFG.kinds[ITEMS[o.id].kind].g===ENHS.grp);
 if(ENHS.pick&&L.some(o=>o.id===ENHS.pick)){const p=ENHS.pick,it=ITEMS[p],l=enhLv7(p),K=ENHCFG.kinds[it.kind];
  h+='<div class="pop7"><div style="display:flex;gap:8px;align-items:center"><img src="'+ico7(p)+'" style="width:38px;height:38px;border-radius:8px;background:#1a1428;flex:none"><div style="flex:1;min-width:0"><b>'+it.name+' <span style="color:'+enhCol(l)+'">+'+l+'</span></b><br><small>'+K.n+' '+enhStat7(p)+' · '+(P.armor[it.kind]===p?'สวมอยู่':'อยู่ในกระเป๋า')+'</small></div>'
   +'<button class="g" onclick="enhSet7(\''+p+'\')">⚒️ ตีบวก</button><button onclick="ENHS.pick=null;enhRender7()">✕</button></div>'+srcBtn7('item:'+p)+'</div>'}
 h+='<div class="grid7">';if(!L.length)h+='<small style="grid-column:1/-1;padding:8px">ไม่มีอุปกรณ์ที่ตีบวกได้ในหมวดนี้</small>';
 for(const o of L){const it=ITEMS[o.id],l=enhLv7(o.id);h+='<div class="gs'+(o.id===id?' sel':'')+(o.id===ENHS.pick?' pk':'')+'" style="--tc:'+TIERC[it.tier]+'" title="'+it.name+' +'+l+'" onclick="enhPick7(\''+o.id+'\')"><img src="'+ico7(o.id)+'">'+(l?'<em style="color:'+enhCol(l)+'">+'+l+'</em>':'')+(o.worn?'<i>E</i>':'')+'</div>'}
 h+='</div></div></div></div>';enhW.innerHTML=h};
window.enhPick7=id=>{if(ENHS.busy)return;ENHS.pick=ENHS.pick===id?null:id;ENHS.srcK=null;sfx('ui');enhRender7()};
window.enhSet7=id=>{if(ENHS.busy)return;ENHS.sel=id;ENHS.pick=null;ENHS.msg='';ENHS.srcK=null;sfx('pop');enhRender7()};
window.enhUnset7=()=>{if(ENHS.busy)return;ENHS.sel=null;ENHS.srcK=null;sfx('ui');enhRender7()};
window.enhSrc7=k=>{ENHS.srcK=ENHS.srcK===k?null:k;sfx('ui');enhRender7()};
{const _o=openEnh7;openEnh7=function(id){ENHS.pick=null;ENHS.srcK=null;const keep=id||null;_o(id);if(!keep&&ENHS.open){ENHS.sel=null;enhRender7()}}}
window.openEnh7=openEnh7;enhItem=function(id){openEnh7(id)};

// ---------- 8) ทั่งตีเหล็กตั้งพื้น (ตีได้จริง): ตัวละครเดินไปยืนข้างทั่ง ค้อนลงบนหน้าทั่งพอดี ----------
const ANV7={x:OX+17.5*T,y:6.6*T};window.ANV7y=ANV7.y;
setInterval(()=>{window.ENHOPEN7=!!(ENHS.open||ENHS.busy)},200);
try{const s=SHOP_STN.gear.find(s=>s.k==='anvil');if(s){s.x=ANV7.x;s.y=ANV7.y;s.n='🔨 ทั่งตีเหล็ก · ตีบวก'}}catch(e){}
{const _sn=stnNear;stnNear=function(){if(D&&D.shop==='gear'){if(Math.hypot(P.x-ANV7.x,P.y-ANV7.y)<46)return SHOP_STN.gear.find(s=>s.k==='anvil');const r=_sn();return r&&r.k==='anvil'?null:r}return _sn()}}
// ปิดช่องที่ทั่งตั้งอยู่ (ชนได้ ไม่เดินทะลุ)
{const _es=enterShop;enterShop=function(id){const r=_es(id);try{if(id==='gear'&&typeof dm!=='undefined'){const tx=Math.floor(ANV7.x/T),ty=Math.floor((ANV7.y-4)/T);if(dm[ty])dm[ty][tx]=WL}}catch(e){}return r}}
function drawAnvil7(){const x=ANV7.x,y=ANV7.y;ctx.save();
 ctx.fillStyle='rgba(0,0,0,.28)';ctx.beginPath();ctx.ellipse(x,y+1,19,5,0,0,7);ctx.fill();
 // ตอไม้ฐาน
 const g=ctx.createLinearGradient(x-13,0,x+13,0);g.addColorStop(0,'#4a2c14');g.addColorStop(.5,'#8a5a2e');g.addColorStop(1,'#3a2210');ctx.fillStyle=g;ctx.fillRect(x-13,y-16,26,16);ctx.fillStyle='#a8743e';ctx.beginPath();ctx.ellipse(x,y-16,13,3.5,0,0,7);ctx.fill();
 ctx.strokeStyle='#24140a';ctx.lineWidth=1.2;ctx.strokeRect(x-12.5,y-16,25,15.5);ctx.fillStyle='rgba(0,0,0,.25)';for(const q of [-6,1,7])ctx.fillRect(x+q,y-14,1,13);
 // ตัวทั่ง (มีเขา)
 ctx.fillStyle='#2b2d35';ctx.beginPath();ctx.moveTo(x-8,y-17);ctx.lineTo(x+8,y-17);ctx.lineTo(x+6,y-23);ctx.lineTo(x-6,y-23);ctx.closePath();ctx.fill();
 ctx.fillStyle='#4a4d58';ctx.beginPath();ctx.moveTo(x-17,y-31);ctx.lineTo(x+13,y-31);ctx.lineTo(x+13,y-26);ctx.lineTo(x+7,y-23);ctx.lineTo(x-7,y-23);ctx.lineTo(x-11,y-26);ctx.quadraticCurveTo(x-20,y-27,x-25,y-30);ctx.quadraticCurveTo(x-21,y-31,x-17,y-31);ctx.closePath();ctx.fill();
 ctx.strokeStyle='#15161b';ctx.lineWidth=1.2;ctx.stroke();ctx.fillStyle='#8a8f9e';ctx.fillRect(x-16,y-32,29,2.4);ctx.fillStyle='rgba(255,255,255,.35)';ctx.fillRect(x-14,y-32,10,1);ctx.restore()}
{const _h=hero;hero=function(){if(!(D&&D.shop==='gear'))return _h();if(ANV7.y<=P.y+3){drawAnvil7();_h()}else{_h();drawAnvil7()}}}
// ตำแหน่งยืน/เป้าค้อน ตามทั่งใหม่ (ยืนซ้ายทั่ง หันขวา · ค้อนลงหน้าทั่ง)
{const _fs=forgeStart7;forgeStart7=function(id,ok){_fs(id,ok);FRG.a={x:ANV7.x,y:ANV7.y,k:'anvil'};FRG.to={x:ANV7.x-24,y:ANV7.y}}}
// ตำแหน่งของบนทั่งในฉากตีเหล็ก: เลื่อนให้อยู่บนหน้าทั่ง (y-33)
{const _fd=frgDraw;frgDraw=function(x,by,TOP){const a=FRG.a;if(a&&a.k==='anvil'){const sv={x:a.x,y:a.y};FRG.a={x:a.x+2,y:a.y-6,k:'anvil'};try{return _fd(x,by,TOP)}finally{FRG.a=Object.assign(FRG.a,sv)}}return _fd(x,by,TOP)}}

// ---------- 9) เรื่องราว: ช่างหนวดเหล็กสอนตีบวกครั้งแรก (ให้หินเสริมพลัง + แท่งแร่สำหรับเริ่ม) ----------
{const _o=openEnh7;openEnh7=function(id){let seen=false;try{seen=localStorage.getItem('fm_enhtut7')==='1'}catch(e){seen=true}
  if(!seen&&D&&D.shop==='gear'&&!ENHS.busy){try{localStorage.setItem('fm_enhtut7','1')}catch(e){}const nm=(SD2.gear&&SD2.gear.owner&&SD2.gear.owner.name)||'ช่างหนวดเหล็ก';
   talk({name:nm,c:'#c87a3a'},'อ้อ เจ้าสนใจตีบวกงั้นรึ? อาวุธดีต้องผ่านไฟผ่านค้อน… วางของบนทั่ง ใช้หินเสริมพลังจากดันเจี้ยนกับแท่งแร่จากเตาหลอม ตีให้ถึงเนื้อเหล็ก! ข้าให้ของติดมือไปลองก่อน',
    [{t:'⚒️ รับของแล้วลองตีเลย',c:'go',f:()=>{inv.estone=(inv.estone|0)+3;inv.ingSt=(inv.ingSt|0)+2;inv.ingot=(inv.ingot|0)+2;refreshInv();say('🎁 ได้ 💎หินเสริมพลัง ×3 · แท่งหิน ×2 · แท่งเหล็ก ×2');setTimeout(()=>_o(id),200)}}],'⚒️ บทเรียนตีบวก');return}
  return _o(id)}}
window.openEnh7=openEnh7;enhItem=function(id){openEnh7(id)};

// ---------- 10) ชำนาญสกิล: พาสซีฟผูกกับสกิลจริง — ใช้สกิลบ่อย = ชำนาญขึ้น (ดาเมจ↑ คูลดาวน์↓ มานา↓) ----------
const MSK7={need:[0,10,30,70,150,300],dmg:.06,cd:.04,mp:.04};
let MSKD7={};try{MSKD7=JSON.parse(localStorage.getItem('fm_msk7')||'{}')||{}}catch(e){}
const mskKey7=i=>P.cls+':'+i,mskUses7=i=>MSKD7[mskKey7(i)]|0,mskLv7=i=>{const u=mskUses7(i);let l=0;for(let k=1;k<MSK7.need.length;k++)if(u>=MSK7.need[k])l=k;return l};
function mskSave7(){try{localStorage.setItem('fm_msk7',JSON.stringify(MSKD7))}catch(e){}}
{const _us=useSkill;useSkill=function(i){if(P.cls==='none')return _us(i);const L=mskLv7(i),cd0=CS.cd[i],mp0=P.mp,j0=P.jump;const prev=window.CURSK7;window.CURSK7=L?{m:1+MSK7.dmg*L}:null;
  try{_us(i)}finally{window.CURSK7=prev}
  const cast=CS.cd[i]>cd0+.01||P.mp<mp0-.01;if(!cast)return;
  if(L){if(CS.cd[i]>cd0+.01)CS.cd[i]*=1-MSK7.cd*L;const sp=mp0-P.mp;if(sp>0)P.mp=Math.min(BAL.mp,P.mp+sp*MSK7.mp*L);if(P.jump&&P.jump!==j0)P.jump.mm7=1+MSK7.dmg*L}
  const k=mskKey7(i),l0=mskLv7(i);MSKD7[k]=(MSKD7[k]|0)+1;mskSave7();const l1=mskLv7(i);
  if(l1>l0){const S=CSKILLS[P.cls]&&CSKILLS[P.cls][i];say('🎯 ชำนาญสกิล '+(S?S.n:'')+' ขึ้นเป็นขั้น '+l1+'!');sfx('gem')}}}
{const _hE=hurtE;hurtE=function(e,mult,o){if(window.CURSK7&&typeof mult==='number')mult*=CURSK7.m;return _hE(e,mult,o)}}
{const _sh=shoot;shoot=function(k,o){if(window.CURSK7&&o&&typeof o.mult==='number')o=Object.assign({},o,{mult:o.mult*CURSK7.m});return _sh(k,o)}}
{const st=document.createElement('style');st.textContent=`
.msk7{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:8px;overflow-y:auto;padding:2px}
.msk7 .mc{display:flex;gap:9px;padding:9px;border-radius:12px;background:linear-gradient(135deg,rgba(255,255,255,.07),rgba(0,0,0,.25));border:1.5px solid rgba(232,193,74,.35)}
.msk7 .mc.lk{opacity:.5}.msk7 .si{width:56px;height:56px;flex:none;border-radius:12px;background-size:cover;background-position:center;border:2px solid #e8c14a;box-shadow:0 0 10px var(--g,transparent)}
.msk7 .st{display:flex;gap:3px;margin:3px 0}.msk7 .st i{width:14px;height:6px;border-radius:3px;background:#3a3448}.msk7 .st i.on{background:linear-gradient(90deg,#ffd84a,#ff8a3a);box-shadow:0 0 5px #ffb04a}
.msk7 .bar{height:5px;border-radius:3px;background:#2a2438;overflow:hidden}.msk7 .bar b{display:block;height:100%;background:linear-gradient(90deg,#7fd0ff,#b48cff)}
.msk7 small{display:block;font-size:11px;opacity:.85;line-height:1.35}
.pas7{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}.pas7 .pc{flex:1 1 140px;display:flex;gap:7px;align-items:center;padding:6px;border-radius:10px;background:rgba(0,0,0,.3);border:1.5px solid rgba(255,233,160,.35)}
.pas7 .pc.lk{opacity:.45;border-color:#555}.pas7 .pi{width:38px;height:38px;flex:none;border-radius:9px;background-size:cover;background-position:center;border:2px solid var(--c,#e8c14a);box-shadow:0 0 8px var(--c,#e8c14a)}
.pas7 b{font-size:12px;color:#ffe9a0}.pas7 small{font-size:10.5px}`;document.head.appendChild(st)}
function mskHTML7(){const L=CSKILLS[P.cls]||[];if(P.cls==='none'||!L.length)return '<div class="card"><b>🎯 ชำนาญสกิล</b><small>เลือกอาชีพก่อน แล้วใช้สกิลบ่อย ๆ จะชำนาญขึ้น</small></div>';
 let h='<div class="card" style="margin-bottom:8px"><b>🎯 ชำนาญสกิล — ยิ่งใช้ยิ่งเก่ง</b><small>ใช้สกิลในการต่อสู้เพื่อเพิ่มความชำนาญ (สูงสุดขั้น 5) · ทุกขั้น: ดาเมจสกิล +'+Math.round(MSK7.dmg*100)+'% · คูลดาวน์ −'+Math.round(MSK7.cd*100)+'% · มานา −'+Math.round(MSK7.mp*100)+'%</small></div><div class="msk7">';
 L.forEach((s,i)=>{const own=skOwned(i),l=mskLv7(i),u=mskUses7(i),nx=MSK7.need[Math.min(5,l+1)],pv=MSK7.need[l],pc=l>=5?100:Math.round((u-pv)/(nx-pv)*100),ic=typeof skillIcon==='function'?skillIcon(s.n):null;
  h+='<div class="mc'+(own?'':' lk')+'"><div class="si" style="'+(ic?'background-image:url('+ic+')':'')+';--g:'+(l>=3?'#ffb04a':'transparent')+'">'+(ic?'':s.e)+'</div><div style="flex:1;min-width:0"><b>'+s.n+'</b>'+(own?'':' <small style="display:inline;color:#ff9a7a">🔒 Lv.'+s.lv+'</small>')
   +'<div class="st">'+[1,2,3,4,5].map(k=>'<i class="'+(k<=l?'on':'')+'"></i>').join('')+'</div><div class="bar"><b style="width:'+pc+'%"></b></div>'
   +'<small>ขั้น '+l+'/5 · ใช้แล้ว '+u+' ครั้ง'+(l<5?' · อีก '+(nx-u)+' ครั้งขึ้นขั้น '+(l+1):' · ชำนาญสูงสุด!')+'</small>'
   +'<small style="color:#8fe08a">ดาเมจ +'+Math.round(MSK7.dmg*100*l)+'% · คูลดาวน์ −'+Math.round(MSK7.cd*100*l)+'% · มานา −'+Math.round(MSK7.mp*100*l)+'%</small></div></div>'});
 return h+'</div>'}
const PASIC7={str:'💪',vit:'❤️',int:'🔮',agi:'🏹',end:'🛡️'};
{const _rs=renderSkw;renderSkw=function(){if(skwEl.hidden)return;
  if(SKW.tab==='msk'){const save=SKW.tab;SKW.tab='sk';_rs();SKW.tab=save;const lst=skwEl.querySelector('.list');if(lst){lst.outerHTML='<div class="list" style="display:block;overflow-y:auto">'+mskHTML7()+'</div>'}}
  else _rs();
  try{const hd=skwEl.querySelector('.sh');if(hd&&!hd.querySelector('.msk7b')){const b=document.createElement('button');b.className='msk7b'+(SKW.tab==='msk'?' on':'');b.textContent='🎯 ชำนาญ';b.onclick=()=>skwTab('msk');const tabs=hd.querySelectorAll('button');const pas=[...tabs].find(x=>/พาสซีฟ/.test(x.textContent));if(pas)pas.after(b);else hd.appendChild(b);for(const x of tabs)if(SKW.tab==='msk'&&/สกิล/.test(x.textContent)&&!/ชำนาญ/.test(x.textContent))x.classList.remove('on')}}catch(e){}
  // พาสซีฟอาชีพ: แสดงเป็นการ์ดไอคอนเรืองแสง (สีตามสาย) แทนข้อความล้วน
  try{if(SKW.tab==='pas'){const PL=PASSIVE[P.cls]||[],C=CLS[P.cls]||{col:'#e8c14a'},L=CSKILLS[P.cls]||[];for(const cd of skwEl.querySelectorAll('.card')){if(!/พาสซีฟอาชีพ/.test(cd.textContent))continue;
    cd.innerHTML='<b>'+(C.e||'')+' พาสซีฟอาชีพ (ปลดล็อกตามเลเวล)</b><div class="pas7">'+PL.map((p,i)=>{const on=P.lv>=p.lv,sk=L[i%Math.max(1,L.length)],ic=sk&&typeof skillIcon==='function'?skillIcon(sk.n):null,k=p.st?Object.keys(p.st)[0]:null;
      return '<div class="pc'+(on?'':' lk')+'"><div class="pi" style="--c:'+(on?C.col:'#555')+';'+(ic?'background-image:url('+ic+')':'')+'"></div><div><b>'+(k?PASIC7[k]||'🌟':'🌟')+' '+p.n+'</b><small>'+p.d+' · Lv.'+p.lv+(on?' ✓':' 🔒')+'</small></div></div>'}).join('')+'</div>'}}}catch(e){}}}
{const _st=skwTab;skwTab=function(t){SKW.tab=t;sfx('ui');renderSkw()}}
// ต้นไม้พาสซีฟ: จุดที่ยังไม่อัพเป็นอัญมณีมีมิติ (ไล่สี+ขอบเรือง) แทนวงกลมดำเรียบ
{const _ps=ptSVG;ptSVG=function(){let s=_ps();s=s.replace('<defs>','<defs><radialGradient id="ndk7" cx=".4" cy=".35" r=".75"><stop offset="0" stop-color="#5a4e7e"/><stop offset=".6" stop-color="#262036"/><stop offset="1" stop-color="#0e0c16"/></radialGradient><radialGradient id="nsh7" cx=".35" cy=".3" r=".6"><stop offset="0" stop-color="rgba(255,255,255,.75)"/><stop offset="1" stop-color="rgba(255,255,255,0)"/></radialGradient>');
  s=s.split('fill="#1a1a28"').join('fill="url(#ndk7)"');return s}}

// ---------- 11) "หาได้จาก" แสดงต่อท้ายรายละเอียดของทุกที่ (ไม่ต้องกดปุ่ม) · แตะของ = เห็นรายละเอียดเต็ม ----------
{const st=document.createElement('style');st.textContent=`
.isrc7{margin-top:7px;border-top:1px dashed rgba(127,200,255,.35);padding-top:6px;text-align:left}
.isrc7>b{display:block;font-size:11.5px;color:#9fd4ff;margin-bottom:3px}
.isrc7 .src7{margin-top:0;max-height:none}
.il7{text-align:left;font-size:11.5px;line-height:1.4;margin-top:4px;padding-top:4px;border-top:1px solid rgba(255,255,255,.12)}
.il7 div{margin:1px 0}.il7 .y{color:#ffd84a}.il7 .g{color:#8fe08a}.il7 .b{color:#9fd4ff}.il7 .m{opacity:.7}
#icard .isrc7 .src7{max-height:140px;overflow-y:auto}#icard.tip .isrc7 .src7 div:nth-child(n+4){display:none}`;document.head.appendChild(st)}
const srcBlock7=key=>'<div class="isrc7"><b>📍 หาได้จากที่ไหน</b>'+srcHTML7(key)+'</div>';
const lines7=key=>{try{return '<div class="il7">'+(key.startsWith('item:')?gearLines(key.slice(5)):matLines(key.slice(4)))+'</div>'}catch(e){return ''}};
// การ์ดของในกระเป๋า/ตัวละคร: ต่อท้ายด้วยแหล่งที่มา (แทนปุ่ม)
{const _ic=icShow;icShow=function(t,k,ro,at){_ic(t,k,ro,at);try{if(icEl.hidden)return;for(const b of icEl.querySelectorAll('.srcb7,.src7'))b.remove();if(icEl.querySelector('.isrc7'))return;
  const key=(t==='gear'?'item:':'mat:')+k,il=icEl.querySelector('.il');if(il)il.insertAdjacentHTML('afterend',srcBlock7(key));else icEl.insertAdjacentHTML('beforeend',srcBlock7(key))}catch(e){}}}
// ร้านค้า (ซื้อ): รายละเอียดเต็ม + แหล่งที่มาต่อท้าย
{const _bl=buyList;buyList=function(S){let h=_bl(S);const b=SHOP7.sel&&S.buy.find(q=>q.id===SHOP7.sel);if(!b)return h;const key=b.item?'item:'+b.item:b.mat?'mat:'+b.mat:null;
  h=h.replace(/<button class="srcb7"[^>]*>[^<]*<\/button>/,'');if(key)h=h.replace('</div><div class="bgrid7">',lines7(key)+srcBlock7(key)+'</div><div class="bgrid7">');return h}}
// ร้านค้า (ขาย): แตะของ = รายละเอียดเต็ม + แหล่งที่มา
{const _sb=sellBar;sellBar=function(){let h=_sb();try{const s=SHOPUI.sel;if(!h||!s)return h;const key=(s.t==='gear'?'item:':'mat:')+s.k;h=h.replace(/<button class="srcb7"[^>]*>[^<]*<\/button>/,'');return h.replace(/<\/div>$/,lines7(key)+srcBlock7(key)+'</div>')}catch(e){return h}}}
// ตีบวก: แตะของในกระเป๋า = รายละเอียดเต็ม (ค่าสถานะ/ตีบวก/รูน/น้ำหนัก) + แหล่งที่มา
{const _er=enhRender7;enhRender7=function(){_er();try{const p=ENHS.pick;if(!p)return;const pop=enhW.querySelector('.eR .pop7');if(!pop)return;for(const b of pop.querySelectorAll('.srcb7,.src7'))b.remove();
  pop.insertAdjacentHTML('beforeend',lines7('item:'+p)+srcBlock7('item:'+p));pop.style.maxHeight='46%';pop.style.overflowY='auto'}catch(e){}}}
// ช่องวัตถุดิบในหน้าตีบวก: แตะ = รายละเอียด + แหล่งที่มา (ใช้กล่องเดิม)
{const _er=enhRender7;enhRender7=function(){_er();try{const k=ENHS.srcK;if(!k||!ENHS.sel)return;const box=[...enhW.querySelectorAll('.eL .pop7')].pop();if(!box)return;box.innerHTML='<b style="font-size:12px">'+(INVMETA[k]?INVMETA[k][0]:k)+' · มี '+(inv[k]|0)+'</b>'+lines7('mat:'+k)+srcBlock7('mat:'+k)}catch(e){}}}

// ---------- 12) เอาปุ่มที่ซ้ำกับเมนูโปรไฟล์ออกจากขอบจอ (กระเป๋า · ลำโพง · เชื่อมต่อออนไลน์ · พาสซีฟ🌟) ----------
{const st=document.createElement('style');st.textContent='#bagb,#muteb,#netb,#pasb{display:none!important}#pmdot7{position:absolute;right:-4px;top:-4px;min-width:16px;height:16px;padding:0 4px;border-radius:9px;background:#7a4ad8;color:#fff;font:900 10px/16px system-ui;text-align:center;box-shadow:0 0 0 2px #1a1426;pointer-events:none}#pmdot7[hidden]{display:none}#pm7{grid-template-columns:repeat(5,58px)!important}';document.head.appendChild(st)}
PM7.splice(PM7.length-1,0,['🔊','เสียง',()=>{toggleMute();pmRender7()}],['🌐','ออนไลน์',()=>{const b=gid('netb');if(b&&b.onclick)b.onclick();else toggleMenu()}]);
function pmRender7(){pm7.innerHTML=PM7.map((m,i)=>{let ic=m[0],lb=m[1],badge='';if(lb==='เสียง'){ic=SET.mute?'🔇':'🔊';lb=SET.mute?'เปิดเสียง':'ปิดเสียง'}if(lb==='ออนไลน์'&&typeof NET!=='undefined'&&NET.on)lb='ออนไลน์ '+NET.n;
  if(lb==='พาสซีฟ'){const n=typeof ptFree==='function'?ptFree():0;if(n)badge='<i style="position:absolute;right:3px;top:2px;font:900 9px system-ui;font-style:normal;background:#e04a3a;border-radius:7px;padding:0 4px">'+n+'</i>'}
  return '<button data-i="'+i+'" class="'+(m[3]||'')+'" style="position:relative">'+ic+'<small>'+lb+'</small>'+badge+'</button>'}).join('')}
pmRender7();
{const _f=faceEl.onclick;faceEl.onclick=e=>{pmRender7();_f(e)}}
// จุดแจ้งเตือนบนรูปโปรไฟล์ (แทนตัวเลขบนปุ่ม 🌟 ที่เอาออก)
{const d=document.createElement('i');d.id='pmdot7';d.hidden=true;const host=faceEl.parentNode;if(host){if(getComputedStyle(host).position==='static')host.style.position='relative';host.appendChild(d)}
 setInterval(()=>{try{const n=typeof ptFree==='function'?ptFree():0;d.hidden=!n;d.textContent='🌟'+(n>99?'99+':n);d.style.right='auto';d.style.left=(faceEl.offsetLeft+faceEl.offsetWidth-12)+'px';d.style.top=(faceEl.offsetTop+faceEl.offsetHeight-12)+'px';d.style.zIndex=5}catch(e){}},1000)}
// คอลัมน์ขวาเหลือปุ่มออโต้ปุ่มเดียว: ชิดมุมบนขวา
rcol7=function(){try{const a=gid('autob');if(a)a.style.setProperty('top','calc(8px + var(--st,0px))','important')}catch(e){}};rcol7();
