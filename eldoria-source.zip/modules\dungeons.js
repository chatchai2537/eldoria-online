// =====================================================================
// dungeons.js — ดันเจี้ยนไม่สิ้นสุด: ชั้น → มอน/บอส/รางวัล จาก GAME_DATABASE.DungeonsData · หน้าโหลดตอนลงชั้น
// =====================================================================
function DGMAX7(){try{const m=GAME_DATABASE.DungeonsData.maxFloor;return isFinite(m)&&m>0?m:999}catch(e){return 100}}
function dgMobs7(f,cols){try{const DB=GAME_DATABASE,B=DB.band(f);const L=[];for(const id of B.monsterSpawns){const M=DB.monster(id);if(!M||M.eventOnly)continue;if(M.floors&&(f<M.floors[0]||f>M.floors[1]))continue;L.push([M.family,M.name,M.colors==='band'?cols:M.colors,M.id])}
  return L.length?L:dgPool(f).map(k=>[k,DGNAME[k],cols])}catch(e){console.warn('[dungeons] mobs',e);return dgPool(f).map(k=>[k,DGNAME[k],cols])}}
function dgLv7(f){const E=GAME_DATABASE.DungeonsData.endless;if(f>=E.fromFloor){const c=E.levelCap;return [c,c+2]}return [f,f+2]}
function dgBossOf7(f){const B=dgBoss(f);try{const band=GAME_DATABASE.band(f);if(band.bossId){const M=GAME_DATABASE.monster(band.bossId);if(M)return {f:M.family,n:M.name+' ชั้น '+f,lv:Math.min(110,f+3),c:M.colors==='band'?B.c:M.colors}}}catch(e){}return B}
function dgInfo7(f){const DB=GAME_DATABASE,B=DB.band(f),E=DB.DungeonsData.endless,sc=Eldoria.modules.monsters&&Eldoria.modules.monsters.floorScale?Eldoria.modules.monsters.floorScale(f):{hp:1,atk:1,def:0};
 return {floor:f,band:B.name,reqLevel:Math.min(f,E.levelCap),monsters:dgMobs7(f,['#999','#444','#fff']).map(t=>t[1]),endless:f>=E.fromFloor,hp:sc.hp,atk:sc.atk,def:sc.def,reward:f>=E.fromFloor?1+E.rewardGrowth*(f-E.fromFloor+1):1}}
function dgGo7(f){f=Math.max(1,Math.min(DGMAX7(),f|0));const I=dgInfo7(f);
 const ok=LoadingScreenManager.go({icon:I.endless?'🌌':'🗝️',title:'ดันเจี้ยนชั้น '+f,tip:I.band+(I.endless?' · มอนแกร่งขึ้น ×'+I.hp.toFixed(2):'')},()=>Guard.run('enterDg',()=>enterDg(f),'isInteracting'));
 if(!ok)enterDg(f)}
window.DGMAX7=DGMAX7;window.dgMobs7=dgMobs7;window.dgLv7=dgLv7;window.dgBossOf7=dgBossOf7;window.dgInfo7=dgInfo7;window.dgGo7=dgGo7;
(()=>{
 // ลงชั้น → ส่งเหตุการณ์
 const _ed=enterDg;enterDg=function(f){const r=_ed(f);try{if(D&&D.dg===f)EventBus.emit(EV.DUNGEON_FLOOR_ENTER,dgInfo7(f))}catch(e){}return r};
 // ชนะบอสชั้น → ส่งเหตุการณ์
 EventBus.on(EV.BOSS_DIED,d=>{if(d.floor)EventBus.emit(EV.DUNGEON_FLOOR_CLEARED,{floor:d.floor})},'dungeons.clear');
 // รางวัลชั้นไม่สิ้นสุด: เพิ่มตามชั้น
 const _rw=dgReward;dgReward=function(f){const R=_rw(f);try{const I=dgInfo7(f);if(I.reward>1){const extra=Math.min(R.length*3,Math.round(R.length*(I.reward-1)));for(let i=0;i<extra;i++)R.push(R[Math.floor(Math.random()*R.length)])}}catch(e){}return R};
 // เมนูดันเจี้ยน: แสดงข้อมูลจากฐานข้อมูล + ปุ่มลงแบบหน้าโหลด
 const _om=openDgMenu;openDgMenu=function(){_om();Guard.run('dgMenu',()=>{const f=DG.sel,I=dgInfo7(f);for(const sm of shopEl.querySelectorAll('small'))if(/มอนสเตอร์ Lv\./.test(sm.textContent)){const B=dgBossOf7(f);
    sm.innerHTML='🏰 '+I.band+(I.endless?' <b style="color:#c8a0ff">(ไม่สิ้นสุด)</b>':'')+'<br>มอนสเตอร์: '+I.monsters.join(' · ')+'<br>บอส: 👑 '+B.n+' Lv.'+B.lv+(I.endless?'<br>💀 พลังมอน HP ×'+I.hp.toFixed(2)+' · ATK ×'+I.atk.toFixed(2)+' · เกราะ '+Math.round(I.def*100)+'%<br>🎁 รางวัล ×'+I.reward.toFixed(2):'<br>รางวัล: หินเสริมพลัง · แท่งโลหะ · เหรียญ · หินอวยพร (หายาก) · อุปกรณ์')}
   const b=[...shopEl.querySelectorAll('button')].find(q=>/ลงดันเจี้ยนชั้น/.test(q.textContent));if(b)b.setAttribute('onclick','dgGo7('+f+')')})};
 Eldoria.register('dungeons',{go:dgGo7,info:dgInfo7,maxFloor:DGMAX7,mobs:dgMobs7});
})();
