
// =====================================================================
// v4.6 (ง) : ดนตรีใหม่ตามสถานการณ์ (เมือง/ทุ่ง/กลางคืน/เหมือง/ดันเจี้ยน/ต่อสู้/บอส/บ้าน/โรงเตี๊ยม/ปราสาท) + สลับเพลงเมื่อเจอบอส
//            เนื้อเรื่องเข้มข้น (ฉากคัตซีนพร้อมตัวละคร) · บทสอนจับมือ (มือชี้/ลาก) · หน้าตั้งค่าแบบแท็บ
// =====================================================================
// ---------------- 1) ดนตรี ----------------
const MZ={g:null,cur:null,want:null,next:0,step:0,bar:0,swT:0,stinger:0};
const SC={maj:[0,2,4,5,7,9,11],min:[0,2,3,5,7,8,10],dor:[0,2,3,5,7,9,10],hmin:[0,2,3,5,7,8,11],phr:[0,1,3,5,7,8,10],pen:[0,2,4,7,9,0,0]};
const N_=null;
const THEMES={
 town:{bpm:100,root:60,sc:'maj',prog:[0,5,3,4],lead:'pluck',lv:.16,pad:.05,bass:'walk',dr:'light',
  mel:[[4,N_,5,4,2,N_,0,N_],[2,N_,4,N_,5,4,2,N_],[3,N_,4,3,1,N_,6,N_],[4,5,6,7,6,N_,4,N_],[4,N_,5,4,2,N_,0,N_],[2,4,5,7,5,N_,4,N_],[3,N_,2,1,0,N_,1,N_],[2,N_,1,N_,0,N_,N_,N_]]},
 shop:{bpm:92,root:65,sc:'maj',prog:[0,3,4,0],lead:'bell',lv:.1,pad:.04,bass:'root',dr:'none',mel:[[4,N_,N_,2,N_,N_,0,N_],[3,N_,N_,5,N_,N_,4,N_],[2,N_,N_,4,N_,N_,6,N_],[7,N_,N_,N_,4,N_,N_,N_]]},
 field:{bpm:116,root:62,sc:'dor',prog:[0,6,5,6],lead:'flute',lv:.12,pad:.06,bass:'march',dr:'march',
  mel:[[0,N_,2,3,4,N_,4,N_],[3,2,3,N_,6,N_,5,N_],[4,N_,2,0,1,N_,2,N_],[3,N_,1,N_,4,N_,N_,N_],[7,N_,6,5,4,N_,2,N_],[3,N_,4,5,6,N_,5,N_],[4,3,2,N_,1,N_,2,N_],[0,N_,N_,N_,N_,N_,N_,N_]]},
 night:{bpm:76,root:57,sc:'min',prog:[0,5,3,4],lead:'bell',lv:.09,pad:.06,bass:'root',dr:'none',mel:[[4,N_,N_,N_,2,N_,N_,N_],[3,N_,N_,4,N_,N_,2,N_],[0,N_,N_,N_,6,N_,N_,N_],[4,N_,N_,N_,N_,N_,N_,N_]]},
 mine:{bpm:84,root:50,sc:'phr',prog:[0,1,0,6],lead:'bell',lv:.08,pad:.08,bass:'drone',dr:'tom',mel:[[7,N_,N_,N_,8,N_,N_,N_],[N_,N_,5,N_,N_,N_,4,N_],[7,N_,N_,8,N_,N_,10,N_],[9,N_,N_,N_,N_,N_,N_,N_]]},
 dungeon:{bpm:80,root:45,sc:'phr',prog:[0,1,6,1],lead:'bell',lv:.07,pad:.09,bass:'drone',dr:'heart',mel:[[N_,N_,7,N_,N_,N_,8,N_],[N_,N_,N_,N_,6,N_,N_,N_],[7,N_,N_,N_,N_,N_,1,N_],[N_,N_,N_,N_,N_,N_,N_,N_]]},
 battle:{bpm:144,root:57,sc:'min',prog:[0,5,6,4],lead:'saw',lv:.06,pad:.04,bass:'eighth',dr:'rock',
  mel:[[7,N_,7,6,7,N_,9,N_],[8,N_,7,N_,5,N_,4,N_],[6,N_,6,5,6,N_,8,N_],[7,N_,N_,N_,4,N_,N_,N_]]},
 boss:{bpm:160,root:52,sc:'hmin',prog:[0,5,3,4],lead:'brass',lv:.07,pad:.06,bass:'sixteen',dr:'epic',choir:1,
  mel:[[7,N_,N_,6,7,N_,9,N_],[10,N_,9,N_,8,N_,7,N_],[5,N_,N_,4,5,N_,7,N_],[6,N_,5,N_,4,N_,2,N_],[7,N_,N_,6,7,N_,10,N_],[11,N_,10,N_,9,N_,8,N_],[9,8,7,6,5,4,3,2],[4,N_,N_,N_,6,N_,N_,N_]]},
 abyss:{bpm:138,root:49,sc:'hmin',prog:[0,1,0,4],lead:'brass',lv:.07,pad:.08,bass:'sixteen',dr:'epic',choir:1,organ:1,
  mel:[[7,N_,N_,8,7,N_,N_,N_],[6,N_,N_,N_,4,N_,N_,N_],[7,N_,8,N_,10,N_,8,N_],[11,N_,N_,N_,N_,N_,N_,N_]]},
 home:{bpm:78,root:65,sc:'pen',prog:[0,3,4,0],lead:'bell',lv:.11,pad:.05,bass:'root',dr:'none',mel:[[2,N_,4,N_,3,N_,2,N_],[1,N_,N_,N_,0,N_,N_,N_],[2,N_,3,N_,4,N_,7,N_],[4,N_,N_,N_,N_,N_,N_,N_]]},
 inn:{bpm:132,root:62,sc:'maj',prog:[0,4,0,4],lead:'fiddle',lv:.08,pad:.03,bass:'root',dr:'clap',
  mel:[[0,2,4,2,4,7,4,2],[1,3,4,3,1,6,4,2],[0,2,4,7,9,7,4,2],[1,4,3,1,0,N_,0,N_]]},
 hall:{bpm:72,root:58,sc:'maj',prog:[0,3,4,0],lead:'brass',lv:.06,pad:.07,bass:'root',dr:'timp',mel:[[4,N_,N_,4,7,N_,N_,N_],[5,N_,4,N_,3,N_,N_,N_],[4,N_,N_,7,9,N_,N_,N_],[7,N_,N_,N_,N_,N_,N_,N_]]}};
const mtof=n=>440*Math.pow(2,(n-69)/12);
function degN(T,d){const s=SC[T.sc],L=T.sc==='pen'?5:7,i=((d%L)+L)%L,o=Math.floor(d/L);return T.root+s[i]+12*o}
function vce(type,f,t,dur,v,o){const C=AU.c;if(!C)return;const os=C.createOscillator(),g=C.createGain();let out=g;os.type=type;os.frequency.setValueAtTime(f,t);if(o&&o.det)os.detune.setValueAtTime(o.det,t);
 if(o&&o.vib){const l=C.createOscillator(),lg=C.createGain();l.frequency.value=5.5;lg.gain.value=f*.012;l.connect(lg);lg.connect(os.frequency);l.start(t);l.stop(t+dur+.1)}
 if(o&&o.lp){const fl=C.createBiquadFilter();fl.type='lowpass';fl.frequency.setValueAtTime(o.lp,t);if(o.lp2)fl.frequency.exponentialRampToValueAtTime(o.lp2,t+dur);fl.Q.value=o.q||1;os.connect(fl);fl.connect(g)}else os.connect(g);
 const a=(o&&o.a)||.005;g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(v,t+a);g.gain.exponentialRampToValueAtTime(.0001,t+dur);out.connect(MZ.g);os.start(t);os.stop(t+dur+.05)}
function nzv(t,d,v,f1,f2,ty,q){const C=AU.c;if(!C||!AU.nb)return;const s=C.createBufferSource(),f=C.createBiquadFilter(),g=C.createGain();s.buffer=AU.nb;f.type=ty||'bandpass';f.Q.value=q||1;f.frequency.setValueAtTime(f1,t);f.frequency.exponentialRampToValueAtTime(f2,t+d);g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.0001,t+d);s.connect(f);f.connect(g);g.connect(MZ.g);s.start(t,Math.random());s.stop(t+d+.05)}
const INST={
 pluck:(f,t,d,v)=>{vce('triangle',f,t,Math.min(d,.6),v,{lp:3200,lp2:600});vce('sine',f*2,t,.25,v*.3)},
 bell:(f,t,d,v)=>{vce('sine',f*2,t,1.6,v*.8);vce('sine',f*5.4,t,.5,v*.18)},
 flute:(f,t,d,v)=>{vce('triangle',f*2,t,d*.95,v,{a:.04,vib:1});vce('sine',f*4,t,d*.6,v*.1,{a:.05})},
 saw:(f,t,d,v)=>{vce('sawtooth',f*2,t,Math.min(d,.22),v,{lp:2600,lp2:900});vce('sawtooth',f*2,t,Math.min(d,.22),v*.6,{det:9,lp:2200,lp2:700})},
 brass:(f,t,d,v)=>{vce('sawtooth',f*2,t,d*.9,v,{a:.03,lp:600,lp2:2400,vib:1});vce('sawtooth',f*2,t,d*.9,v*.7,{a:.03,det:-8,lp:500,lp2:2000})},
 fiddle:(f,t,d,v)=>{vce('sawtooth',f*2,t,d*.9,v,{a:.02,lp:3000,vib:1})}};
function padChord(T,deg,t,len){const v=T.pad;if(!v)return;for(const iv of [0,2,4]){const f=mtof(degN(T,deg+iv)-12);vce('sawtooth',f,t,len,v*.35,{a:.4,lp:900,det:-6});vce('sawtooth',f,t,len,v*.35,{a:.4,lp:900,det:7})}
 if(T.choir)for(const iv of [0,2,4])vce('triangle',mtof(degN(T,deg+iv)),t,len,v*.4,{a:.35,vib:1});if(T.organ)for(const iv of [0,4,7])vce('square',mtof(degN(T,deg+iv)-24),t,len,v*.15,{a:.2,lp:700})}
function drums(T,s,t,spb,tension){const p=T.dr,st=s%16;
 const kick=v=>{vce('sine',150,t,.25,v,{});const C=AU.c;try{const o=C.createOscillator(),g=C.createGain();o.frequency.setValueAtTime(150,t);o.frequency.exponentialRampToValueAtTime(42,t+.2);g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.0001,t+.3);o.connect(g);g.connect(MZ.g);o.start(t);o.stop(t+.35)}catch(e){}},
  snare=v=>{nzv(t,.16,v,2400,900,'bandpass',.8);vce('triangle',200,t,.08,v*.4)},hat=v=>nzv(t,.04,v,9000,7000,'highpass',1),tom=(f,v)=>{try{const C=AU.c,o=C.createOscillator(),g=C.createGain();o.frequency.setValueAtTime(f,t);o.frequency.exponentialRampToValueAtTime(f*.5,t+.3);g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.0001,t+.35);o.connect(g);g.connect(MZ.g);o.start(t);o.stop(t+.4)}catch(e){}};
 if(p==='light'){if(st===0||st===8)kick(.22);if(st%4===2)hat(.05);if(st===12)nzv(t,.08,.06,6000,3000,'bandpass',2)}
 else if(p==='march'){if(st%8===0)kick(.25);if(st===4||st===12)snare(.12);if(st===14||st===15)snare(.05);if(st%2===0)hat(.03)}
 else if(p==='rock'){if(st%4===0||st===10)kick(.32);if(st===4||st===12)snare(.2);if(st%2===0)hat(.06)}
 else if(p==='epic'){if(st%2===0)kick(.3);if(st===4||st===12)snare(.24);if(st%4===2)hat(.07);if(st===0&&MZ.bar%4===0)nzv(t,1.2,.16,7000,2500,'highpass',.5);if(st===14)tom(160,.25);if(st===15)tom(110,.25)}
 else if(p==='tom'){if(st===0)tom(90,.3);if(st===10)tom(70,.2)}
 else if(p==='heart'){if(st===0||st===3)tom(60,.18+tension*.25);if(tension>.5&&(st===8||st===11))tom(58,.12+tension*.2)}
 else if(p==='clap'){if(st%6===0)kick(.18);if(st%6===3)nzv(t,.08,.12,2000,1200,'bandpass',1.5)}
 else if(p==='timp'){if(st===0)tom(70,.35);if(st===12&&MZ.bar%2)tom(90,.25)}}
function bassline(T,deg,s,t,spb){const st=s%16,f=mtof(degN(T,deg)-24),b=T.bass;
 if(b==='root'){if(st===0)vce('sine',f,t,spb*7,.16)}
 else if(b==='walk'){if(st%4===0){const w=[0,2,4,2][st/4];vce('triangle',mtof(degN(T,deg+w)-24),t,spb*3.5,.14)}}
 else if(b==='march'){if(st%4===0)vce('triangle',st%8?mtof(degN(T,deg+4)-24):f,t,spb*3,.15)}
 else if(b==='drone'){if(st===0){vce('sawtooth',f,t,spb*16,.06,{a:.6,lp:300});vce('sine',f/2,t,spb*16,.14,{a:.6})}}
 else if(b==='eighth'){if(st%2===0)vce('sawtooth',f,t,spb*1.6,.09,{lp:500});}
 else if(b==='sixteen'){vce('sawtooth',f,t,spb*.9,.07,{lp:420});if(st%4===0)vce('sine',f/2,t,spb*3,.12)}}
function musState(){if(!D){const n=typeof dayDark==='function'&&dayDark(DAY.t)>.55;return musNear(n?'night':'field')}
 if(D.shop)return D.shop==='inn'?'inn':D.shop==='hall'?'hall':'shop';if(D.town)return 'town';if(D.home)return 'home';
 if(D.zone){const b=D.boss;if(b&&!b.dead&&Math.hypot(b.x-P.x,b.y-P.y)<560)return b.abyss?'abyss':'boss';return musNear(D.dg?'dungeon':'mine')}return 'field'}
function musNear(def){let c=0;try{for(const e of enemies()){if(e.dead)continue;const d=Math.hypot(e.x-P.x,e.y-P.y);if(d<230&&(e.aggro||e.chase||e.tg||d<120))c++}}catch(e){}if(c>=2||(c>=1&&MZ.cur==='battle'))return 'battle';return def}
function musTick(){const C=AU.c;if(!C||SET.mute||SET.music<=0||document.hidden)return;if(!MZ.g){MZ.g=C.createGain();MZ.g.gain.value=1;MZ.g.connect(AU.mu);MZ.next=C.currentTime+.1}
 let w=musState();if(w==='battle'&&MZ.cur!=='battle'){MZ.batT=(MZ.batT||0)+1;if(MZ.batT<3)w=MZ.cur||w}else MZ.batT=0;
 if(w!==MZ.cur&&MZ.cur&&(MZ.cur==='battle'&&w!=='boss'&&w!=='abyss')){MZ.calm=(MZ.calm||0)+1;if(MZ.calm<8)w='battle'}else MZ.calm=0;
 if(w!==MZ.cur){const boss=w==='boss'||w==='abyss';MZ.g.gain.cancelScheduledValues(C.currentTime);MZ.g.gain.setTargetAtTime(.0001,C.currentTime,.12);const nt=C.currentTime+.45;MZ.g.gain.setTargetAtTime(1,nt,.2);MZ.cur=w;MZ.step=0;MZ.bar=0;MZ.next=nt;
  if(boss){nzv(nt,1.4,.3,6000,1500,'highpass',.5);for(const iv of [0,3,7])vce('sawtooth',mtof(degN(THEMES[w],iv)),nt,1.5,.08,{a:.02,lp:800,lp2:3000});try{const b=D.boss;if(b&&!MZ.bn){MZ.bn=b;banner('⚠️ '+(b.nm||'บอส'),'เผชิญหน้ากับบอส!','red')}}catch(e){}}}
 if(!(w==='boss'||w==='abyss'))MZ.bn=null;
 const T=THEMES[MZ.cur];if(!T)return;const spb=60/T.bpm/4,tension=D&&D.dg?Math.min(1,D.dg/80):0;
 while(MZ.next<C.currentTime+.6){const t=MZ.next,s=MZ.step,st=s%16;if(st===0)MZ.bar++;const bi=(MZ.bar-1+T.prog.length*64)%T.prog.length,deg=T.prog[bi];
  if(st===0)padChord(T,deg,t,spb*16);bassline(T,deg,s,t,spb);drums(T,s,t,spb,tension);
  if(st%2===0){const M=T.mel[(MZ.bar-1)%T.mel.length],n=M[st/2];if(n!=null){let len=1;for(let j=st/2+1;j<8&&M[j]==null;j++)len++;(INST[T.lead]||INST.pluck)(mtof(degN(T,n)),t,spb*2*len*.95,T.lv)}}
  if(MZ.cur==='dungeon'&&tension>.4&&st===6&&Math.random()<tension*.5)INST.bell(mtof(degN(T,1)+12),t,1,.04);
  MZ.next+=spb;MZ.step++}}
musicTick=function(){try{musTick()}catch(e){}};
if(AU.c&&!AU._mz){AU._mz=1;setInterval(musicTick,140)}else{const _iv=setInterval(()=>{if(AU.c){clearInterval(_iv);setInterval(musicTick,140)}},500)}

// ---------------- 2) เนื้อเรื่องเข้มข้น: คัตซีนตัวละคร ----------------
const CAST={gareth:{n:'กัปตันแกเร็ธ',skin:'#e8c4a0',hair:'#6a4a2a',beard:1,armor:'#8a8e9a',cape:'#1a3a8a'},princess:{n:'เจ้าหญิงเอเลน่า',skin:'#f6dcc4',hair:'#f0d070',crown:'#ffd23a',dress:'#e888b8',fem:1},
 morvane:{n:'อัครเวทมอร์เวน',skin:'#d8c8c0',hair:'#2a1a3a',hood:'#4a1a6a',eye:'#c040ff'},king:{n:'พระราชาอัลดริค',skin:'#ecc8a4',hair:'#e8e8e8',beard:1,crown:'#ffd23a',robe:'#8a1a1a'},
 iris:{n:'ไอริส',skin:'#f4d8bc',hair:'#c8843a',fem:1,dress:'#3a5a9a'},emperor:{n:'จักรพรรดิเงา',skin:'#140a1c',hair:'#000',crown:'#6a2a8a',eye:'#ff3a5a',shadow:1},
 dragon:{n:'มังกรคริสตัล',dragon:1}};
function cineBust(k,W,H,t,who,s){const C=CAST[who];if(!C)return;const cx=W*.5,cy=H*.33,S=s*1.0;
 const bg=k.createRadialGradient(cx,cy,10,cx,cy,H*.8);bg.addColorStop(0,C.shadow?'rgba(120,20,60,.5)':C.dragon?'rgba(90,200,255,.35)':'rgba(255,230,170,.25)');bg.addColorStop(1,'rgba(0,0,0,0)');k.fillStyle=bg;k.fillRect(0,0,W,H);
 if(C.dragon){k.save();k.translate(cx,cy);k.scale(S,S);k.fillStyle='#bfe8ff';k.strokeStyle='#3a7ab0';k.lineWidth=3;k.beginPath();k.moveTo(-90,40);k.quadraticCurveTo(-60,-30,0,-40);k.quadraticCurveTo(70,-48,110,-10);k.lineTo(120,10);k.quadraticCurveTo(80,6,60,20);k.quadraticCurveTo(20,40,-90,40);k.fill();k.stroke();
  k.fillStyle='#e8f8ff';for(const [x,y] of [[-10,-40],[20,-46],[50,-44]]){k.beginPath();k.moveTo(x,y);k.lineTo(x+8,y-26);k.lineTo(x+14,y);k.fill();k.stroke()}k.fillStyle='#fff';k.beginPath();k.ellipse(62,-14,9,5,0,0,7);k.fill();k.fillStyle='#2a8ad0';k.beginPath();k.arc(64,-14,3.5+Math.sin(t*2),0,7);k.fill();k.restore();return}
 k.save();k.translate(cx,cy+40*S);k.scale(S,S);const br=Math.sin(t*1.5)*1.5;
 // ไหล่/ลำตัว
 const body=C.armor||C.robe||C.dress||C.hood||'#333';const g=k.createLinearGradient(0,10,0,120);g.addColorStop(0,body);g.addColorStop(1,'#0a0a10');k.fillStyle=g;k.beginPath();k.moveTo(-80,120);k.quadraticCurveTo(-74,30,-34,18+br);k.lineTo(34,18+br);k.quadraticCurveTo(74,30,80,120);k.fill();
 if(C.cape){k.fillStyle=C.cape;k.beginPath();k.moveTo(-80,120);k.quadraticCurveTo(-86,40,-40,18);k.lineTo(-50,120);k.fill();k.beginPath();k.moveTo(80,120);k.quadraticCurveTo(86,40,40,18);k.lineTo(50,120);k.fill()}
 if(C.armor){k.fillStyle='rgba(255,255,255,.25)';k.beginPath();k.ellipse(-46,36,18,10,-.3,0,7);k.ellipse(46,36,18,10,.3,0,7);k.fill()}
 // คอ+หน้า
 k.fillStyle=C.skin;k.fillRect(-11,-6+br,22,26);k.beginPath();k.ellipse(0,-30+br,30,36,0,0,7);k.fill();
 if(C.hood){k.fillStyle=C.hood;k.beginPath();k.moveTo(-40,0);k.quadraticCurveTo(-44,-74,0,-78);k.quadraticCurveTo(44,-74,40,0);k.quadraticCurveTo(26,-50,0,-56);k.quadraticCurveTo(-26,-50,-40,0);k.fill()}
 else{k.fillStyle=C.hair;k.beginPath();k.ellipse(0,-50+br,32,22,0,Math.PI,0);k.fill();if(C.fem){k.beginPath();k.moveTo(-32,-50);k.quadraticCurveTo(-46,0,-34,30);k.lineTo(-24,-20);k.fill();k.beginPath();k.moveTo(32,-50);k.quadraticCurveTo(46,0,34,30);k.lineTo(24,-20);k.fill()}}
 // ตา
 const ey=-30+br,blink=(t%4)<.12;if(C.shadow||C.eye){k.save();k.globalCompositeOperation='lighter';for(const sx of [-12,12]){const eg=k.createRadialGradient(sx,ey,0,sx,ey,14);eg.addColorStop(0,C.eye||'#ff3a5a');eg.addColorStop(1,'rgba(0,0,0,0)');k.fillStyle=eg;k.fillRect(sx-14,ey-14,28,28)}k.restore();k.fillStyle='#fff';for(const sx of [-12,12])k.fillRect(sx-5,ey-1.5,10,3)}
 else{k.fillStyle='#1a1410';for(const sx of [-12,12])k.fillRect(sx-4,ey-(blink?1:4),8,blink?2:8);k.fillStyle='#fff';if(!blink)for(const sx of [-12,12])k.fillRect(sx-2,ey-3,2,2);k.strokeStyle='rgba(120,60,40,.6)';k.lineWidth=2;k.beginPath();k.moveTo(-6,-10+br);k.quadraticCurveTo(0,C.fem?-7:-9,6,-10+br);k.stroke()}
 if(C.beard){k.fillStyle=C.hair;k.beginPath();k.moveTo(-26,-24);k.quadraticCurveTo(-20,14,0,16);k.quadraticCurveTo(20,14,26,-24);k.quadraticCurveTo(14,-8,0,-10);k.quadraticCurveTo(-14,-8,-26,-24);k.fill()}
 if(C.crown){k.fillStyle=C.crown;k.strokeStyle='#5a3a08';k.lineWidth=2;k.beginPath();k.moveTo(-26,-62+br);for(let i=0;i<=4;i++){k.lineTo(-26+i*13,-62-(i%2?6:16)+br)}k.lineTo(26,-62+br);k.closePath();k.fill();k.stroke();k.fillStyle=C.shadow?'#ff3a5a':'#e04a6a';k.beginPath();k.arc(0,-70+br,3,0,7);k.fill()}
 if(C.shadow){for(let i=0;i<10;i++){k.fillStyle='rgba(100,20,140,'+(.2+.15*Math.sin(t*3+i))+')';k.beginPath();k.arc(Math.sin(t+i*2)*70,40-((t*30+i*20)%140),6+i%4*3,0,7);k.fill()}}
 k.restore();k.save();k.font='bold '+Math.round(15*s)+'px system-ui,"Noto Sans Thai",sans-serif';k.textAlign='center';const nm=C.n,tw=k.measureText(nm).width+24;k.fillStyle='rgba(20,14,6,.85)';k.fillRect(cx-tw/2,H*.06,tw,24*s);k.strokeStyle='#e8c14a';k.lineWidth=1.5;k.strokeRect(cx-tw/2,H*.06,tw,24*s);k.fillStyle='#ffe9a0';k.fillText(nm,cx,H*.06+17*s);k.restore()}
function cineFx(k,W,H,t,sc,u,s){const cx=W/2,cy=H*.42;
 if(sc==='fire'){const g=k.createLinearGradient(0,H*.3,0,H);g.addColorStop(0,'#1a0402');g.addColorStop(1,'#6a1a04');k.fillStyle=g;k.fillRect(0,0,W,H);for(let i=0;i<7;i++){const x=W*(i+.5)/7,h=(60+(i*37)%50)*s;k.fillStyle='#120804';k.fillRect(x-24*s,H*.7-h,48*s,h);k.beginPath();k.moveTo(x-30*s,H*.7-h);k.lineTo(x,H*.7-h-26*s);k.lineTo(x+30*s,H*.7-h);k.fill()}
  for(let i=0;i<40;i++){const x=(i*53.7)%W,y=H*.72-((t*60+i*31)%(H*.6)),r=(4+(i%5)*3)*s;const fg=k.createRadialGradient(x,y,0,x,y,r*2);fg.addColorStop(0,'rgba(255,200,80,.8)');fg.addColorStop(1,'rgba(255,60,0,0)');k.fillStyle=fg;k.fillRect(x-r*2,y-r*2,r*4,r*4)}}
 else if(sc==='kidnap'){k.fillStyle='#0a0a1a';k.fillRect(0,0,W,H);k.fillStyle='#e8e8ff';k.beginPath();k.arc(W*.8,H*.2,26*s,0,7);k.fill();k.fillStyle='#1a1a2a';k.fillRect(cx-40*s,H*.25,80*s,H*.6);k.beginPath();k.moveTo(cx-50*s,H*.25);k.lineTo(cx,H*.1);k.lineTo(cx+50*s,H*.25);k.fill();k.fillStyle='#ffd870';k.fillRect(cx-10*s,H*.35,20*s,26*s);
  const p=Math.min(1,u/2);k.fillStyle='rgba(100,20,140,.8)';k.beginPath();k.ellipse(cx+p*W*.3,H*.4-p*H*.2,30*s,40*s,0,0,7);k.fill();k.fillStyle='#c040ff';k.fillRect(cx+p*W*.3-8*s,H*.38-p*H*.2,5*s,2*s);k.fillRect(cx+p*W*.3+3*s,H*.38-p*H*.2,5*s,2*s)}
 else if(sc==='sacrifice'){k.fillStyle='#0a0806';k.fillRect(0,0,W,H);const g=k.createLinearGradient(0,0,0,H);g.addColorStop(0,'rgba(255,240,180,.0)');g.addColorStop(1,'rgba(255,240,180,.35)');k.fillStyle=g;k.fillRect(cx-60*s,0,120*s,H*.75);k.fillStyle='#3a2a1a';k.fillRect(0,H*.75,W,H*.25);
  k.save();k.translate(cx,H*.75);k.rotate(.08);k.fillStyle='#c8ccd6';k.fillRect(-4*s,-90*s,8*s,90*s);k.fillStyle='#e8c14a';k.fillRect(-16*s,-96*s,32*s,6*s);k.fillStyle='#5a3418';k.fillRect(-3*s,-118*s,6*s,22*s);k.restore();k.fillStyle='#1a3a8a';k.beginPath();k.moveTo(cx-10*s,H*.75);k.quadraticCurveTo(cx-40*s,H*.6,cx-70*s,H*.76);k.fill();
  for(let i=0;i<25;i++){k.fillStyle='rgba(255,240,200,'+(.4+.4*Math.sin(t*2+i))+')';k.fillRect(cx+Math.sin(i*7.7)*80*s,H*.75-((t*25+i*17)%(H*.7)),2*s,2*s)}}}
const CINESC=new Set(['fire','kidnap','sacrifice','bust']);
{const _cd=cineDraw;cineDraw=function(now){const it=CINE.L&&CINE.L[CINE.i];if(!it||!(CINESC.has(it.s)||it.who)||cineEl.hidden)return _cd(now);requestAnimationFrame(cineDraw);
  const W=cCv.width=cCv.clientWidth,H=cCv.height=cCv.clientHeight,k=cK,t=now/1000,u=(now-CINE.t0)/1000,s=Math.min(W,H)/500;k.fillStyle='#04030a';k.fillRect(0,0,W,H);
  if(CINESC.has(it.s)&&it.s!=='bust')cineFx(k,W,H,t,it.s,u,s);if(it.who){k.save();k.globalAlpha=Math.min(1,u*2.5);cineBust(k,W,H,t,it.who,s);k.restore()}
  const vg=k.createRadialGradient(W/2,H/2,H*.3,W/2,H/2,H*.9);vg.addColorStop(0,'rgba(0,0,0,0)');vg.addColorStop(1,'rgba(0,0,0,.7)');k.fillStyle=vg;k.fillRect(0,0,W,H)}}
const CB6=(who,t)=>({s:'bust',who,t:'「'+CAST[who].n+'」 '+t});
const STORYCS={
 s1:[CB6('gareth','ข้าคือกัปตันแกเร็ธ หัวหน้าองครักษ์แห่งเอลโดเรีย… สไลม์พวกนั้นไม่ได้คลั่งเอง มีบางอย่างปลุกพวกมันขึ้นมา'),CB6('gareth','ระวังตัวด้วย เจ้าหนู ข้าเห็นคนดี ๆ ล้มไปมากแล้วในทุ่งนั่น')],
 e1:[CB6('gareth','เห็นไหม… ในเจลของมันมีประกายสีม่วง นี่คือพลังของห้วงลึก ข้าจะรายงานพระราชาเอง')],
 s2:[CB6('gareth','อาวุธหินจะพาเจ้าไปตายเปล่า ๆ ไปหาช่างหนวดเหล็กที่ร้านอาวุธ ขอตำราช่างแล้วตีดาบด้วยมือเจ้าเอง')],
 s3:[CB6('princess','ข้าคือเอเลน่า ธิดาของพระราชา… ข้าเห็นเจ้าในความฝัน ถือแสงอรุณไว้ในมือ'),CB6('princess','ปรมาจารย์อาชีพที่จัตุรัสจะชี้ทางให้เจ้า… ได้โปรดอย่าตายนะ')],
 s4:[{s:'dark',t:'ใต้ทุ่งหญ้า… ประตูดันเจี้ยนส่งเสียงกระซิบเรียกชื่อของเจ้าทุกค่ำคืน'}],
 e4:[CB6('emperor','…ผู้ถูกเลือก… เจ้าได้ยินข้าใช่ไหม… ข้ารอเจ้าอยู่ที่ก้นบึ้ง… ลงมาสิ…')],
 s5:[CB6('morvane','ข้าคืออัครเวทมอร์เวน ที่ปรึกษาแห่งราชสำนัก เหมืองเหล็กร้างอันตรายนัก… ขอให้เจ้าโชคดีนะ ผู้กล้า'),{s:'dark',t:'รอยยิ้มของอัครเวทดูเย็นชาเกินกว่าคำอวยพร…'}],
 e5:[CB6('gareth','บนซากโกเลมมีตราประทับ… ตราของราชสำนัก?! ใครบางคนในปราสาทส่งมันมาเฝ้าเศษผลึก')],
 s6:[CB6('iris','ลัทธิ “เงาจันทร์ดับ” กำลังเคลื่อนไหวในเมือง กิลด์ต้องการคนช่วยสืบ ทำงานให้กิลด์แล้วเราจะได้ข่าวจากสายลับ')],
 e6:[CB6('iris','สายลับบอกว่าผู้นำลัทธิคือ “นายท่านในชุดคลุมม่วง”… คนในวังแน่นอน ระวังตัวให้ดี')],
 s7:[{s:'fire',t:'ระหว่างที่เจ้าอยู่ในเหมือง… อสูรเงาบุกถล่มประตูเมือง!'},CB6('gareth','ข้า… ยังไหว! อย่าห่วงเมือง ไปเอาเศษผลึกในถ้ำลาวามาก่อนที่มันจะสายเกินไป!')],
 s8:[{s:'kidnap',t:'คืนนั้น… เงาร่างหนึ่งในชุดคลุมม่วง พาเจ้าหญิงเอเลน่าหายไปจากหอคอย'},CB6('king','ได้โปรด… ผู้กล้า นำลูกสาวข้ากลับมา ข่าวว่ามันพานางลงไปในดันเจี้ยน')],
 e8:[CB6('emperor','ธิดาแห่งแสง… จะเป็นภาชนะให้ข้าคืนชีพ ฮึ ฮึ ฮึ… เร่งมือเข้าสิ ผู้กล้า')],
 s9:[CB6('gareth','ริบบิ้นของเจ้าหญิง… ตกอยู่บนทางไปยอดเขาเงิน! นางยังมีชีวิต รีบไป!')],
 s10:[CB6('iris','ข่าวด่วน! อัครเวทมอร์เวนหายตัวจากปราสาท ห้องของเขามีแผนที่สุสานทองคำ… ไปให้ถึงก่อนเขา')],
 e10:[CB6('morvane','ฮ่า ๆ ๆ! ช้าไปแล้ว ผู้กล้า ราชาโง่ไว้ใจข้ามาสิบปี… นายท่านแห่งห้วงลึกจะครองแผ่นดินนี้!'),CB6('gareth','เจ้าคนทรยศ! ผู้กล้า ไปตามเจ้าหญิง ข้าจะถ่วงมันไว้เอง!'),{s:'sacrifice',t:'กัปตันแกเร็ธยืนขวางเวทของมอร์เวนจนลมหายใจสุดท้าย… ดาบของเขาปักอยู่หน้าประตูสุสาน'}],
 s11:[CB6('king','แกเร็ธ… สหายเก่าของข้า… จงอย่าให้การเสียสละของเขาสูญเปล่า ข่าวว่าเจ้าหญิงถูกผนึกไว้ที่ชั้นห้าสิบ')],
 e11:[{s:'crystal',t:'ที่ชั้นห้าสิบ เจ้าพบเจ้าหญิงในผนึกคริสตัล — และทำลายมันได้สำเร็จ'},CB6('princess','เจ้ามาจริง ๆ… ข้ารู้ว่าเจ้าต้องมา… แต่แกเร็ธ… ไม่นะ…')],
 s12:[CB6('princess','มังกรคริสตัลเคยเป็นผู้พิทักษ์ผลึกอรุณ ความมืดครอบงำมัน… ได้โปรดปลดปล่อยมันด้วย')],
 e12:[CB6('dragon','ขอบใจ… ที่ปลดปล่อยข้า… จงฟัง… จักรพรรดิเงาเคยเป็นผู้กล้าคนแรก… ผู้ที่ถูกความมืดกลืนกินเพราะสิ้นหวัง…'),CB6('dragon','อย่าให้หัวใจเจ้า… เป็นเช่นเขา…')],
 s13:[CB6('morvane','ลงมาให้ถึงชั้นร้อยสิ ผู้กล้า… นายท่านหิวกระหายแสงในตัวเจ้า!'),CB6('princess','ข้าจะสวดภาวนาให้เจ้าทุกคืน… กลับมานะ สัญญากับข้า'),CB6('king','ทั้งแผ่นดินฝากไว้กับเจ้า… และฝากแกเร็ธด้วย')],
 e13:[CB6('emperor','แสง… อบอุ่นเช่นนี้… ข้าลืมไปนานแสนนาน… ขอบใจ… ผู้กล้าแห่งรุ่นหลัง…'),CB6('princess','เจ้ากลับมาแล้ว! ทั้งเมืองรอเจ้าอยู่ที่ปราสาท')]};
STORY.cs=STORY.cs||{};
setInterval(()=>{if(PAUSED||!cineEl.hidden||!STORY.intro||(DLG&&DLG.open)||P.dead)return;try{if(!titleEl.hidden)return}catch(e){}
 const ch=STORY.ch,key=(STORY.st==='report'?'e':'s')+ch;if(STORY.cs[key]||!STORYCS[key])return;
 try{if(enemies().some(e=>!e.dead&&Math.hypot(e.x-P.x,e.y-P.y)<200))return}catch(e){}
 STORY.cs[key]=1;saveStory();cinePlay(STORYCS[key],()=>{})},900);

// ---------------- 3) บทสอนแบบจับมือ: มือชี้/มือลาก + สปอตไลต์ ----------------
{const st=document.createElement('style');st.textContent=`
#tuthand{position:fixed;z-index:28;pointer-events:none;width:44px;height:44px;font-size:36px;line-height:44px;text-align:center;filter:drop-shadow(0 2px 3px rgba(0,0,0,.7));transition:left .25s,top .25s}
#tuthand[hidden]{display:none}#tuthand.tap{animation:thtap 1s ease-in-out infinite}#tuthand.drag{animation:thdrag 1.6s ease-in-out infinite}
@keyframes thtap{0%,100%{transform:translate(0,0) scale(1)}40%{transform:translate(-4px,-6px) scale(1.08)}55%{transform:translate(0,0) scale(.92)}}
@keyframes thdrag{0%{transform:translate(0,0)}35%{transform:translate(46px,-10px)}55%{transform:translate(46px,-10px)}85%{transform:translate(0,0)}}
#tutring.spot{box-shadow:0 0 0 4px rgba(127,216,255,.35),0 0 24px #7fd8ff,0 0 0 9999px rgba(0,0,0,.42)!important}
#tut .ti{width:46px;height:46px;border-radius:50%;background:radial-gradient(circle at 40% 35%,#fff6d0,#e8b84a 60%,#8a5a1a);display:flex;align-items:center;justify-content:center;font-size:26px;flex:none;box-shadow:0 0 12px rgba(255,220,120,.6)}
`;document.head.appendChild(st)}
const tHand=document.createElement('div');tHand.id='tuthand';tHand.textContent='👆';tHand.hidden=true;document.body.appendChild(tHand);
setInterval(()=>{if(!TUT.on||STORY.tut>=TUTS.length||tutEl.hidden){tHand.hidden=true;tRing.classList.remove('spot');return}const i=STORY.tut,s=TUTS[i];
 if(i===0&&COARSE){const z=gid('joyzone');if(z){const r=z.getBoundingClientRect();tHand.className='drag';tHand.style.left=(r.left+r.width*.32)+'px';tHand.style.top=(r.top+r.height*.62)+'px';tHand.hidden=false;tRing.classList.remove('spot');return}}
 const el=s.el&&s.el();if(!el||el.offsetParent===null||tRing.hidden){tHand.hidden=true;tRing.classList.remove('spot');return}
 const r=el.getBoundingClientRect();tHand.className='tap';tHand.style.left=(r.left+r.width*.55)+'px';tHand.style.top=(r.top+r.height*.6)+'px';tHand.hidden=false;tRing.classList.toggle('spot',[2,3,5,6,7,8].includes(i))},200);
try{const add=[{i:'🔥',h:'อัลติเมท',x:()=>'ตีมอนจนวงรอบรูปโปรไฟล์เต็ม → ไฟจะลุกท่วมกรอบ แล้วปุ่มอัลติเมทจะโผล่ขึ้นมา กดเพื่อร่ายท่าไม้ตาย!',el:()=>gid('ultb').hidden?gid('face'):gid('ultb'),ok:()=>TUT.t>6}];if(!TUTS.some(q=>q.h==='อัลติเมท'))TUTS.splice(TUTS.length-1,0,...add)}catch(e){}

// ---------------- 4) หน้าตั้งค่า: แบ่งแท็บ ตัดของไม่จำเป็น ----------------
{const st=document.createElement('style');st.textContent=`
#menu .tabs6{display:flex;gap:5px;margin:6px 0 8px;flex-wrap:wrap}#menu .tabs6 button{flex:1;min-width:70px;font:inherit;font-weight:800;font-size:12.5px;padding:7px 6px;border-radius:9px;border:1px solid #c8a24a;background:#2a2018;color:#ffe9c0;cursor:pointer}
#menu .tabs6 button.on{background:#ffe9a0;color:#3a2408}#menu [data-pane]{display:none}#menu.p6-ctl [data-pane=ctl],#menu.p6-snd [data-pane=snd],#menu.p6-gfx [data-pane=gfx],#menu.p6-acc [data-pane=acc]{display:revert}
`;document.head.appendChild(st)}
function setupMenu6(){if(menuEl._p6)return;menuEl._p6=1;const kids=[...menuEl.children];let pane=null;const hide=e=>e.style.display='none';
 for(const e of kids){const tx=(e.innerText||'').trim();
  if(e.matches('b.sec')){pane=/ควบคุม/.test(tx)?'ctl':/เสียง/.test(tx)?'snd':/บันทึก|บัญชี|ความปลอดภัย/.test(tx)?'acc':pane;e.dataset.pane=pane;if(/เสียง/.test(tx))e.textContent='🔊 เสียง';continue}
  if(e.id==='resume'||(e.tagName==='SMALL'&&/WASD/.test(tx))){if(COARSE&&e.tagName==='SMALL')hide(e);continue}
  if(e.id==='dbg'||e.id==='cp'||e.id==='secinfo'){hide(e);continue}
  if(/แผนที่วงกลม|หญ้าโยก|แสดง FPS/.test(tx)){hide(e);continue}
  if(COARSE&&/ปุ่มวิ่งคีย์บอร์ด/.test(tx)){hide(e);continue}
  if(!pane)continue;let p=pane;if(pane==='snd'&&!/เสียงรวม|ดนตรี|เอฟเฟกต์/.test(tx))p='gfx';if(/ออนไลน์/.test(tx)||e.id==='fsb')p=e.id==='fsb'?'gfx':'acc';e.dataset.pane=p}
 const tabs=document.createElement('div');tabs.className='tabs6';tabs.innerHTML='<button data-t="ctl">🎮 ควบคุม</button><button data-t="snd">🔊 เสียง</button><button data-t="gfx">🖼️ ภาพ</button><button data-t="acc">👤 บัญชี</button>';
 const first=menuEl.firstElementChild;first.after(tabs);for(const b of tabs.children)b.onclick=e=>{e.stopPropagation();menuTab6(b.dataset.t)};
 const gh=document.createElement('b');gh.className='sec';gh.textContent='🖼️ ภาพ';gh.dataset.pane='gfx';const g1=menuEl.querySelector('[data-pane=gfx]');if(g1)g1.before(gh);
 menuTab6(localStorage.getItem('fm_mtab')||'ctl')}
function menuTab6(t){for(const p of ['ctl','snd','gfx','acc'])menuEl.classList.toggle('p6-'+p,p===t);for(const b of menuEl.querySelectorAll('.tabs6 button'))b.classList.toggle('on',b.dataset.t===t);try{localStorage.setItem('fm_mtab',t)}catch(e){}}
{const _tm=toggleMenu;toggleMenu=function(){const r=_tm.apply(this,arguments);try{if(!menuEl.hidden)setupMenu6()}catch(e){}return r}}
