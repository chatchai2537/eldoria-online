// รัน: npm i playwright && node tests/system_validator.test.js
const {chromium}=require('playwright');const path=require('path');
(async()=>{const b=await chromium.launch();const pg=await b.newPage();const errs=[];pg.on('pageerror',e=>errs.push(e.message));
 await pg.goto('file://'+path.resolve(__dirname,'../game_built.html')+'?devtest=1');await pg.waitForTimeout(2000);
 await pg.evaluate(()=>{titleEl.hidden=true;const i=document.getElementById('introName');if(i){i.value='Test';document.getElementById('introGo').click()}});await pg.waitForTimeout(1500);
 const R=await pg.evaluate(()=>{PAUSED=false;const R=SystemValidator.runChecks({ui:true});
  // ตรวจชั้นดันเจี้ยนไม่สิ้นสุด + อีเวนต์ + Guard
  const x0=P.xp;EventSystem.setActive('double_exp',true);gainXp(10);const xp2=P.xp-x0;EventSystem.setActive('double_exp',false);
  enterDg(150);const ok150=D&&D.dg===150&&D.mobs.length>0;exitD();
  return {ok:R.ok,checks:R.checks,errors:R.errors,warnings:R.warnings.length,xp2,ok150,flags:PSTATE}});
 console.log(JSON.stringify(R,null,1));const pass=R.ok&&R.xp2===20&&R.ok150&&!errs.length;console.log(pass?'PASS':'FAIL',errs);await b.close();process.exit(pass?0:1)})();
