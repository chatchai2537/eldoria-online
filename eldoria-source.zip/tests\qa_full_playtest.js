const {chromium}=require('playwright');const fs=require('fs');
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:900,height:520}});const errs=[];pg.on('pageerror',e=>errs.push(e.message+' '+(e.stack||'').split('\n')[1]));
await pg.goto('file://'+require('path').resolve(__dirname,'../game_built.html')+'?devtest=1');await pg.waitForTimeout(1500);
await pg.evaluate(()=>{titleEl.hidden=true;const i=document.getElementById('introName');if(i){i.value='QA';document.getElementById('introGo').click()}});await pg.waitForTimeout(1500);
pg.on('console',m=>{if(/^QA:/.test(m.text()))console.log(m.text())});
const R=await pg.evaluate(async(fl)=>{PAUSED=false;FM_ACCT='tiksi';STORY.intro=1;try{dlgClose(true)}catch(e){}return await SystemValidator.runFullGamePlaytest({floors:fl,onProgress:m=>console.log('QA: '+m)})},process.argv[2]||'sample');
fs.writeFileSync('qa_'+(process.argv[3]||'run')+'.json',JSON.stringify(R,null,1));
console.log(JSON.stringify({stats:R.stats,byModule:R.byModule,byType:R.byType}));console.log('pageerrors',errs.slice(0,10));await b.close()})();
