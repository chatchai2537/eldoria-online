
// =====================================================================
// v4.6.1 : หน้าร้าน/เตา/ทั่ง/กระเป๋า เลื่อนขึ้นกลางจอ ไม่โดนแถบลัด/แชทบัง · ถือธนูตรงกลางคันธนู · ให้ของขวัญเลือกจากกระเป๋า
// =====================================================================
{const st=document.createElement('style');st.textContent=`
#wrap #shop{top:50%!important;bottom:auto!important;left:50%!important;transform:translate(-50%,-50%)!important;transform-origin:center!important;z-index:22!important;width:min(96vw,900px);max-width:96vw!important;max-height:calc(100% - 14px)!important;overflow:auto;box-sizing:border-box;box-shadow:0 10px 40px rgba(0,0,0,.7)}
#wrap #bag{top:50%!important;left:50%!important;right:auto!important;transform:translate(-50%,-50%)!important;z-index:22!important;max-height:calc(100% - 14px)!important;max-width:96vw!important;box-sizing:border-box;box-shadow:0 10px 40px rgba(0,0,0,.7)}
#wrap.panel6 #bar,#wrap.panel6 #chatTg,#wrap.panel6 #chatBox,#wrap.panel6 #acts,#wrap.panel6 #ultb,#wrap.panel6 #qtrack,#wrap.panel6 #msg,#wrap.panel6 #bfrow,#wrap.panel6 #zb,#wrap.panel6 #tut{visibility:hidden!important}
#wrap.panel6::after{content:"";position:absolute;inset:0;background:rgba(0,0,0,.45);z-index:21;pointer-events:none}
#giftw .lst{grid-template-columns:repeat(auto-fill,minmax(78px,1fr))}
#giftw .cell{flex-direction:column;aspect-ratio:auto;padding:6px 2px 4px;gap:2px;--tc:#6a5a3a}
#giftw .cell img{width:40px;height:40px}#giftw .cell small{font-size:10.5px;opacity:.9;text-align:center;line-height:1.2;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
#giftw .cell em{left:auto;right:4px;color:#fff}
#giftw .cell.love{--tc:#ff6a9a;box-shadow:0 0 10px rgba(255,106,154,.5)}#giftw .cell.like{--tc:#ffb84a}
`;document.head.appendChild(st)}
{const shopE=gid('shop'),bagE=gid('bag'),w=gid('wrap');setInterval(()=>{const open=(shopE&&!shopE.hidden)||(bagE&&!bagE.hidden);w.classList.toggle('panel6',!!open)},120)}
// ธนูวาดใหม่: คันโค้งสมมาตร จับกลางคัน หันตามทิศยิง · ยิงแล้วง้างสายจริง
const BOWT=[['#6a4424','#a07040','#c8ccd6'],['#5a3a1e','#9a6a3a','#d8dce6'],['#6a3010','#c8743a','#ffb070'],['#3a3e4a','#c8d0dc','#ffffff'],['#5a4008','#e8b820','#fff0a0'],['#1a3a5a','#5ac8f0','#e0faff']];
function drawBow6(x,y,aim,tier,pull,arrow,sc){const C=BOWT[tier|0]||BOWT[0],t=performance.now()/1000;ctx.save();ctx.translate(x,y);ctx.rotate(aim);ctx.scale(sc||1,sc||1);ctx.lineCap='round';ctx.lineJoin='round';
 const sx=-5-pull*11;// สาย
 ctx.strokeStyle='rgba(235,230,215,.9)';ctx.lineWidth=.9;ctx.beginPath();ctx.moveTo(-5,-22);ctx.lineTo(sx,0);ctx.lineTo(-5,22);ctx.stroke();
 const limb=s=>{ctx.beginPath();ctx.moveTo(1,0);ctx.bezierCurveTo(7,s*7,6,s*17,-2,s*22);ctx.quadraticCurveTo(-4.5,s*23.5,-6,s*22.2)};
 ctx.strokeStyle='#1a1008';ctx.lineWidth=4.6;limb(-1);ctx.stroke();limb(1);ctx.stroke();ctx.strokeStyle=C[1];ctx.lineWidth=3;limb(-1);ctx.stroke();limb(1);ctx.stroke();
 ctx.strokeStyle='rgba(255,255,255,.35)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(3,-3);ctx.bezierCurveTo(7.5,-9,6.5,-16,0,-21);ctx.stroke();
 ctx.fillStyle=C[2];for(const s of [-1,1]){ctx.beginPath();ctx.arc(-5.6,s*22.3,1.6,0,7);ctx.fill()}
 ctx.fillStyle=C[0];ctx.fillRect(-1,-5,5,10);ctx.fillStyle=C[2];ctx.fillRect(-1,-5.5,5,1.4);ctx.fillRect(-1,4.1,5,1.4);
 if(tier>=3){ctx.globalCompositeOperation='lighter';const g=ctx.createRadialGradient(4,0,0,4,0,26);g.addColorStop(0,tier>=5?'rgba(120,220,255,.35)':'rgba(255,230,150,.3)');g.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=g;ctx.fillRect(-24,-28,52,56);ctx.globalCompositeOperation='source-over'}
 if(arrow){ctx.strokeStyle='#7a5a32';ctx.lineWidth=1.6;ctx.beginPath();ctx.moveTo(sx,0);ctx.lineTo(14,0);ctx.stroke();ctx.fillStyle='#d8dce8';ctx.beginPath();ctx.moveTo(19,0);ctx.lineTo(13,-2.6);ctx.lineTo(13,2.6);ctx.closePath();ctx.fill();ctx.fillStyle='#e04a3a';ctx.beginPath();ctx.moveTo(sx,0);ctx.lineTo(sx-3,-2.5);ctx.lineTo(sx+3,0);ctx.lineTo(sx-3,2.5);ctx.closePath();ctx.fill();
  if(pull>.6){ctx.globalCompositeOperation='lighter';const g=ctx.createRadialGradient(17,0,0,17,0,7);g.addColorStop(0,'rgba(255,240,180,.8)');g.addColorStop(1,'rgba(255,200,80,0)');ctx.fillStyle=g;ctx.fillRect(10,-7,14,14)}}
 ctx.restore()}
const AIM={r:0,l:Math.PI,d:Math.PI/2,u:-Math.PI/2};
{const _ts=toolSpr;toolSpr=function(hx,hy,ang){if(!(P.tool==='sword'&&isRng()&&wKind()==='bow'))return _ts(hx,hy,ang);const tier=P.tier.sword|0,at=P.at>=0&&P.at<.5,pull=at?Math.min(1,P.at/.3)*(P.at<.36?1:0):0;
  if(at){const sd=P.dir==='l'?-1:P.dir==='r'?1:0;hx+=sd*7;if(P.dir==='u')hy-=6}const aim=at?AIM[P.dir]:(P.dir==='d'?Math.PI/2+.75:P.dir==='u'?-Math.PI/2-.6:AIM[P.dir]);drawBow6(hx,hy,aim,tier,pull,at&&P.at<.36,at?1:.85);
  ctx.fillStyle='#f1d2b0';ctx.fillRect(hx-2.5,hy-2.5,5,5);P.tip={x:hx+Math.cos(aim)*16,y:hy+Math.sin(aim)*16,t:performance.now()}}}
{const _h=hero;hero=function(){_h();try{if(!window.BOW7&&!P.dead&&P.draw&&P.tool==='sword'&&isRng()&&wKind()==='bow'&&(P.dir==='l'||P.dir==='r')&&!(P.at>=0)&&!(MOUNT&&MOUNT.on)&&!P.sit){const f=P.dir==='l'?-1:1,s=P.mv?Math.sin(P.t):0;drawBow6(P.x+f*5+s*3*f,P.y-17,AIM[P.dir],P.tier.sword|0,0,false,.85);ctx.fillStyle='#f1d2b0';ctx.fillRect(P.x+f*5+s*3*f-2.5,P.y-19.5,5,5)}}catch(e){}}}
// ให้ของขวัญ: เลือกจากช่องกระเป๋า (เห็นรูปและจำนวน)
const gfW=mk6('giftw');const GF={n:null,key:null};
giftPick=function(n,key){const L=LV(key);if(L.gift===HOME.day){talk(n,'วันนี้ให้ของข้าแล้วนี่นา พรุ่งนี้ค่อยมาใหม่นะ',[BYE],ROM[key].dn);return}
 const items=INVORDER.filter(k=>inv[k]>0&&k!=='coin'&&!/^t_|^sd_|^pa_/.test(k));if(!items.length){say('ไม่มีของในกระเป๋า');return}
 GF.n=n;GF.key=key;try{dlgClose(true)}catch(e){}p6open(gfW);renderGift()};
function renderGift(){const R=ROM[GF.key],L=LV(GF.key),known=L.known||(L.known={});
 const items=INVORDER.filter(k=>inv[k]>0&&k!=='coin'&&!/^t_|^sd_|^pa_/.test(k));
 let h='<div class="w"><div class="hd"><b>🎁 เลือกของขวัญให้'+R.dn+'</b><span style="font-size:12px;opacity:.85;margin-right:6px">'+heartsTxt(L.h)+'</span><button onclick="closeGift()">✕</button></div><div class="bd"><div class="col" style="flex:1"><small>แตะของที่จะให้ · ของที่เคยให้แล้วเธอชอบจะมีกรอบสี (💗 ชอบมาก · 🧡 ชอบ) · ให้ได้วันละ 1 ชิ้น</small><div class="lst">';
 for(const k of items){const kn=known[k];let ic='';try{ic=iconURL('mat:'+k)}catch(e){}h+='<div class="cell'+(kn==='love'?' love':kn==='like'?' like':'')+'" onclick="giftGive(\''+k+'\')"><img src="'+ic+'"><small>'+(kn==='love'?'💗 ':kn==='like'?'🧡 ':'')+MN(k)+'</small><em>'+inv[k]+'</em></div>'}
 h+='</div></div></div></div>';gfW.innerHTML=h}
window.closeGift=()=>p6close(gfW);
window.giftGive=k=>{const R=ROM[GF.key],L=LV(GF.key);if(!(inv[k]>0))return;const known=L.known||(L.known={});known[k]=R.love.includes(k)?'love':R.like.includes(k)?'like':R.hate.includes(k)?'hate':'ok';p6close(gfW);giveGift(GF.n,GF.key,k)};

// เครื่องมือหันหน้า (ลูกศรลง): ยกเหนือหัว → สับพุ่งเข้าหาจอ → หัวขวาน/อีเต้อ/จอบ "ปัก" ลงดินหน้าเท้า
// [DOWN+ขวาน] มุมมองจากด้านหลังใบขวาน: ด้ามตั้งตรงลงพื้น · เห็นสัน (หลังใบ) ด้านบน · ใบเรียวลงเป็นคมที่ปลายล่าง แตะพื้น
function axeDownBack6(hx,hy,k,ground,stuck){const Q=TIERS[(P.tier&&P.tier.axe)|0]||TIERS[0],L=30*k,hb=hy+21*k;ctx.save();if(stuck){ctx.beginPath();ctx.rect(hx-30,hy-10,60,ground+1-(hy-10));ctx.clip()}
 ctx.fillStyle='#2a1a0e';ctx.fillRect(hx-2.3,hy,4.6,22*k);ctx.fillStyle=Q.gr==='#2a1e14'?'#6a4426':'#8a5a30';ctx.fillRect(hx-1.5,hy,3,22*k);ctx.fillStyle='rgba(255,230,190,.35)';ctx.fillRect(hx-1.2,hy,1,22*k);
 const top=hb-3*k,y1=hb+2*k,yE=hy+L+2*k;ctx.fillStyle=Q.dk;ctx.fillRect(hx-5.5,top,11,5*k+1);ctx.fillStyle=Q.lo;ctx.fillRect(hx-4.5,top+1,9,3*k);
 const g=ctx.createLinearGradient(hx-5,0,hx+5,0);g.addColorStop(0,Q.lo);g.addColorStop(.5,Q.hi);g.addColorStop(1,Q.mid);ctx.fillStyle=g;ctx.strokeStyle=Q.dk;ctx.lineWidth=1;
 ctx.beginPath();ctx.moveTo(hx-5,y1);ctx.lineTo(hx+5,y1);ctx.lineTo(hx+1,yE);ctx.lineTo(hx-1,yE);ctx.closePath();ctx.fill();ctx.stroke();
 ctx.fillStyle='#ffffff';ctx.fillRect(hx-1,yE-1.6,2,1.6);ctx.restore()}
// [DOWN+ที่ขุดแร่] มุมมองจากด้านหลังหัวพลั่ว: ด้ามตั้งตรงลงพื้น · หัวเหล็กเห็นเป็นแนวตั้ง ปลายแหลมล่างปักดิน ปลายบนชี้ขึ้นหลังด้าม (เหมือนหลักของขวาน)
function pickDownBack6(hx,hy,k,ground,stuck){const Q=TIERS[(P.tier&&P.tier.pick)|0]||TIERS[0],hb=hy+21*k,yE=hy+31*k+2*k;ctx.save();if(stuck){ctx.beginPath();ctx.rect(hx-30,hy-30,60,ground+1-(hy-30));ctx.clip()}
 const g=ctx.createLinearGradient(hx-3,0,hx+3,0);g.addColorStop(0,Q.lo);g.addColorStop(.5,Q.hi);g.addColorStop(1,Q.mid);
 ctx.fillStyle=g;ctx.strokeStyle=Q.dk;ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(hx-2.6,hb-2*k);ctx.lineTo(hx-.6,hb-13*k);ctx.lineTo(hx+.6,hb-13*k);ctx.lineTo(hx+2.6,hb-2*k);ctx.closePath();ctx.fill();ctx.stroke();
 ctx.fillStyle='#2a1a0e';ctx.fillRect(hx-2.3,hy,4.6,22*k);ctx.fillStyle=Q.gr==='#2a1e14'?'#6a4426':'#8a5a30';ctx.fillRect(hx-1.5,hy,3,22*k);ctx.fillStyle='rgba(255,230,190,.35)';ctx.fillRect(hx-1.2,hy,1,22*k);
 ctx.fillStyle=Q.dk;ctx.fillRect(hx-4,hb-3*k,8,5*k+1);ctx.fillStyle=Q.lo;ctx.fillRect(hx-3,hb-2*k,6,3*k);
 ctx.fillStyle=g;ctx.beginPath();ctx.moveTo(hx-3,hb+2*k);ctx.lineTo(hx+3,hb+2*k);ctx.lineTo(hx+.5,yE);ctx.lineTo(hx-.5,yE);ctx.closePath();ctx.fill();ctx.stroke();
 ctx.fillStyle='#ffffff';ctx.fillRect(hx-.8,yE-1.6,1.6,1.6);ctx.restore()}
window.CHOP6=()=>P.at>=0&&P.tool!=='sword'&&P.tool!=='rod';
{const _tw=toolSwing;toolSwing=function(x,by,d,side,f,TOP,held){if(side||d!=='d')return _tw(x,by,d,side,f,TOP,held);const p=P.at,ez=u=>u*u*u,eo=u=>1-Math.pow(1-u,3),EDGE=.4;
  let hx,hy,ang,sx,sy,rec=0;
  if(p<.38){const u=eo(p/.38);hx=x-11+12*u;hy=by-13-41*u;ang=-.5*(1-u);sx=1-(1-EDGE)*u;sy=1}
  else if(p<.46){const u=ez((p-.38)/.08);hx=x+1;hy=by-54+30*u;ang=0;sx=EDGE;sy=1-2*u}
  else if(p<.66){rec=Math.sin((p-.46)/.2*Math.PI);hx=x+1;hy=by-24+1.5*rec;ang=0;sx=EDGE;sy=-1}
  else{const u=eo((p-.66)/.34);hx=x+1-12*u;hy=by-24+11*u;ang=-.5*Math.max(0,(u-.7)/.3);sx=EDGE+(1-EDGE)*u;sy=-1+2*Math.min(1,u/.6)}
  if(Math.abs(sy)<.12)sy=sy<0?-.12:.12;
  // [แก้บั๊ก DOWN+ขวาน] ช่วง IMPACT: หมุนขวาน -90° (ไม่พลิกแนวตั้ง) ใบขวานจึงห้อยลง คมอยู่ด้านล่างแตะพื้น · มือยังจับจุดเดิมของด้าม
  let gx=null;
  // [DOWN+ขวาน ดึงกลับ] ดึงขวานขึ้นจากดิน (เห็นภาพหลังใบเต็มขนาด) แล้วเหวี่ยงกลับขึ้นไปท่าถือทางซ้าย — ไม่พลิกจนบางหาย
  if((P.tool==='axe'||P.tool==='pick')&&p>=.66){const u=eo((p-.66)/.34);if(u<.35){const w=u/.35;hx=x+1-4*w;hy=by-22-6*w;ang=0;sx=1;sy=-1}else{const v=(u-.35)/.65;hx=x-3-8*v;hy=by-28+15*v;ang=Math.PI+(Math.PI-.5)*v;sx=1;sy=1}}
  const tl=P.tool,cv=(typeof TOOLKEYS!=='undefined'&&TOOLKEYS.includes(tl))?farmTool(tl,HOME.tools[tl]|0):toolIcon(tl,(P.tier&&P.tier[tl])|0,64),ground=by+7,stuck=p>=.44&&p<.7;
  // ดินแตกเมื่อปักลง
  const dx=gx!=null?gx:hx;if(stuck){ctx.save();ctx.fillStyle='rgba(60,40,20,.55)';ctx.beginPath();ctx.ellipse(dx,ground+1,7,2.4,0,0,7);ctx.fill();ctx.strokeStyle='rgba(40,25,10,.6)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(dx-8,ground+1);ctx.lineTo(dx-12,ground+3);ctx.moveTo(dx+7,ground);ctx.lineTo(dx+12,ground+2);ctx.stroke();ctx.restore()}
  if(tl==='axe'&&sy<0)axeDownBack6(hx,hy,-sy,ground,stuck);else if(tl==='pick'&&sy<0)pickDownBack6(hx,hy,-sy,ground,stuck);else{ctx.save();if(stuck){ctx.beginPath();ctx.rect(hx-40,hy-80,80,ground-(hy-80));ctx.clip()}ctx.translate(hx,hy);ctx.rotate(ang);ctx.scale(sx,sy);if((tl==='axe'||tl==='pick')&&window.AXS7)ctx.scale(AXS7,AXS7);ctx.drawImage(cv,-23,-36,46,46);ctx.restore();}
  if(stuck){ctx.save();ctx.fillStyle='#7a5a32';ctx.beginPath();ctx.ellipse(dx,ground,5,1.8,0,Math.PI,0);ctx.fill();ctx.restore()}
  // แขนสองข้าง: ต้นแขน+ปลายแขน+มือ (ซ่อนแขนเดิมแล้ว ไม่ซ้อนเป็นสามแขน)
  const arm=(sx0,s2)=>{const shx=x+sx0,shy=by-24,ex=(shx+hx+s2*3)/2+s2*3,ey=(shy+hy)/2+(hy<by-34?-2:2);ctx.save();ctx.strokeStyle=TOP;ctx.lineCap='round';ctx.lineJoin='round';ctx.lineWidth=5.5;ctx.beginPath();ctx.moveTo(shx,shy);ctx.lineTo(ex,ey);ctx.lineTo(hx+s2*2.5,hy+1);ctx.stroke();ctx.restore()};
  arm(-8,-1);arm(8,1);ctx.fillStyle='#f1d2b0';ctx.fillRect(hx-5,hy-2,4,4);ctx.fillRect(hx+1,hy-2,4,4);
  if(p>.38&&p<.5){ctx.save();ctx.globalAlpha=.45*(1-(p-.38)/.12);ctx.strokeStyle='#fff';ctx.lineWidth=3;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(x+1,by-80);ctx.lineTo(x+1,ground);ctx.stroke();ctx.restore()}
  if(p>.44&&p<.5&&!P._chip6){P._chip6=1;try{shake(1.2,.08)}catch(e){}for(let i=0;i<9;i++)fx.push({x:hx+(Math.random()-.5)*10,y:ground,vx:(Math.random()-.5)*90,vy:-30-Math.random()*50,l:.35,c:'150,120,80'})}if(p<.4)P._chip6=0}}
// หันข้าง: ง้างไปด้านหลังเหนือไหล่ → ฟาดลงหน้าเท้า หัวเครื่องมือปักดิน · เคียว = เกี่ยวต่ำแนวนอน · บัวรดน้ำ = เอียงเทน้ำ (ไม่ฟาด)
function toolCv6(){const tl=P.tool;return (typeof TOOLKEYS!=='undefined'&&TOOLKEYS.includes(tl))?farmTool(tl,HOME.tools[tl]|0):toolIcon(tl,(P.tier&&P.tier[tl])|0,64)}
function armTo6(sx,sy,hx,hy,TOP){ctx.strokeStyle=TOP;ctx.lineCap='round';ctx.lineWidth=5.5;ctx.beginPath();ctx.moveTo(sx,sy);ctx.lineTo((sx+hx)/2,(sy+hy)/2+2);ctx.lineTo(hx,hy);ctx.stroke();ctx.fillStyle='#f1d2b0';ctx.fillRect(hx-3,hy-2.5,6,5)}
function drawTool6(hx,hy,ang,sx,sy,clipY){ctx.save();if(clipY!=null){ctx.beginPath();ctx.rect(hx-60,hy-90,120,clipY-(hy-90));ctx.clip()}ctx.translate(hx,hy);ctx.rotate(ang);ctx.scale(sx||1,sy||1);if((P.tool==='axe'||P.tool==='pick')&&window.AXS7)ctx.scale(AXS7,AXS7);if(P.dir==='r'&&sx===undefined)ctx.scale(-1,1);ctx.drawImage(toolCv6(),-23,-36,46,46);ctx.restore()}
{const _tw=toolSwing;toolSwing=function(x,by,d,side,f,TOP,held){const p=P.at,ez=u=>u*u*u,eo=u=>1-Math.pow(1-u,3),tl=P.tool;
  if(tl==='can'){const tilt=p<.25?eo(p/.25):p<.75?1:1-eo((p-.75)/.25),hx=side?x+f*9:x+(d==='d'?5:-5),hy=by-(side?16:d==='u'?24:15);
   const ang=side?f*1.15*tilt:(d==='d'?.9*tilt:-.9*tilt);armTo6(side?x:x+(d==='d'?8:-8),by-24,hx,hy,TOP);ctx.save();ctx.translate(hx,hy);ctx.rotate(ang);if(side&&f<0)ctx.scale(-1,1);ctx.drawImage(toolCv6(),-23,-30,46,46);ctx.restore();
   if(tilt>.8&&Math.random()<.9){const sp=side?[hx+f*20,hy+2]:[hx+(d==='d'?10:-10),hy+(d==='u'?-6:8)];for(let i=0;i<2;i++)rfxP(sp[0]+(Math.random()-.5)*4,sp[1],(Math.random()-.5)*10+(side?f*10:0),40+Math.random()*30,.35,'150,200,255',1.8,'drip')}return}
  if(tl==='sick'){const u=p<.15?eo(p/.15):p<.4?1:p<.5?1-ez((p-.4)/.1)*2:p<.7?-1:-1+eo((p-.7)/.3)*1;// 1=ง้าง -1=เกี่ยวผ่าน
   let hx,hy,ang;if(side){hx=x+f*(4+6*(1-u));hy=by-14+Math.abs(u)*2;ang=f*(1.9-1.1*u)}else{hx=x+(d==='d'?-10*u:10*u);hy=by-(d==='u'?20:12);ang=(d==='d'?2.2:-.9)+(-1.2*u)}
   armTo6(side?x:x+(hx<x?-8:8),by-24,hx,hy,TOP);drawTool6(hx,hy,ang,side&&f<0?-1:1,1);
   if(p>.4&&p<.5){ctx.save();ctx.globalAlpha=.4;ctx.strokeStyle='#e8ffd0';ctx.lineWidth=3;ctx.beginPath();if(side)ctx.arc(x+f*10,by-6,22,f>0?-1.2:Math.PI-0.4,f>0?.4:Math.PI+1.2);else ctx.ellipse(x,by-4,20,6,0,0,Math.PI);ctx.stroke();ctx.restore()}return}
  if(!side)return _tw(x,by,d,side,f,TOP,held);
  let hx,hy,ang;const ground=by+6;
  if(p<.38){const u=eo(p/.38);hx=x+f*(4-7*u);hy=by-15-26*u;ang=f*(-.2-1.2*u)}
  else if(p<.46){const u=ez((p-.38)/.08);hx=x+f*(-3+15*u);hy=by-41+23*u;ang=f*(-1.4+3.45*u)}
  else if(p<.66){const r=Math.sin((p-.46)/.2*Math.PI);hx=x+f*12;hy=by-18+r;ang=f*2.05}
  else{const u=eo((p-.66)/.34);hx=x+f*(12-8*u);hy=by-18+3*u;ang=f*(2.05-2.25*u)}
  const stuck=p>=.44&&p<.68;
  if(stuck){ctx.save();const gx=x+f*31;ctx.fillStyle='rgba(60,40,20,.5)';ctx.beginPath();ctx.ellipse(gx,ground+1,7,2.2,0,0,7);ctx.fill();ctx.restore()}
  drawTool6(hx,hy,ang,(P.dir==='r'?-1:1)*(P.tool==='hoe'?-1:1),1,stuck?ground:null);armTo6(x+f*1,by-24,hx,hy,TOP);
  if(stuck){ctx.fillStyle='#7a5a32';ctx.beginPath();ctx.ellipse(x+f*31,ground,5,1.6,0,Math.PI,0);ctx.fill()}
  if(p>.38&&p<.5){ctx.save();ctx.globalAlpha=.4*(1-(p-.38)/.12);ctx.strokeStyle='#fff';ctx.lineWidth=3;ctx.lineCap='round';ctx.beginPath();ctx.arc(x+f*2,by-14,32,f>0?-2.3:Math.PI-.9,f>0?.9:Math.PI+2.3);ctx.stroke();ctx.restore()}
  if(p>.44&&p<.5&&!P._chip7){P._chip7=1;for(let i=0;i<8;i++)fx.push({x:x+f*31+(Math.random()-.5)*8,y:ground,vx:(Math.random()-.5)*80+f*20,vy:-30-Math.random()*50,l:.35,c:'150,120,80'})}if(p<.4)P._chip7=0}}
// โหมดทดลอง (เบราว์เซอร์ไม่ให้เก็บข้อมูล): ปุ่มเล่นทันที ไม่ต้องสมัครไอดี
if(window.FM_NOSAVE){const _tm=tMain;tMain=function(){_tm();try{const pan=gid('tpan');if(!pan||pan.querySelector('#nsPlay'))return;
  pan.innerHTML='<div style="text-align:center;font-weight:800;margin-bottom:6px">🎮 โหมดทดลองเล่น</div><button class="tb" id="nsPlay" style="background:linear-gradient(180deg,#ffe9a0,#e8b84a);color:#3a2408;font-weight:900">▶ เล่นเลย</button><small style="display:block;text-align:center;opacity:.8;margin-top:6px;line-height:1.5">หน้านี้เก็บข้อมูลในเครื่องไม่ได้ — เล่นได้ปกติ แต่ปิดหน้าแล้วเซฟจะหาย<br>อยากเก็บเซฟ ให้เปิดลิงก์ในเบราว์เซอร์ (Chrome/Safari) หรือแอป APK</small>';
  gid('nsPlay').onclick=()=>{try{if(!P.name)P.name='ผู้กล้า';tPlay()}catch(e){titleEl.hidden=true;PAUSED=false}}}catch(e){}};
 setTimeout(()=>{try{sysSay('🎮 โหมดทดลอง: เซฟจะหายเมื่อปิดหน้า')}catch(e){}},4000)}
