// =====================================================================
// config.js — GAME_DATABASE (ข้อมูลล้วน ไม่มีตรรกะเกม)
// ★ เพิ่มมอนสเตอร์ / ชั้นดันเจี้ยน / อีเวนต์ / ร้านอีเวนต์ / ไอเท็ม = แก้แค่ไฟล์นี้ ★
//   - มอนใหม่: เพิ่มใน CUSTOM_MONSTERS (family = รูปร่างที่มีอยู่: beetle bat golem wolf wisp dragon skeleton zombie drake)
//   - ให้มอนเกิดที่ไหน: spawnIn:['iron',...] (โซน) หรือ floors:[จาก,ถึง] (ดันเจี้ยน)
//   - ดรอป: dropTableId → LOOT_TABLES
//   - อีเวนต์: เปลี่ยน active:true/false ใน EVENTS (หรือกดเปิด/ปิดในหน้า GM)
// =====================================================================
const CUSTOM_MONSTERS=[
 {id:'frost_skeleton',name:'โครงกระดูกน้ำแข็ง',family:'skeleton',colors:['#cfe8ff','#3a5a7a','#7fe0ff'],stats:{hp:1.1,atk:1.2,def:.08,speed:64},dropTableId:'endless_common',floors:[101,Infinity]},
 {id:'void_drake',name:'มังกรเล็กแห่งความว่างเปล่า',family:'drake',colors:['#4a2a6a','#1a0a2a','#ff4ad8'],stats:{hp:1.35,atk:1.3,def:.12,speed:60},dropTableId:'endless_rare',floors:[121,Infinity]},
 {id:'ev_pumpkin_golem',name:'โกเลมฟักทอง',family:'golem',colors:['#ff8a1a','#6a3008','#ffe24a'],stats:{hp:2.2,atk:1.4,def:.1,speed:38},dropTableId:'halloween',eventOnly:'halloween'},
 {id:'ev_pumpkin_king',name:'👑 ราชาฟักทองอาถรรพ์',family:'golem',colors:['#ff6a00','#3a1404','#9aff4a'],stats:{hp:9,atk:1.8,def:.2,speed:40},dropTableId:'halloween_boss',eventOnly:'halloween',seasonalBoss:true}
];
const LOOT_TABLES={
 legacy:{note:'ดรอปแบบเดิมในโค้ดเกม (ไม่เพิ่มอะไร)',rolls:[]},
 endless_common:{rolls:[{item:'estone',chance:.25,min:1,max:1},{item:'rshard',chance:.35,min:1,max:2},{item:'ingDm',chance:.15,min:1,max:1}]},
 endless_rare:{rolls:[{item:'bless',chance:.08,min:1,max:1},{item:'estone',chance:.5,min:1,max:2},{item:'rshard',chance:.6,min:2,max:3}]},
 halloween:{rolls:[{item:'candy7',chance:.6,min:1,max:3},{item:'rshard',chance:.3,min:1,max:1}]},
 halloween_boss:{rolls:[{item:'candy7',chance:1,min:10,max:20},{item:'bless',chance:.5,min:1,max:2},{item:'phoenix',chance:.3,min:1,max:1}]}
};
const DUNGEON_CONFIG={
 maxFloor:999,            // ดันเจี้ยนไม่สิ้นสุด (ปรับได้)
 bands:[                  // ช่วงชั้น → มอนที่เกิด (ใส่ id มอน)
  {from:1,to:10,name:'สุสานชั้นตื้น',monsterSpawns:['dg_skeleton','dg_zombie','dg_bat']},
  {from:11,to:30,name:'สุสานเงา',monsterSpawns:['dg_skeleton','dg_zombie','dg_wolf','dg_beetle']},
  {from:31,to:60,name:'คุกโกเลม',monsterSpawns:['dg_skeleton','dg_zombie','dg_golem','dg_wisp']},
  {from:61,to:85,name:'รังมังกร',monsterSpawns:['dg_drake','dg_golem','dg_wisp','dg_skeleton']},
  {from:86,to:100,name:'ห้วงลึก',monsterSpawns:['dg_drake','dg_skeleton','dg_wisp','dg_golem']},
  {from:101,to:Infinity,name:'ห้วงไร้สิ้นสุด',monsterSpawns:['dg_drake','dg_skeleton','dg_wisp','dg_golem','frost_skeleton','void_drake']}],
 endless:{fromFloor:101,levelCap:110,hpGrowth:.035,atkGrowth:.022,defPerFloor:.001,defCap:.45,rewardGrowth:.02}
};
const EVENTS=[
 {eventId:'double_exp',name:'EXP x2',icon:'✨',active:false,multiplier:{xp:2}},
 {eventId:'gold_rush',name:'ตื่นทอง เหรียญ x1.5',icon:'🪙',active:false,multiplier:{coin:1.5,drop:1.25}},
 {eventId:'halloween',name:'คืนฮาโลวีน',icon:'🎃',active:false,multiplier:{xp:1.2},specialSpawns:[{monsterId:'ev_pumpkin_golem',where:['zone','dungeon'],chancePerSec:.03,max:2}],seasonalBossId:'ev_pumpkin_king',seasonalBossEverySec:300,eventShopId:'shop_halloween'}
];
const SHOPS_EXTRA={
 shop_halloween:{name:'🎃 ร้านอีเวนต์ฮาโลวีน',host:'store',items:[
  {id:'ev_hw_sword',give:{item:'sword_pumpkin7'},name:'ดาบฟักทองอาถรรพ์',price:0,cost:{candy7:60},note:'อาวุธอีเวนต์ (แลกด้วยลูกอม 60)'},
  {id:'ev_hw_bless',give:{mat:'bless'},name:'หินอวยพร',price:500,cost:{candy7:15},note:'ลูกอม 15 + 500 เหรียญ'},
  {id:'ev_hw_phoenix',give:{mat:'phoenix'},name:'ขนนกฟีนิกซ์',price:0,cost:{candy7:25},note:'ลูกอม 25'}]}
};
const ITEMS_EXTRA=[
 {id:'sword_pumpkin7',base:'sword3',name:'ดาบฟักทองอาถรรพ์',stat:'ดาบอีเวนต์ฮาโลวีน (พลังเท่าดาบระดับ 3)'}
];
const MATS_EXTRA=[
 {id:'candy7',name:'ลูกอมฮาโลวีน',desc:'ดรอปจากมอนอีเวนต์ฮาโลวีน · ใช้แลกของที่ร้านอีเวนต์ (ร้านป้าแดง)',weight:.01,icon:'🍬'}
];
const SKILL_OVERRIDES={ /* ตัวอย่าง: 'mage:อัญเชิญโครงกระดูก':{cd:6} */ };

// ---------------------------------------------------------------------
// ประกอบ GAME_DATABASE: รวมข้อมูลเดิมของเกม (อ่านจากตารางที่มีอยู่) + ข้อมูลเพิ่มด้านบน
// ---------------------------------------------------------------------
const GAME_DATABASE=(()=>{const DB={MonstersData:[],LootTables:LOOT_TABLES,DungeonsData:DUNGEON_CONFIG,EventsData:EVENTS,ShopsData:SHOPS_EXTRA,ItemsExtra:ITEMS_EXTRA,MatsExtra:MATS_EXTRA,SkillOverrides:SKILL_OVERRIDES,ZoneSpawns:{},_byId:{},_byKey:{}};
 const famStats=f=>{const F=FAM[f]||{};return {hp:F.hp||1,atk:F.atk||1,def:0,speed:F.spd||50}};
 const add=m=>{if(!m||!m.id)return;m.stats=Object.assign(famStats(m.family),m.stats||{});m.dropTableId=m.dropTableId||'legacy';DB.MonstersData.push(m);DB._byId[m.id]=m;DB._byKey[m.family+'|'+m.name]=DB._byKey[m.family+'|'+m.name]||m};
 // มอนในโซน (ของเดิม)
 try{ZONES.forEach((Z,i)=>{if(!Z||Z.dg||i>=200)return;DB.ZoneSpawns[Z.id]=[];for(const [f,nm,col] of Z.mobs){const id=Z.id+'_'+f;add({id,name:nm,family:f,colors:col,legacy:true,spawnIn:[Z.id]});DB.ZoneSpawns[Z.id].push(id)}
  if(Z.boss)add({id:Z.id+'_boss',name:Z.boss.n,family:Z.boss.f,colors:Z.boss.c,boss:true,legacy:true,spawnIn:[Z.id]})})}catch(e){console.warn('[DB] zones',e)}
 // มอนดันเจี้ยน (ของเดิม — สีเปลี่ยนตามช่วงชั้น)
 try{for(const f in DGNAME)add({id:'dg_'+f,name:DGNAME[f],family:f,colors:'band',legacy:true})}catch(e){console.warn('[DB] dg',e)}
 // มอนเพิ่มเติม
 for(const m of CUSTOM_MONSTERS)add(Object.assign({},m));
 DB.monster=id=>DB._byId[id]||null;DB.monsterByKey=(f,n)=>DB._byKey[f+'|'+n]||null;
 DB.band=f=>DUNGEON_CONFIG.bands.find(b=>f>=b.from&&f<=b.to)||DUNGEON_CONFIG.bands[DUNGEON_CONFIG.bands.length-1];
 DB.event=id=>EVENTS.find(e=>e.eventId===id)||null;
 return DB})();
window.GAME_DATABASE=GAME_DATABASE;

// ลงทะเบียนวัตถุดิบ/ไอเท็มเพิ่มเติมเข้าเกม
try{for(const M of MATS_EXTRA){if(inv[M.id]===undefined)inv[M.id]=0;WT[M.id]=M.weight||.05;INVMETA[M.id]=[M.name,M.desc||''];if(!INVORDER.includes(M.id))INVORDER.push(M.id)}
 const _mi=matIcon;matIcon=function(key){const M=MATS_EXTRA.find(q=>q.id===key);if(!M)return _mi(key);const c=document.createElement('canvas');c.width=c.height=48;const k=c.getContext('2d');k.font='32px "Noto Color Emoji","Apple Color Emoji",sans-serif';k.textAlign='center';k.textBaseline='middle';k.fillText(M.icon||'📦',24,26);return c};
 for(const M of MATS_EXTRA){const im=new Image();im.src=iconURL('mat:'+M.id);DROPIMG[M.id]=im}}catch(e){console.warn('[DB] mats',e)}
try{for(const X of ITEMS_EXTRA){const B=ITEMS[X.base];if(!B||ITEMS[X.id])continue;ITEMS[X.id]=Object.assign({},B,{name:X.name,stat:X.stat||B.stat,extra7:1});if(typeof GEAR==='object'&&GEAR[X.id]===undefined){}}
 const Q=window.__PEND8;if(Q){window.__PEND8=null;for(const k in Q.a)if(ITEMS[Q.a[k]])P.armor[k]=Q.a[k];for(const id in Q.g)if(ITEMS[id])GEAR[id]=Q.g[id];try{syncSword();recalcStats();refreshInv()}catch(e){}}}catch(e){console.warn('[DB] items',e)}
try{for(const key in SKILL_OVERRIDES){const [c,n]=key.split(':'),S=(CSKILLS[c]||[]).find(s=>s.n===n);if(S)Object.assign(S,SKILL_OVERRIDES[key])}}catch(e){}
// อ้างอิงตารางเดิม (อ่านอย่างเดียว) ให้อยู่ใน GAME_DATABASE ด้วย
Object.defineProperty(GAME_DATABASE,'ItemsData',{get(){return ITEMS}});Object.defineProperty(GAME_DATABASE,'SkillsData',{get(){return CSKILLS}});
Object.defineProperty(GAME_DATABASE,'ZonesData',{get(){return ZONES.filter((z,i)=>z&&i<200&&!z.dg)}});
