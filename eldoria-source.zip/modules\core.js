// =====================================================================
// core.js — แกนกลางสถาปัตยกรรม v4.8
// EventBus · Hooks (ตัวกรองค่า) · Guard (try/catch/finally) · สถานะผู้เล่น · LoadingScreenManager · Eldoria (ทางเข้ารวมของทุกโมดูล)
// โมดูลใหม่คุยกันผ่าน EventBus เท่านั้น — ระบบเดิม (legacy) ถูกห่อให้ "ส่งเหตุการณ์" ออกมา
// =====================================================================
const EventBus=(()=>{const L={},stats={emit:0,err:0};
 function on(ev,fn,owner){(L[ev]=L[ev]||[]).push({fn,owner:owner||'?'});return ()=>off(ev,fn)}
 function off(ev,fn){const a=L[ev];if(!a)return;const i=a.findIndex(q=>q.fn===fn);if(i>=0)a.splice(i,1)}
 function once(ev,fn,owner){const u=on(ev,function(d){u();fn(d)},owner);return u}
 function emit(ev,data){stats.emit++;const a=L[ev];if(!a||!a.length)return 0;let n=0;for(const q of a.slice()){try{q.fn(data);n++}catch(e){stats.err++;console.warn('[EventBus] '+ev+' @'+q.owner,e)}}return n}
 function count(ev){return ev?(L[ev]||[]).length:Object.values(L).reduce((s,a)=>s+a.length,0)}
 return {on,off,once,emit,count,events:()=>Object.keys(L),stats}})();
window.EventBus=EventBus;
// รายชื่อเหตุการณ์มาตรฐาน (ใช้ชื่อเดียวกันทุกโมดูล)
const EV=Object.freeze({MONSTER_SPAWNED:'MONSTER_SPAWNED',MONSTER_DIED:'MONSTER_DIED',BOSS_DIED:'BOSS_DIED',XP_GAINED:'XP_GAINED',LEVEL_UP:'LEVEL_UP',
 ITEM_EQUIPPED:'ITEM_EQUIPPED',SKILL_CAST:'SKILL_CAST',SKILL_FAILED:'SKILL_FAILED',SCENE_CHANGED:'SCENE_CHANGED',DUNGEON_FLOOR_ENTER:'DUNGEON_FLOOR_ENTER',
 DUNGEON_FLOOR_CLEARED:'DUNGEON_FLOOR_CLEARED',QUEST_CLAIMED:'QUEST_CLAIMED',UI_OPEN:'UI_OPEN',UI_CLOSE:'UI_CLOSE',EVENT_STARTED:'EVENT_STARTED',EVENT_ENDED:'EVENT_ENDED',
 LOOT_DROPPED:'LOOT_DROPPED',ERROR:'ERROR',VALIDATED:'VALIDATED'});
window.EV=EV;

// Hooks: ตัวกรองค่าแบบลำดับ (เช่น xp → อีเวนต์ EXP x2 คูณเพิ่ม) — ไม่ต้องแก้โค้ดระบบอื่น
const Hooks=(()=>{const F={};return {add(name,fn,owner){(F[name]=F[name]||[]).push({fn,owner});},
 apply(name,v,ctx){const a=F[name];if(!a)return v;for(const q of a){try{const r=q.fn(v,ctx);if(r!==undefined&&r!==null&&!(typeof r==='number'&&!isFinite(r)))v=r}catch(e){console.warn('[Hooks] '+name,e)}}return v},
 count:n=>(F[n]||[]).length}})();
window.Hooks=Hooks;

// สถานะผู้เล่นที่ต้องรีเซ็ตเสมอ
const PSTATE={isCasting:false,isInteracting:false,isEquipping:false,inTransition:false,lastError:null};
window.PSTATE=PSTATE;
// Guard: ห่อทุกการกระทำ — ถ้าพัง แจ้งเหตุการณ์ ERROR และคืนสถานะใน finally เสมอ
const Guard={run(tag,fn,flag,onErr){if(flag)PSTATE[flag]=true;try{return fn()}catch(e){PSTATE.lastError={tag,msg:String(e&&e.message||e),t:Date.now()};console.warn('[Guard] '+tag,e);try{EventBus.emit(EV.ERROR,{tag,error:e})}catch(_){}if(onErr)try{onErr(e)}catch(_){}return undefined}
  finally{if(flag)PSTATE[flag]=false}},
 wrap(tag,fn,flag,onErr){return function(){const a=arguments,self=this;return Guard.run(tag,()=>fn.apply(self,a),flag,onErr)}}};
window.Guard=Guard;

// LoadingScreenManager: หน้าโหลดแบบเฟดเข้า/ออก ตอนเปลี่ยนฉาก/ชั้นดันเจี้ยน
const LoadingScreenManager=(()=>{const el=document.createElement('div');el.id='lsm7';el.innerHTML='<div class="c"><div class="ic"></div><b></b><small></small><div class="bar"><i></i></div></div>';
 const st=document.createElement('style');st.textContent=`#lsm7{position:absolute;inset:0;z-index:80;display:none;align-items:center;justify-content:center;background:radial-gradient(circle at 50% 45%,#2a1f3a,#07050c);opacity:0;transition:opacity .28s ease;pointer-events:none}
#lsm7.on{display:flex}#lsm7.v{opacity:1;pointer-events:auto}#lsm7 .c{text-align:center;color:#ffe9c0;font-family:inherit;min-width:220px}#lsm7 .ic{font-size:40px;filter:drop-shadow(0 0 10px rgba(255,220,140,.6));animation:lsm7b 1.2s ease-in-out infinite}
#lsm7 b{display:block;font:900 20px Georgia,serif;letter-spacing:1px;margin:6px 0 2px;text-shadow:0 2px 0 #000}#lsm7 small{display:block;opacity:.75;font-size:12px}
#lsm7 .bar{margin:12px auto 0;width:200px;height:6px;border-radius:4px;background:rgba(255,255,255,.12);overflow:hidden}#lsm7 .bar i{display:block;height:100%;width:0;background:linear-gradient(90deg,#e8c14a,#fff2c0);transition:width .5s ease}
@keyframes lsm7b{50%{transform:translateY(-5px)}}`;document.head.appendChild(st);
 let busy=false,tmr=null;const wrap=()=>document.getElementById('wrap')||document.body;
 function set(o){el.querySelector('.ic').textContent=o.icon||'🌀';el.querySelector('b').textContent=o.title||'กำลังโหลด…';el.querySelector('small').textContent=o.tip||''}
 function attach(){if(!el.parentNode)wrap().appendChild(el)}
 // แบบซิงก์: ปิดจอทันที → เปลี่ยนฉาก → เฟดออก (ใช้กับระบบเดิมที่ต้องเปลี่ยนฉากทันที)
 function cover(o,fn){attach();set(o||{});clearTimeout(tmr);el.classList.add('on','v');el.style.transition='none';void el.offsetWidth;el.style.transition='';const bar=el.querySelector('.bar i');bar.style.width='35%';
  let r;PSTATE.inTransition=true;try{r=fn&&fn()}catch(e){console.warn('[LSM]',e)}finally{PSTATE.inTransition=false;requestAnimationFrame(()=>{bar.style.width='100%'});tmr=setTimeout(hide,o&&o.hold||420)}return r}
 // แบบอะซิงก์: เฟดเข้า → เปลี่ยนฉาก → เฟดออก (ใช้กับปุ่มที่ผู้เล่นกด)
 function go(o,fn){if(busy)return false;busy=true;attach();set(o||{});clearTimeout(tmr);const bar=el.querySelector('.bar i');bar.style.width='0';el.classList.add('on');void el.offsetWidth;el.classList.add('v');PSTATE.inTransition=true;
  setTimeout(()=>{bar.style.width='60%';try{fn&&fn()}catch(e){console.warn('[LSM]',e)}finally{PSTATE.inTransition=false;bar.style.width='100%';tmr=setTimeout(()=>{hide();busy=false},o&&o.hold||380)}},300);return true}
 function hide(){el.classList.remove('v');setTimeout(()=>{if(!el.classList.contains('v'))el.classList.remove('on')},300)}
 return {cover,go,hide,el,isBusy:()=>busy}})();
window.LoadingScreenManager=LoadingScreenManager;window.LSM=LoadingScreenManager;

// Eldoria: ทางเข้ารวม (facade) — เรียกระบบเดิมผ่านชื่อโมดูล โดยอ้างฟังก์ชันล่าสุดเสมอ
const Eldoria={version:'4.8.0',modules:{},register(name,api){this.modules[name]=Object.assign(this.modules[name]||{},api);return this.modules[name]}};
window.Eldoria=Eldoria;
// ตารางโมดูล → ฟังก์ชันระบบเดิมที่อยู่ในความรับผิดชอบ (ใช้ค้นหา/ตรวจสอบ)
const MOD7={
 core:{frame:()=>(typeof frame!=='undefined'?frame:undefined),playerTick:()=>(typeof playerTick!=='undefined'?playerTick:undefined),setScene:()=>(typeof setScene!=='undefined'?setScene:undefined),fade:()=>(typeof fade!=='undefined'?fade:undefined),sfx:()=>(typeof sfx!=='undefined'?sfx:undefined),tone:()=>(typeof tone!=='undefined'?tone:undefined),say:()=>(typeof say!=='undefined'?say:undefined),sysSay:()=>(typeof sysSay!=='undefined'?sysSay:undefined),saveGame:()=>(typeof saveGame!=='undefined'?saveGame:undefined),loadGame:()=>(typeof loadGame!=='undefined'?loadGame:undefined)},
 player:{gainXp:()=>(typeof gainXp!=='undefined'?gainXp:undefined),need:()=>(typeof need!=='undefined'?need:undefined),recalcStats:()=>(typeof recalcStats!=='undefined'?recalcStats:undefined),applyBonus:()=>(typeof applyBonus!=='undefined'?applyBonus:undefined),calcBonus:()=>(typeof calcBonus!=='undefined'?calcBonus:undefined),equipItem:()=>(typeof equipItem!=='undefined'?equipItem:undefined),unequip:()=>(typeof unequip!=='undefined'?unequip:undefined),refreshInv:()=>(typeof refreshInv!=='undefined'?refreshInv:undefined),canTake:()=>(typeof canTake!=='undefined'?canTake:undefined),pickClass:()=>(typeof pickClass!=='undefined'?pickClass:undefined),statAdd:()=>(typeof statAdd!=='undefined'?statAdd:undefined)},
 skills:{useSkill:()=>(typeof useSkill!=='undefined'?useSkill:undefined),castUlt:()=>(typeof castUlt!=='undefined'?castUlt:undefined),ultTick:()=>(typeof ultTick!=='undefined'?ultTick:undefined),summon:()=>(typeof summon!=='undefined'?summon:undefined),minTick:()=>(typeof minTick!=='undefined'?minTick:undefined),flkStep:()=>(typeof flkStep!=='undefined'?flkStep:undefined),healSk:()=>(typeof healSk!=='undefined'?healSk:undefined),hurtE:()=>(typeof hurtE!=='undefined'?hurtE:undefined),eachIn:()=>(typeof eachIn!=='undefined'?eachIn:undefined)},
 monsters:{mkMob:()=>(typeof mkMob!=='undefined'?mkMob:undefined),mobStats:()=>(typeof mobStats!=='undefined'?mobStats:undefined),spawnMob:()=>(typeof spawnMob!=='undefined'?spawnMob:undefined),spawnBoss:()=>(typeof spawnBoss!=='undefined'?spawnBoss:undefined),mobKill:()=>(typeof mobKill!=='undefined'?mobKill:undefined),updMob:()=>(typeof updMob!=='undefined'?updMob:undefined),mvM:()=>(typeof mvM!=='undefined'?mvM:undefined),dropLoot:()=>(typeof dropLoot!=='undefined'?dropLoot:undefined),addDrop:()=>(typeof addDrop!=='undefined'?addDrop:undefined)},
 dungeons:{enterDg:()=>(typeof enterDg!=='undefined'?enterDg:undefined),genDungeon:()=>(typeof genDungeon!=='undefined'?genDungeon:undefined),dgPacks:()=>(typeof dgPacks!=='undefined'?dgPacks:undefined),dgBoss:()=>(typeof dgBoss!=='undefined'?dgBoss:undefined),dgPool:()=>(typeof dgPool!=='undefined'?dgPool:undefined),dgReward:()=>(typeof dgReward!=='undefined'?dgReward:undefined),openChest_:()=>(typeof openChest_!=='undefined'?openChest_:undefined),enterZone:()=>(typeof enterZone!=='undefined'?enterZone:undefined),genZone:()=>(typeof genZone!=='undefined'?genZone:undefined),exitD:()=>(typeof exitD!=='undefined'?exitD:undefined)},
 events:{},
 ui:{openShop:()=>(typeof openShop!=='undefined'?openShop:undefined),closeShop:()=>(typeof closeShop!=='undefined'?closeShop:undefined),renderShop:()=>(typeof renderShop!=='undefined'?renderShop:undefined),openForge:()=>(typeof openForge!=='undefined'?openForge:undefined),closeForge:()=>(typeof closeForge!=='undefined'?closeForge:undefined),openChar:()=>(typeof openChar!=='undefined'?openChar:undefined),renderChar:()=>(typeof renderChar!=='undefined'?renderChar:undefined),talk:()=>(typeof talk!=='undefined'?talk:undefined),dlgClose:()=>(typeof dlgClose!=='undefined'?dlgClose:undefined),openGuild:()=>(typeof openGuild!=='undefined'?openGuild:undefined),openClassMenu:()=>(typeof openClassMenu!=='undefined'?openClassMenu:undefined),icShow:()=>(typeof icShow!=='undefined'?icShow:undefined),icClose:()=>(typeof icClose!=='undefined'?icClose:undefined),updTrack:()=>(typeof updTrack!=='undefined'?updTrack:undefined)}};
window.MOD7=MOD7;
for(const m in MOD7){const api={};for(const fn in MOD7[m])Object.defineProperty(api,fn,{enumerable:true,get(){try{return MOD7[m][fn]()}catch(e){return undefined}}});Eldoria.register(m,api)}
