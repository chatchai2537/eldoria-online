
// =====================================================================
// v4.6 (ข) : เครื่องประดับสัตว์เลี้ยง (ปลอกคอ/กระพรวน/แหวน 3 ขั้น · รีค่า+ล็อก · ทะลวง)
//            ร้านแฟชั่น (ชุด+อาวุธ) · ช่างตีเหล็กใหม่ (ตำราปลดล็อกชุด · เดินไปเตาเอง) · แท่นค้นหาของหาย · ประตูแบบภาพตัด · ป้ายร้านดาบใหม่
// =====================================================================
{const st=document.createElement('style');st.textContent=`
.p6w{position:absolute;inset:0;z-index:30;display:flex;align-items:center;justify-content:center;background:rgba(6,4,10,.6)}
.p6w[hidden]{display:none}
.p6w .w{width:min(860px,97%);height:min(540px,95%);display:flex;flex-direction:column;border-radius:16px;overflow:hidden;color:#f3eefc;background:linear-gradient(180deg,#221a34,#141020);border:2px solid #e8c14a;box-shadow:0 0 0 3px #120c06,0 14px 40px rgba(0,0,0,.7);font-family:system-ui,"Noto Sans Thai",sans-serif}
.p6w .hd{display:flex;align-items:center;gap:6px;padding:8px 10px;background:linear-gradient(180deg,#3a2c54,#2a2040);border-bottom:1px solid rgba(232,193,74,.4)}
.p6w .hd b{margin-right:auto;font-size:15px;color:#ffe9a0}
.p6w .hd button,.p6w .bt{font:inherit;font-weight:800;font-size:12.5px;padding:6px 10px;border-radius:9px;border:1px solid #c8a24a;background:#3a2c18;color:#ffe9c0;cursor:pointer}
.p6w .hd button.on{background:#ffe9a0;color:#3a2408}
.p6w .bt.g{background:linear-gradient(180deg,#5aa04a,#3a7a2a);border-color:#8ad07a;color:#fff}.p6w .bt.r{background:linear-gradient(180deg,#c0503a,#8a2a1a);border-color:#ff9a7a;color:#fff}
.p6w .bt:disabled{opacity:.45;cursor:default}
.p6w .bd{flex:1;min-height:0;display:flex;gap:10px;padding:10px}
.p6w .col{display:flex;flex-direction:column;gap:8px;min-height:0}
.p6w .lst{flex:1;overflow-y:auto;display:grid;grid-template-columns:repeat(auto-fill,minmax(64px,1fr));gap:6px;align-content:start;padding:2px}
.p6w .cell{position:relative;aspect-ratio:1;border-radius:10px;background:rgba(255,255,255,.06);border:2px solid var(--tc,#555);cursor:pointer;display:flex;align-items:center;justify-content:center}
.p6w .cell img{width:80%;height:80%}.p6w .cell.sel{box-shadow:0 0 0 2px #fff,0 0 12px var(--tc)}.p6w .cell em{position:absolute;left:3px;top:1px;font:900 10px system-ui;font-style:normal;color:var(--tc);text-shadow:0 1px 1px #000}
.p6w .cell.eq::after{content:"E";position:absolute;right:3px;bottom:1px;font:900 10px system-ui;color:#8fe08a}
.p6w .card{padding:9px;border-radius:12px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1)}
.p6w .ln{display:flex;align-items:center;gap:6px;padding:5px 7px;margin:3px 0;border-radius:8px;background:rgba(0,0,0,.3);font-size:12.5px}
.p6w .ln b{margin-left:auto;color:#ffe9a0}.p6w .ln .lk{width:26px;height:24px;padding:0;border-radius:7px;border:1px solid #777;background:#222;cursor:pointer;font-size:13px}.p6w .ln .lk.on{background:#c89a2a;border-color:#ffe9a0}
.p6w small{opacity:.75;font-size:11.5px;line-height:1.4}
.p6w .slots{display:flex;gap:8px;justify-content:center}.p6w .slot{width:62px;height:62px;border-radius:12px;border:2px dashed rgba(255,255,255,.25);display:flex;align-items:center;justify-content:center;position:relative;cursor:pointer;background:rgba(0,0,0,.25)}
.p6w .slot img{width:52px;height:52px}.p6w .slot span{position:absolute;bottom:-15px;font-size:10px;opacity:.7;white-space:nowrap}
.p6w .fit{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px;overflow-y:auto;flex:1;align-content:start}
.p6w .fit .it{display:flex;flex-direction:column;gap:5px;padding:8px;border-radius:12px;background:rgba(255,255,255,.05);border:1.5px solid rgba(255,255,255,.12)}
.p6w .fit .it.own{border-color:#8fe08a}.p6w .fit .it.wear{border-color:#ffe9a0;box-shadow:0 0 10px rgba(255,233,160,.35)}
.p6w .fit .it canvas,.p6w .fit .it img{width:100%;height:96px;object-fit:contain;border-radius:9px;background:radial-gradient(circle at 50% 60%,#4a3a6a,#1a1428)}
#cut6{position:absolute;inset:0;z-index:40;pointer-events:none;background:#000;opacity:0;backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px)}
.p6w .bd>.col{overflow-y:auto}.p6w .lst{min-height:76px}
#pa6pv canvas{display:block;margin:0 auto;width:auto;max-width:100%;height:auto;max-height:120px;border-radius:10px}
@media (max-height:440px){#pa6pv canvas{max-height:64px}.p6w .card{padding:6px}.p6w .ln{padding:3px 6px;margin:2px 0;font-size:11.5px}.p6w .bd{padding:6px;gap:6px}.p6w .slot{width:50px;height:50px}.p6w .slot img{width:42px;height:42px}.p6w .fit .it canvas,.p6w .fit .it img{height:70px}}
`;document.head.appendChild(st)}
const mk6=(id)=>{const e=document.createElement('div');e.id=id;e.className='p6w';e.hidden=true;gid('wrap').appendChild(e);e.addEventListener('pointerdown',ev=>ev.stopPropagation());return e};
function p6open(el){el.hidden=false;PAUSED=true;sfx('ui')}
function p6close(el){el.hidden=true;PAUSED=false;sfx('ui')}

// =====================================================================
// 1) เครื่องประดับสัตว์เลี้ยง
// =====================================================================
const PA={items:[],eq:{collar:null,bell:null,ring:null},n:1};
try{Object.assign(PA,JSON.parse(localStorage.getItem('fm_pacc')||'{}'))}catch(e){}
function savePA(){try{localStorage.setItem('fm_pacc',JSON.stringify(PA))}catch(e){}}
const PAK={collar:{n:'ปลอกคอ',e:'⭕'},bell:{n:'กระพรวน',e:'🔔'},ring:{n:'แหวนสัตว์เลี้ยง',e:'💍'}};
const PAT=[null,{n:'ขั้น 1',c:'#5ad06a',lines:1},{n:'ขั้น 2',c:'#b06aff',lines:2},{n:'ขั้น 3',c:'#ff3a3a',lines:3}];
const PAS={crit:{n:'โอกาสคริติคอล',r:[1,3,5],u:'%'},cdmg:{n:'ความเสียหายหนักหน่วง (คริ)',r:[3,7,14],u:'%'},cres:{n:'ลดโอกาสโดนคริ',r:[2,5,9],u:'%'},dr:{n:'ลดความเสียหายที่ได้รับ',r:[1,3,6],u:'%'},pen:{n:'เจาะทะลุ (บอส/อีลิท)',r:[2,5,10],u:'%'},dmg:{n:'โบนัสความเสียหาย',r:[1,3,6],u:'%'}};
const PAKEYS=Object.keys(PAS);
function paRoll(t,not){const L=PAKEYS.filter(k=>!(not||[]).includes(k)),s=L[Math.random()*L.length|0],[a,b,c]=PAS[s].r,hi=[0,a,b,c][t],lo=[0,1,a,b][t];return{s,v:+(lo+Math.random()*(hi-lo)).toFixed(1),lk:0}}
function paNew(k,t){const it={u:PA.n++,k,t,l:[]};for(let i=0;i<PAT[t].lines;i++)it.l.push(paRoll(t,it.l.map(q=>q.s)));PA.items.push(it);savePA();return it}
// ดรอปเป็นของในกระเป๋าก่อน แล้วแปลงเป็นชิ้นที่สุ่มค่า
for(const k in PAK)for(const t of [1,2]){const id='pa_'+k+'_'+t;INVMETA[id]=[PAK[k].n+' '+PAT[t].n,'เครื่องประดับสัตว์เลี้ยง — สุ่มค่าเมื่อเก็บ · ใส่ที่หน้าต่าง 🐾'];WT[id]=.1;if(inv[id]===undefined)inv[id]=0}
function paIconCv(k,t){const key='pa'+k+t;if(ICN6[key+'cv'])return ICN6[key+'cv'];const c=document.createElement('canvas');c.width=c.height=64;const q=c.getContext('2d'),col=PAT[t].c,mt=['','#c8ccd6','#e8c14a','#ff5a4a'][t];q.lineCap='round';q.lineJoin='round';
 const g=q.createRadialGradient(32,30,2,32,32,30);g.addColorStop(0,col+'66');g.addColorStop(1,'rgba(0,0,0,0)');q.fillStyle=g;q.fillRect(0,0,64,64);
 if(k==='collar'){q.strokeStyle='#3a1a0a';q.lineWidth=11;q.beginPath();q.ellipse(32,30,20,14,0,0,7);q.stroke();q.strokeStyle=t===3?'#8a1010':t===2?'#5a2a8a':'#8a4a1a';q.lineWidth=8;q.stroke();q.fillStyle=mt;for(let i=0;i<8;i++){const a=i*.785;q.beginPath();q.arc(32+Math.cos(a)*20,30+Math.sin(a)*14,1.8,0,7);q.fill()}
  q.fillStyle=mt;q.strokeStyle='#1a1a1a';q.lineWidth=1.5;q.beginPath();q.moveTo(32,42);q.lineTo(38,48);q.lineTo(32,56);q.lineTo(26,48);q.closePath();q.fill();q.stroke()}
 else if(k==='bell'){q.strokeStyle='#8a1a1a';q.lineWidth=4;q.beginPath();q.arc(32,14,7,Math.PI,0);q.stroke();const bg=q.createRadialGradient(26,28,2,32,34,20);bg.addColorStop(0,'#fff8d0');bg.addColorStop(.4,mt);bg.addColorStop(1,'#4a3008');q.fillStyle=bg;q.strokeStyle='#2a1a04';q.lineWidth=2;q.beginPath();q.arc(32,34,17,0,7);q.fill();q.stroke();
  q.strokeStyle='#2a1a04';q.lineWidth=2;q.beginPath();q.moveTo(17,34);q.lineTo(47,34);q.stroke();q.fillStyle='#1a1004';q.beginPath();q.arc(32,41,3.5,0,7);q.fill();q.fillRect(31,41,2,7)}
 else{q.strokeStyle='#1a1a1a';q.lineWidth=9;q.beginPath();q.ellipse(32,38,16,13,0,0,7);q.stroke();const rg=q.createLinearGradient(16,26,48,50);rg.addColorStop(0,'#fff');rg.addColorStop(.4,mt);rg.addColorStop(1,'#3a2a08');q.strokeStyle=rg;q.lineWidth=6;q.stroke();
  const gc=t===3?'#ff3a5a':t===2?'#b06aff':'#5ad06a';q.fillStyle=gc;q.strokeStyle='#fff';q.lineWidth=1.5;q.beginPath();q.moveTo(32,12);q.lineTo(41,22);q.lineTo(32,30);q.lineTo(23,22);q.closePath();q.fill();q.stroke();q.fillStyle='rgba(255,255,255,.7)';q.fillRect(29,17,3,3)}
 if(t===3){q.globalCompositeOperation='lighter';const gg=q.createRadialGradient(32,32,0,32,32,32);gg.addColorStop(0,'rgba(255,80,60,.35)');gg.addColorStop(1,'rgba(255,80,60,0)');q.fillStyle=gg;q.fillRect(0,0,64,64)}
 return ICN6[key+'cv']=c}
const paIcon=(k,t)=>{const key='pau'+k+t;return ICN6[key]||(ICN6[key]=paIconCv(k,t).toDataURL())};
{const _mi=matIcon;matIcon=function(key){const m=/^pa_(\w+)_(\d)$/.exec(key);if(m&&PAK[m[1]]){const c=document.createElement('canvas');c.width=c.height=48;c.getContext('2d').drawImage(paIconCv(m[1],+m[2]),0,0,48,48);return c}return _mi(key)}}
{const _ri=refreshInv;refreshInv=function(){for(const k in PAK)for(const t of [1,2]){const id='pa_'+k+'_'+t;while(inv[id]>0){inv[id]--;const it=paNew(k,t);setTimeout(()=>{sysSay('🐾 ได้'+PAK[k].n+' '+PAT[t].n+' — '+it.l.map(paLineTxt).join(' · '));try{banner('🐾 เครื่องประดับสัตว์เลี้ยง!',PAK[k].n+' '+PAT[t].n,'')}catch(e){}},300)}}return _ri.apply(this,arguments)}}
// ดรอปจากมอน
{const _mk=mobKill;mobKill=function(m){_mk(m);const dg=D&&D.dg?D.dg:0,p=m.boss?.3:m.elite?.05:.006+dg/12000;if(Math.random()<p){const ks=Object.keys(PAK),k=ks[Math.random()*3|0],t=(m.boss&&dg>=50&&Math.random()<.3)||(m.boss&&m.abyss)?2:1;addDrop('pa_'+k+'_'+t,m.x,m.y)}}}
{const _dl=dropLoot;dropLoot=function(x,y,s){_dl(x,y,s);if(Math.random()<.002){const ks=Object.keys(PAK);addDrop('pa_'+ks[Math.random()*3|0]+'_1',x,y)}}}
try{for(const k in PAK)for(const t of [1,2]){DROPIMG&&(DROPIMG['pa_'+k+'_'+t]=DROPIMG['pa_'+k+'_'+t]||null)}}catch(e){}
function paLineTxt(l){return PAS[l.s].n+' +'+l.v+PAS[l.s].u}
const PAX=()=>{const o={crit:0,cdmg:0,cres:0,dr:0,pen:0,dmg:0};if(!HOME.pet)return o;for(const s in PA.eq){const it=PA.items.find(q=>q.u===PA.eq[s]);if(it)for(const l of it.l)o[l.s]+=l.v/100}return o};
window.CRITD=()=>PAX().cdmg;
{const _c=critCh;critCh=function(){return _c()+PAX().crit}}
{const _h=hurtE;hurtE=function(e,mult,o){const x=PAX();return _h(e,mult*(1+x.dmg+((e&&(e.boss||e.elite))?x.pen:0)),o)}}
{const _z=zHurt;zHurt=function(src,dmg,kbm,msg){const x=PAX();let d=dmg*(1-Math.min(.5,x.dr));const cc=Math.max(0,.07-x.cres);if(src&&(src.F||src.boss)&&Math.random()<cc){d*=1.5;try{dmgTxt(P.x,P.y-52,'คริ!','#ff4a4a',true)}catch(e){}}return _z(src,d,kbm,msg)}}
// วาดบนตัวสัตว์เลี้ยง
{const _dp=drawPet;drawPet=function(p,x,y){_dp(p,x,y);const c=PA.items.find(q=>q.u===PA.eq.collar),b=PA.items.find(q=>q.u===PA.eq.bell),r=PA.items.find(q=>q.u===PA.eq.ring);if(!c&&!b&&!r)return;
  const t=performance.now()/1000,mv=PET.mv&&x===PET.x,bb=mv?Math.abs(Math.sin(t*12))*2:0;ctx.save();ctx.translate(x,y-bb);if(x===PET.x)ctx.scale(PET.f,1);
  if(c){ctx.fillStyle=['','#8a4a1a','#7a3ab0','#c01a1a'][c.t];ctx.fillRect(4,-9.5,7,2.4);ctx.fillStyle=['','#c8ccd6','#e8c14a','#ffd23a'][c.t];ctx.fillRect(6,-8,1.5,1.5);ctx.fillRect(9,-8,1.5,1.5)}
  if(b){const sw=Math.sin(t*(mv?14:3))*.5;ctx.save();ctx.translate(7.5,-7);ctx.rotate(sw);ctx.fillStyle=['','#c8ccd6','#e8c14a','#ffd060'][b.t];ctx.beginPath();ctx.arc(0,2.5,2.4,0,7);ctx.fill();ctx.fillStyle='#2a1a04';ctx.fillRect(-.5,3.5,1,1.4);ctx.restore();if(mv&&Math.random()<.02&&Math.hypot(P.x-x,P.y-y)<300)tone(2400,2600,.12,'sine',.012)}
  if(r){ctx.globalCompositeOperation='lighter';const g=ctx.createRadialGradient(8,-12,0,8,-12,9);g.addColorStop(0,['','rgba(90,208,106,.5)','rgba(176,106,255,.55)','rgba(255,58,58,.6)'][r.t]);g.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=g;ctx.fillRect(-2,-22,20,20)}
  ctx.restore();if(c&&c.t===3||b&&b.t===3||r&&r.t===3){if(Math.random()<.06)rfxP(x+(Math.random()-.5)*14,y-8,0,-24,.6,'255,90,70',1.6,'spark')}}}
// หน้าต่าง
const paW=mk6('pacw');const PAU={sel:null,tab:'all'};
function openPA(){p6open(paW);renderPA()}window.openPA=openPA;window.closePA=()=>p6close(paW);
function petPreview(){const c=document.createElement('canvas');c.width=180;c.height=110;const k=c.getContext('2d'),sv=ctx;ctx=k;try{const g=k.createRadialGradient(90,80,4,90,70,90);g.addColorStop(0,'#5a4a7a');g.addColorStop(1,'#1a1428');k.fillStyle=g;k.fillRect(0,0,180,110);k.translate(90,96);k.scale(3.2,3.2);const ox=PET.x,oy=PET.y,of=PET.f;PET.f=1;drawPet({k:HOME.pet},0,0);PET.f=of}catch(e){}finally{ctx=sv}return c}
function renderPA(){const sel=PA.items.find(q=>q.u===PAU.sel);const eqU=new Set(Object.values(PA.eq));
 let h='<div class="w"><div class="hd"><b>🐾 เครื่องประดับสัตว์เลี้ยง</b><button onclick="closePA()">✕</button></div><div class="bd"><div class="col" style="width:min(42%,320px)"><div class="card" style="text-align:center"><div id="pa6pv"></div>'+(HOME.pet?'':'<small style="color:#ff9a7a">ยังไม่มีสัตว์เลี้ยง — ซื้อได้ที่ลุงขายผักในเมือง</small>')+'</div><div class="slots">';
 for(const s in PAK){const it=PA.items.find(q=>q.u===PA.eq[s]);h+='<div class="slot" onclick="PAU.sel='+(it?it.u:'null')+';renderPA()" style="'+(it?'border:2px solid '+PAT[it.t].c:'')+'">'+(it?'<img src="'+paIcon(it.k,it.t)+'">':'<span style="position:static;font-size:22px;opacity:.4">'+PAK[s].e+'</span>')+'<span>'+PAK[s].n+'</span></div>'}
 const x=PAX();h+='</div><div class="card" style="margin-top:10px"><b style="font-size:12.5px">📊 รวมค่าที่ได้</b><br><small>'+(PAKEYS.filter(k=>x[k]).map(k=>PAS[k].n+' +'+(x[k]*100).toFixed(1)+'%').join('<br>')||'ยังไม่ได้สวมใส่')+'</small></div></div>';
 h+='<div class="col" style="flex:1"><div class="lst">';
 const L=PA.items.slice().sort((a,b)=>b.t-a.t||a.k.localeCompare(b.k));for(const it of L)h+='<div class="cell'+(it.u===PAU.sel?' sel':'')+(eqU.has(it.u)?' eq':'')+'" style="--tc:'+PAT[it.t].c+'" onclick="PAU.sel='+it.u+';renderPA()"><img src="'+paIcon(it.k,it.t)+'"><em>'+it.t+'</em></div>';
 if(!L.length)h+='<small style="grid-column:1/-1">ยังไม่มีเครื่องประดับ — ดรอปจากมอนในดันเจี้ยน/เหมือง (อีลิทและบอสดรอปบ่อยกว่า) · ขั้น 2 ดรอปจากบอสดันเจี้ยนชั้น 50 ขึ้นไป</small>';
 h+='</div>';
 if(sel){const same=PA.items.filter(q=>q!==sel&&q.k===sel.k&&q.t===sel.t&&!eqU.has(q.u)).length,locks=sel.l.filter(l=>l.lk).length,rc=2000+locks*1500,isEq=eqU.has(sel.u);
  h+='<div class="card"><b style="color:'+PAT[sel.t].c+'">'+PAK[sel.k].n+' '+PAT[sel.t].n+'</b>'+(isEq?' <small style="color:#8fe08a">● สวมอยู่</small>':'');
  sel.l.forEach((l,i)=>{h+='<div class="ln">'+(sel.t>=3?'<button class="lk'+(l.lk?' on':'')+'" onclick="paLock('+i+')" title="ล็อกค่านี้ไว้ตอนรีค่า">'+(l.lk?'🔒':'🔓')+'</button>':'')+PAS[l.s].n+'<b>+'+l.v+PAS[l.s].u+'</b></div>'});
  h+='<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:6px">'+(isEq?'<button class="bt" onclick="paUnequip()">ถอดออก</button>':'<button class="bt g" '+(HOME.pet?'':'disabled')+' onclick="paEquip()">สวมให้สัตว์เลี้ยง</button>')
   +(sel.t<3?'<button class="bt" '+(same>=2?'':'disabled')+' onclick="paMerge()">⚡ ทะลวงเป็น'+PAT[sel.t+1].n+' (ใช้ชิ้นเหมือนกัน 3 ชิ้น · มี '+(same+1)+'/3)</button>':'<button class="bt" '+(inv.coin>=rc&&locks<3?'':'disabled')+' onclick="paReroll()">🎲 รีค่า ('+rc.toLocaleString()+' 🪙)</button>')
   +(isEq?'':'<button class="bt r" onclick="paSalvage()">ย่อยทิ้ง (+'+[0,80,400,2000][sel.t]+' 🪙)</button>')+'</div>'+(sel.t>=3?'<small>กด 🔓 เพื่อล็อกค่าที่ชอบไว้ — รีค่าจะสุ่มเฉพาะค่าที่ไม่ล็อก (ล็อกเพิ่มราคา)</small>':'<small>ทะลวง: รวม 3 ชิ้นชนิดและขั้นเดียวกัน → ได้ขั้นที่สูงขึ้น ค่าแรงขึ้นและมีหลายบรรทัด · ขั้น 3 (แดง) รีค่าได้</small>')+'</div>'}
 h+='</div></div></div>';paW.innerHTML=h;const pv=gid('pa6pv');if(pv&&HOME.pet)pv.appendChild(petPreview())}
window.PAU=PAU;window.renderPA=renderPA;
const paSel=()=>PA.items.find(q=>q.u===PAU.sel);
window.paEquip=()=>{const it=paSel();if(!it||!HOME.pet)return;PA.eq[it.k]=it.u;savePA();sfx('gem');tone(1200,1800,.2,'sine',.05);renderPA()};
window.paUnequip=()=>{const it=paSel();if(!it)return;if(PA.eq[it.k]===it.u)PA.eq[it.k]=null;savePA();sfx('ui');renderPA()};
window.paLock=i=>{const it=paSel();if(!it||it.t<3)return;const l=it.l[i];if(!l.lk&&it.l.filter(q=>q.lk).length>=2){say('ล็อกได้สูงสุด 2 ค่า');return}l.lk=l.lk?0:1;savePA();sfx('ui');renderPA()};
window.paReroll=()=>{const it=paSel();if(!it||it.t<3)return;const locks=it.l.filter(l=>l.lk).length,rc=2000+locks*1500;if(inv.coin<rc){say('เหรียญไม่พอ');return}inv.coin-=rc;refreshInv();
 const keep=it.l.filter(l=>l.lk).map(l=>l.s);it.l=it.l.map(l=>{if(l.lk)return l;const n=paRoll(3,keep);keep.push(n.s);return n});savePA();sfx('gem');for(let i=0;i<5;i++)tone(600+i*180,0,.12,'triangle',.04,i*.06);say('🎲 รีค่าสำเร็จ!');renderPA()};
window.paMerge=()=>{const it=paSel();if(!it||it.t>=3)return;const eqU=new Set(Object.values(PA.eq)),others=PA.items.filter(q=>q!==it&&q.k===it.k&&q.t===it.t&&!eqU.has(q.u)).slice(0,2);if(others.length<2){say('ต้องมีชิ้นเหมือนกันอีก 2 ชิ้น (ที่ไม่ได้สวมอยู่)');return}
 for(const q of [it,...others]){const i=PA.items.indexOf(q);if(i>=0)PA.items.splice(i,1);for(const s in PA.eq)if(PA.eq[s]===q.u)PA.eq[s]=null}const n=paNew(it.k,it.t+1);PAU.sel=n.u;savePA();
 shake(3,.3);sfx('chest');for(let i=0;i<6;i++)tone(400+i*160,0,.25,'sawtooth',.03,i*.07);try{banner('⚡ ทะลวงสำเร็จ!',PAK[n.k].n+' '+PAT[n.t].n,n.t===3?'red':'')}catch(e){}renderPA()};
window.paSalvage=()=>{const it=paSel();if(!it)return;const v=[0,80,400,2000][it.t];PA.items.splice(PA.items.indexOf(it),1);PAU.sel=null;inv.coin+=v;refreshInv();savePA();sfx('coin');renderPA()};
// ปุ่ม 🐾 บนจอ
const petB=document.createElement('button');petB.id='petb6';petB.textContent='🐾';petB.title='เครื่องประดับสัตว์เลี้ยง';petB.onclick=e=>{e.stopPropagation();openPA()};{const zb=gid('zb');if(zb)zb.appendChild(petB)}
setInterval(()=>{petB.hidden=!HOME.pet&&!PA.items.length},800);
{const _rl=renderLife;renderLife=function(){_rl();try{if(LIFE&&(LIFE.tab==='pet')){const b=lifeEl.querySelector('.lb');if(b&&!b.querySelector('.pa6'))b.insertAdjacentHTML('afterbegin','<div class="it pa6" style="grid-column:1/-1;flex-direction:row;align-items:center"><b style="flex:1">🐾 เครื่องประดับสัตว์เลี้ยง (ปลอกคอ · กระพรวน · แหวน)</b><button onclick="closeLife();openPA()">เปิด</button></div>')}}catch(e){}}}

// =====================================================================
// 2) ร้านแฟชั่น (ชุด + อาวุธ) — บ้านสีม่วงมุมขวาล่างกลายเป็นบูติก
// =====================================================================
const FASH={own:[],body:null,wpn:null};try{Object.assign(FASH,JSON.parse(localStorage.getItem('fm_fash')||'{}'))}catch(e){}
const saveFash=()=>{try{localStorage.setItem('fm_fash',JSON.stringify(FASH))}catch(e){}};
const OUTFIT={
 night:{n:'ชุดอัศวินรัตติกาล',p:4500,TOP:'#1c1a2c',COLLAR:'#e8c14a',BLK:'#15141f',LEG2:'#2c2a3e',cape:['#3a0a4a','#1a0424','#e8c14a'],hat:'circlet',d:'ผ้าคลุมม่วงขลิบทอง มงกุฎเงินบาง ๆ'},
 sakura:{n:'ชุดซามูไรซากุระ',p:6000,TOP:'#f2a6c2',COLLAR:'#ffffff',BLK:'#3a2a4a',LEG2:'#5a3a6a',hat:'kasa',fx:'petal',d:'กลีบซากุระโปรยตามตัว หมวกฟางซามูไร'},
 star:{n:'ชุดจอมเวทดวงดาว',p:8000,TOP:'#1a2a6a',COLLAR:'#ffd23a',BLK:'#141a3a',LEG2:'#0a0e24',cape:['#0e1a50','#050a24','#ffd23a'],hat:'wizard',fx:'star',d:'หมวกแหลมปักดาว ผ้าคลุมกลางคืนประกายดาว'},
 pirate:{n:'ชุดกัปตันโจรสลัด',p:7000,TOP:'#a81a1a',COLLAR:'#f4e8d0',BLK:'#2a1a10',LEG2:'#1a0e08',cape:['#5a0a0a','#2a0404','#e8c14a'],hat:'tricorn',d:'หมวกสามมุมขนนก โค้ทแดงกระดุมทอง'},
 flame:{n:'ชุดเทพอัคคี',p:18000,TOP:'#c83a0a',COLLAR:'#ffd060',BLK:'#3a0a04',LEG2:'#1a0402',cape:['#ff6a1a','#6a0a00','#ffd060'],hat:'flamecrown',fx:'fire',d:'มงกุฎเปลวไฟ ผ้าคลุมลุกโชน ประกายไฟตลอดเวลา'},
 frost:{n:'ชุดราชันย์น้ำแข็ง',p:18000,TOP:'#bfe8ff',COLLAR:'#ffffff',BLK:'#5a86aa',LEG2:'#3a5a7a',cape:['#e8f8ff','#7ab8e0','#ffffff'],hat:'icecrown',fx:'snow',d:'มงกุฎคริสตัลน้ำแข็ง เกล็ดหิมะร่วงรอบตัว'}};
const FWPN={
 dragon:{n:'ดาบมังกรเพลิง',p:9000,b:['#ffd0a0','#ff5a1a','#8a1a04'],g:'#e8c14a',glow:'255,110,30',d:'ใบดาบเปลวเพลิง ด้ามหัวมังกร'},
 sakura:{n:'คาตานะซากุระ',p:6500,b:['#ffffff','#f0d8e4','#a07a90'],g:'#c0507a',glow:'255,170,210',kat:1,d:'คาตานะใบบางคม ลายกลีบซากุระ'},
 crystal:{n:'ดาบคริสตัลน้ำแข็ง',p:9000,b:['#ffffff','#9ae0ff','#3a7ab0'],g:'#dff4ff',glow:'140,220,255',d:'ใบดาบคริสตัลโปร่งแสง เย็นยะเยือก'},
 moon:{n:'ดาบเงาจันทรา',p:12000,b:['#e8d8ff','#7a4ab0','#2a0a4a'],g:'#c8b8ff',glow:'170,120,255',curve:1,d:'ดาบโค้งดั่งจันทร์เสี้ยว เงาม่วงเรืองรอง'},
 holy:{n:'มหาดาบศักดิ์สิทธิ์',p:20000,b:['#ffffff','#fff2b0','#c8a030'],g:'#ffd23a',glow:'255,240,160',big:1,d:'ดาบใหญ่แห่งแสง ปีกทองที่ด้าม'},
 thunder:{n:'คาตานะอสนี',p:15000,b:['#ffffff','#c8e0ff','#3a4a8a'],g:'#2a2a3a',glow:'150,200,255',kat:1,bolt:1,d:'ใบดาบสายฟ้าแลบเป็นระยะ'}};
const FW6={};
function fashSword(id){if(FW6[id])return FW6[id];const W=FWPN[id],c=document.createElement('canvas');c.width=c.height=64;const q=c.getContext('2d');q.lineJoin='round';q.lineCap='round';
 const L=W.big?50:W.kat?48:44,w=W.big?6:W.kat?3:4.5,top=58-L-6;const g=q.createLinearGradient(32-w,0,32+w,0);g.addColorStop(0,W.b[2]);g.addColorStop(.5,W.b[0]);g.addColorStop(1,W.b[1]);q.fillStyle=g;q.strokeStyle='#14141a';q.lineWidth=1.4;q.beginPath();
 if(W.kat){q.moveTo(32-w,46);q.quadraticCurveTo(30-w,24,34,top);q.quadraticCurveTo(34+w,24,32+w,46);}else if(W.curve){q.moveTo(32-w,46);q.quadraticCurveTo(24,26,36,top);q.quadraticCurveTo(32,24,32+w,46);}else{q.moveTo(32-w,46);q.lineTo(32-w,top+8);q.lineTo(32,top);q.lineTo(32+w,top+8);q.lineTo(32+w,46)}q.closePath();q.fill();q.stroke();
 q.strokeStyle='rgba(255,255,255,.7)';q.lineWidth=1;q.beginPath();q.moveTo(32,44);q.lineTo(32,top+6);q.stroke();
 if(id==='dragon'){q.fillStyle='rgba(255,220,120,.85)';for(let i=0;i<5;i++){q.beginPath();q.moveTo(32+w,40-i*7);q.lineTo(36+w,37-i*7);q.lineTo(32+w,35-i*7);q.fill()}}
 if(id==='sakura'){q.fillStyle='#ff8ab8';for(const [a,b] of [[31,30],[33,22],[31,14]]){q.beginPath();q.arc(a,b,1.6,0,7);q.fill()}}
 if(W.bolt){q.strokeStyle='#ffffa0';q.lineWidth=1.2;q.beginPath();q.moveTo(31,42);q.lineTo(34,34);q.lineTo(30,28);q.lineTo(34,18);q.stroke()}
 q.fillStyle=W.g;q.strokeStyle='#14141a';q.lineWidth=1.4;if(W.kat){q.beginPath();q.ellipse(32,47.5,6,2.4,0,0,7);q.fill();q.stroke()}else if(W.big){q.beginPath();q.moveTo(18,44);q.quadraticCurveTo(24,52,32,47);q.quadraticCurveTo(40,52,46,44);q.lineTo(46,49);q.lineTo(18,49);q.closePath();q.fill();q.stroke()}else{q.fillRect(22,46,20,3.5);q.strokeRect(22,46,20,3.5)}
 q.fillStyle=W.kat?'#1a1a22':'#4a2a14';q.fillRect(30.5,49,3,9);if(W.kat){q.fillStyle='#f4f0e8';for(let y=50;y<58;y+=2.5)q.fillRect(30.5,y,3,1)}q.fillStyle=W.g;q.beginPath();q.arc(32,59,2.4,0,7);q.fill();q.stroke();
 if(id==='dragon'){q.fillStyle='#c8901a';q.beginPath();q.moveTo(22,47);q.lineTo(16,42);q.lineTo(20,48);q.fill();q.beginPath();q.moveTo(42,47);q.lineTo(48,42);q.lineTo(44,48);q.fill()}
 return FW6[id]=c}
{const _ts=toolSpr;toolSpr=function(hx,hy,ang){if(!(FASH.wpn&&P.tool==='sword'&&FWPN[FASH.wpn]&&!isRng()))return _ts(hx,hy,ang);const W=FWPN[FASH.wpn],t=performance.now()/1000;ctx.save();ctx.translate(hx,hy);ctx.rotate(ang);if(P.dir==='r')ctx.scale(-1,1);ctx.drawImage(fashSword(FASH.wpn),-23,-36,46,46);
  ctx.globalCompositeOperation='lighter';const g=ctx.createLinearGradient(0,-34,0,0);g.addColorStop(0,'rgba('+W.glow+',0)');g.addColorStop(.5,'rgba('+W.glow+','+(.25+.15*Math.sin(t*4))+')');g.addColorStop(1,'rgba('+W.glow+',0)');ctx.fillStyle=g;ctx.fillRect(-6,-34,12,30);ctx.restore();
  if(Math.random()<.12){const a=ang-Math.PI/2;rfxP(hx+Math.cos(a)*18,hy+Math.sin(a)*18,(Math.random()-.5)*14,-14,.5,W.glow,1.6,W.bolt&&Math.random()<.4?'spark':'dot')}}}
// ชุด: ซ่อนเกราะเดิมตอนวาด แล้ววาดชุดแฟชั่นแทน
{const _eq=EQCOL;EQCOL=function(){const o=_eq();const F=FASH.body&&OUTFIT[FASH.body];if(F&&window._fashOn)return Object.assign({},o,{TOP:F.TOP,COLLAR:F.COLLAR,BLK:F.BLK,LEG2:F.LEG2});return o}}
function drawCape(F,f,side,d,t){if(!F.cape)return;const x=P.x,by=P.y,sw=Math.sin(t*3)*2+(P.mv?Math.sin(P.t*2)*3:0);ctx.save();const g=ctx.createLinearGradient(0,by-28,0,by-2);g.addColorStop(0,F.cape[0]);g.addColorStop(1,F.cape[1]);ctx.fillStyle=g;ctx.strokeStyle=F.cape[2];ctx.lineWidth=1.2;ctx.beginPath();
 if(side){ctx.moveTo(x-f*2,by-28);ctx.quadraticCurveTo(x-f*12-sw,by-14,x-f*14-sw*1.5,by-2);ctx.lineTo(x-f*3,by-4);ctx.closePath()}else{ctx.moveTo(x-8,by-28);ctx.lineTo(x+8,by-28);ctx.lineTo(x+11+sw*.5,by-3);ctx.quadraticCurveTo(x,by+1,x-11+sw*.5,by-3);ctx.closePath()}
 ctx.fill();ctx.stroke();if(F.fx==='fire'){ctx.globalCompositeOperation='lighter';const fg=ctx.createRadialGradient(x,by-6,0,x,by-6,14);fg.addColorStop(0,'rgba(255,140,40,.35)');fg.addColorStop(1,'rgba(255,60,0,0)');ctx.fillStyle=fg;ctx.fillRect(x-14,by-20,28,28)}ctx.restore()}
function drawHat(F,f,side,d,t){const x=P.x,y=P.y-47,R=(c,a,b,w,h)=>{ctx.fillStyle=c;ctx.fillRect(Math.round(a),Math.round(b),w,h)};ctx.save();
 if(F.hat==='circlet'){R('#d8dce8',x-7,y+3,14,2);R('#7a4ab0',x-1,y+1,2,2)}
 else if(F.hat==='kasa'){ctx.fillStyle='#d8b86a';ctx.strokeStyle='#6a4a1a';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x-15,y+5);ctx.quadraticCurveTo(x,y-9,x+15,y+5);ctx.closePath();ctx.fill();ctx.stroke();ctx.strokeStyle='rgba(106,74,26,.5)';for(const o of [-8,-3,3,8]){ctx.beginPath();ctx.moveTo(x,y-4);ctx.lineTo(x+o*1.6,y+4);ctx.stroke()}}
 else if(F.hat==='wizard'){ctx.fillStyle='#1a2a6a';ctx.strokeStyle='#0a1030';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x-12,y+4);ctx.lineTo(x+12,y+4);ctx.lineTo(x+(side?-f*10:3),y-20);ctx.closePath();ctx.fill();ctx.stroke();R('#ffd23a',x-12,y+2,24,2.5);ctx.fillStyle='#ffd23a';ctx.beginPath();ctx.arc(x+(side?-f*4:1),y-6,1.8,0,7);ctx.fill()}
 else if(F.hat==='tricorn'){ctx.fillStyle='#14141a';ctx.strokeStyle='#e8c14a';ctx.lineWidth=1.2;ctx.beginPath();ctx.moveTo(x-14,y+3);ctx.quadraticCurveTo(x,y-12,x+14,y+3);ctx.quadraticCurveTo(x,y-1,x-14,y+3);ctx.fill();ctx.stroke();ctx.strokeStyle='#f4f0e8';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x+(side?-f*4:4),y-4);ctx.quadraticCurveTo(x+(side?-f*14:12),y-12,x+(side?-f*18:16),y-6);ctx.stroke()}
 else if(F.hat==='flamecrown'||F.hat==='icecrown'){const fire=F.hat==='flamecrown';R(fire?'#ffd060':'#e8f8ff',x-8,y+1,16,3);for(let i=0;i<5;i++){const px=x-7+i*3.5,hh=fire?5+Math.sin(t*12+i*2)*2.5:6+(i%2?3:0);ctx.fillStyle=fire?(i%2?'#ff6a1a':'#ffb030'):(i%2?'#bfe8ff':'#ffffff');ctx.beginPath();ctx.moveTo(px-1.6,y+1);ctx.lineTo(px,y+1-hh);ctx.lineTo(px+1.6,y+1);ctx.fill()}
  ctx.globalCompositeOperation='lighter';const g=ctx.createRadialGradient(x,y-2,0,x,y-2,14);g.addColorStop(0,fire?'rgba(255,140,40,.45)':'rgba(170,230,255,.45)');g.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=g;ctx.fillRect(x-14,y-16,28,28)}
 ctx.restore()}
{const _h=hero;hero=function(){const F=FASH.body&&OUTFIT[FASH.body];if(!F||P.dead)return _h();const t=performance.now()/1000,d=P.dir,side=d==='l'||d==='r',f=d==='l'?-1:1;
  if(d!=='u')drawCape(F,f,side,d,t);const sv={helm:P.armor.helm,chest:P.armor.chest,pants:P.armor.pants,arm:P.armor.arm};window._fashOn=1;P.armor.helm=P.armor.chest=P.armor.pants=P.armor.arm=null;
  try{_h()}finally{Object.assign(P.armor,sv);window._fashOn=0}
  if(d==='u')drawCape(F,f,side,d,t);if(!MOUNT.on||!HOME.mount)drawHat(F,f,side,d,t);
  if(F.fx&&Math.random()<.18){const rgb=F.fx==='petal'?'255,170,200':F.fx==='star'?'255,230,120':F.fx==='fire'?'255,120,30':'230,245,255';rfxP(P.x+(Math.random()-.5)*26,P.y-10-Math.random()*36,(Math.random()-.5)*12,F.fx==='fire'?-30:12,1,rgb,F.fx==='star'?1.6:2,F.fx==='fire'||F.fx==='star'?'spark':'dot')}}}
// อาคารบูติก
SIGN_ICONS.fashion=k=>{k.fillStyle='#f2a6c2';k.strokeStyle='#3a1a2a';k.lineWidth=2.5;k.beginPath();k.moveTo(-10,-12);k.lineTo(-4,-14);k.quadraticCurveTo(0,-9,4,-14);k.lineTo(10,-12);k.lineTo(14,-4);k.lineTo(9,-2);k.lineTo(9,14);k.lineTo(-9,14);k.lineTo(-9,-2);k.lineTo(-14,-4);k.closePath();k.fill();k.stroke();k.fillStyle='#ffd23a';k.beginPath();k.arc(0,2,3,0,7);k.fill();k.stroke()};
SD.fashion={name:'บูติกแฟชั่นมาดามโรส',emoji:'👗',icon:'fashion',img:'house2',b:[36,24,5,4],door:{x:62,w:36,t:74,bt:126},sign:{x:128,y:84,arm:24},
 owner:{name:'มาดามโรส',c:'#c0507a',h:'#f4e0a0',g:'f',age:'adult',hs:'bun',greet:['ยินดีต้อนรับสู่บูติกของฉันค่ะ ที่รัก','ชุดใหม่เพิ่งมาถึงเมื่อเช้า สวยทุกชุดเลย!'],lines:['ชุดแฟชั่นไม่เปลี่ยนค่าพลังนะคะ แต่หล่อสวยกว่าเดิมแน่นอน','ชุดเทพอัคคีกับราชันย์น้ำแข็ง ตัดเย็บด้วยเวทมนตร์เชียวนะ','อาวุธแฟชั่นเปลี่ยนแค่รูปลักษณ์ พลังยังเท่าอาวุธจริงค่ะ']},solid:SD.potion.solid.slice(),sell:[],buy:[]};
SHOP_ORDER.push('fashion');SHOP_ART.fashion=SHOP_ART.skill;SHOP_ANIM.fashion=SHOP_ANIM.skill;SHOP_TINT.fashion='rgba(255,140,200,.10)';
{const _ot=ownerTalk;ownerTalk=function(id){if(id!=='fashion')return _ot(id);const o=D.owner;talk(o,pick(SD.fashion.owner.greet)+' — อยากดูอะไรดีคะ?',[{t:'👗 ชุดแฟชั่น',c:'go',f:()=>openFash('body')},{t:'🗡️ อาวุธแฟชั่น',f:()=>openFash('wpn')},{t:'🪞 ตู้เสื้อผ้าของฉัน',f:()=>openFash('mine')},{t:'💬 คุยเล่น',stay:true,f:()=>talk(o,pick(SD.fashion.owner.lines),[BYE])},BYE],'มาดามโรส');return true}}
const fsW=mk6('fashw');const FSU={tab:'body'};
function openFash(t){FSU.tab=t||'body';p6open(fsW);renderFash()}window.openFash=openFash;window.closeFash=()=>p6close(fsW);
function fashPreview(kind,id){const c=document.createElement('canvas');c.width=150;c.height=96;const k=c.getContext('2d'),sv=ctx,svB=FASH.body,svW=FASH.wpn,sx=P.x,sy=P.y,sd=P.dir,sm=P.mv,sdr=P.draw,stl=P.tool,smo=MOUNT.on;ctx=k;
 try{const g=k.createRadialGradient(75,70,4,75,60,80);g.addColorStop(0,'#5a4a7a');g.addColorStop(1,'#1a1428');k.fillStyle=g;k.fillRect(0,0,150,96);k.translate(75,88);k.scale(1.6,1.6);P.x=0;P.y=0;P.dir='d';P.mv=false;MOUNT.on=false;
  if(kind==='body'){FASH.body=id;hero()}else{FASH.body=svB;P.draw=true;P.tool='sword';FASH.wpn=id;P.dir='l';hero()}}catch(e){}finally{ctx=sv;FASH.body=svB;FASH.wpn=svW;P.x=sx;P.y=sy;P.dir=sd;P.mv=sm;P.draw=sdr;P.tool=stl;MOUNT.on=smo}return c}
function renderFash(){const T6=FSU.tab;let h='<div class="w"><div class="hd"><b>👗 บูติกมาดามโรส · 🪙 '+inv.coin.toLocaleString()+'</b><button class="'+(T6==='body'?'on':'')+'" onclick="openFash(\'body\')">ชุด</button><button class="'+(T6==='wpn'?'on':'')+'" onclick="openFash(\'wpn\')">อาวุธ</button><button class="'+(T6==='mine'?'on':'')+'" onclick="openFash(\'mine\')">ตู้ของฉัน</button><button onclick="closeFash()">✕</button></div><div class="bd"><div class="fit">';
 const list=T6==='wpn'?Object.keys(FWPN).map(k=>['w',k]):T6==='body'?Object.keys(OUTFIT).map(k=>['b',k]):FASH.own.map(s=>[s[0],s.slice(2)]);
 if(T6==='mine')h+='<div class="it"><b>ใส่ชุดเกราะจริง</b><small>ถอดชุด/อาวุธแฟชั่นทั้งหมด</small><button class="bt" onclick="fashWear(\'b\',null);fashWear(\'w\',null)">ถอดแฟชั่น</button></div>';
 for(const [ty,k] of list){const D6=ty==='w'?FWPN[k]:OUTFIT[k];if(!D6)continue;const key=ty+':'+k,own=FASH.own.includes(key),wear=ty==='w'?FASH.wpn===k:FASH.body===k;
  h+='<div class="it'+(own?' own':'')+(wear?' wear':'')+'"><span data-fp="'+ty+':'+k+'"></span><b>'+D6.n+'</b><small>'+D6.d+'</small>'+(own?'<button class="bt '+(wear?'':'g')+'" onclick="fashWear(\''+ty+'\','+(wear?'null':'\''+k+'\'')+')">'+(wear?'ถอด':'สวมใส่')+'</button>':'<button class="bt g" '+(inv.coin>=D6.p?'':'disabled')+' onclick="fashBuy(\''+ty+'\',\''+k+'\')">ซื้อ '+D6.p.toLocaleString()+' 🪙</button>')+'</div>'}
 if(T6==='mine'&&!FASH.own.length)h+='<small>ยังไม่มีของแฟชั่น — เลือกซื้อได้ที่แท็บ ชุด/อาวุธ</small>';
 h+='</div></div></div>';fsW.innerHTML=h;for(const s of fsW.querySelectorAll('[data-fp]')){const [ty,k]=s.dataset.fp.split(':');s.replaceWith(fashPreview(ty==='w'?'wpn':'body',k))}}
window.fashBuy=(ty,k)=>{const D6=ty==='w'?FWPN[k]:OUTFIT[k];if(!D6||inv.coin<D6.p)return;inv.coin-=D6.p;FASH.own.push(ty+':'+k);refreshInv();saveFash();sfx('chest');for(let i=0;i<5;i++)tone(800+i*200,0,.15,'triangle',.04,i*.07);fashWear(ty,k);try{banner('✨ ได้'+D6.n+'!','สวมใส่แล้ว — เปลี่ยนได้ที่ตู้เสื้อผ้า','')}catch(e){}};
window.fashWear=(ty,k)=>{if(ty==='w')FASH.wpn=k;else FASH.body=k;saveFash();sfx('ui');if(!fsW.hidden)renderFash()};

// =====================================================================
// 3) ช่างตีเหล็ก: ร้านขายเฉพาะของหาง่าย · คราฟต้องเดินไปที่เตา/ทั่งเอง · ตำราปลดล็อกชุดตามเลเวล
// =====================================================================
SD2.gear.buy=SD2.gear.buy.filter(b=>b.item&&ITEMS[b.item]&&ITEMS[b.item].tier===0);
const SMITH={u:0,q:0};try{Object.assign(SMITH,JSON.parse(localStorage.getItem('fm_smith')||'{}'))}catch(e){}
const saveSmith=()=>{try{localStorage.setItem('fm_smith',JSON.stringify(SMITH))}catch(e){}};
{let mx=0;const chk=id=>{const it=ITEMS[id];if(it&&it.tier>mx)mx=it.tier};for(const id in GEAR)chk(id);for(const k in P.armor)if(P.armor[k])chk(P.armor[k]);if(mx>SMITH.u){SMITH.u=mx;saveSmith()}}
const SMQ=[null,
 {lv:5,n:'ตำราช่าง: ชุดเหล็ก',need:{ingot:6,wing:4},w:'แร่เหล็กขุดได้ใน "เหมืองเหล็กร้าง" (ประตูมิติในทุ่งหญ้า) และดันเจี้ยนชั้นต้น · หลอมที่เตาหลอมในร้านข้า (ใช้ถ่านจากไม้) · ปีกค้างคาวดรอปจากค้างคาวเหมือง/ค้างคาวในดันเจี้ยน'},
 {lv:20,n:'ตำราช่าง: ชุดทองแดง',need:{ingCu:8,shell:6},w:'แร่ทองแดงอยู่ใน "ถ้ำทองแดงลาวา" · เปลือกด้วงดรอปจากด้วงหินสนิม (เหมืองเหล็ก) และด้วงในดันเจี้ยน'},
 {lv:40,n:'ตำราช่าง: ชุดเงิน',need:{ingAg:10,pelt:8},w:'แร่เงินอยู่บน "ยอดเขาเงินหิมะ" · หนังหมาป่าดรอปจากหมาป่าสำริด/หมาป่าหิมะ'},
 {lv:60,n:'ตำราช่าง: ชุดทอง',need:{ingAu:12,core:8},w:'แร่ทองอยู่ใน "สุสานทองคำ" · แกนหินเวทดรอปจากโกเลมทุกชนิด'},
 {lv:80,n:'ตำราช่าง: ชุดเพชร',need:{ingDm:12,scale:4},w:'แร่เพชรอยู่ใน "เหมืองเพชรห้วงลึก" · เกล็ดมังกรดรอปจากมังกร/ดันเจี้ยนชั้นลึก'}];
const smNext=()=>SMITH.u<5?SMITH.u+1:0;
const smAvail=()=>{const n=smNext();return n&&P.lv>=SMQ[n].lv};
function smNeedTxt(n){return Object.entries(SMQ[n].need).map(([k,v])=>MN(k)+' '+Math.min(inv[k]|0,v)+'/'+v).join(' · ')}
function smithQuest(){const o=D.owner,n=smNext();if(!n){talk(o,'เจ้าปลดล็อกตำราครบทุกระดับแล้ว! ไม่มีอะไรที่ข้าสอนเจ้าได้อีก',[BYE]);return}const Q=SMQ[n];
 if(P.lv<Q.lv){talk(o,'ตำรา'+TNAMES[n]+'ยังยากเกินไปสำหรับเจ้า กลับมาเมื่อถึง Lv.'+Q.lv+' แล้วข้าจะสอนให้',[BYE]);return}
 if(SMITH.q!==n){SMITH.q=n;saveSmith();talk(o,'📜 '+Q.n+' — ถ้าอยากตีชุด'+TNAMES[n]+' เอาของพวกนี้มาให้ข้าก่อน: '+smNeedTxt(n)+'\n\n🗺️ '+Q.w,[{t:'⚔️ รับตำรา',c:'go',f:()=>{sysSay('⚒️ เควสช่าง: '+Q.n+' — '+smNeedTxt(n));say('⚒️ รับเควส '+Q.n)}},BYE],'ช่างหนวดเหล็ก');return}
 const ok=Object.entries(Q.need).every(([k,v])=>(inv[k]|0)>=v);
 if(!ok){talk(o,'ยังขาดอยู่นะ: '+smNeedTxt(n)+'\n\n🗺️ '+Q.w,[BYE]);return}
 for(const [k,v] of Object.entries(Q.need))inv[k]-=v;SMITH.u=n;SMITH.q=0;saveSmith();refreshInv();sfx('chest');shake(2,.2);
 try{banner('⚒️ ปลดล็อก'+Q.n.replace('ตำราช่าง: ',''),'คราฟชุด/อาวุธระดับ'+TNAMES[n]+'ได้ที่ทั่งในร้าน','')}catch(e){}
 talk(o,'ฝีมือเจ้าใช้ได้! จำวิธีนี้ไว้: หลอมแร่เป็นแท่งที่เตาซ้ายมือ แล้วตีที่ทั่งขวามือ — ตอนนี้เจ้าตีของระดับ'+TNAMES[n]+'ได้แล้ว',[BYE])}
{const _ot=ownerTalk;ownerTalk=function(id){const r=_ot(id);if(id==='gear'&&DLG.open){DLG.ch=DLG.ch.filter(c=>!/คราฟ \/ ตีบวก/.test(c.t));const n=smNext();DLG.ch.splice(1,0,{t:(smAvail()?'❗ ':'')+'📜 ตำราช่าง'+(n?' ('+TNAMES[n]+')':''),c:smAvail()?'go':'',f:smithQuest},{t:'🔥 วิธีหลอม/ตีของ',f:()=>talk(D.owner,'เตาหลอมอยู่ซ้ายมือ ทั่งตีเหล็กอยู่ขวามือในร้านนี้ — เดินไปยืนหน้าเครื่องแล้วกด E / ⚔️ ได้เลย ข้าไม่ตีให้หรอก ฝึกเองสิ!',[BYE])});try{dlgShowChoices()}catch(e){}}return r}}
{const _cg=craftGear;craftGear=function(id){const it=ITEMS[id];if(it&&it.tier>SMITH.u){say('🔒 ยังตี'+TNAMES[it.tier]+'ไม่เป็น — รับตำราจากช่างหนวดเหล็ก (Lv.'+SMQ[it.tier].lv+')');sfx('thud');return}return _cg(id)}}
{const _ah=anvilHTML;anvilHTML=function(){let h=_ah();if(FUI.tab==='craft'&&FUI.tier>SMITH.u){const n=FUI.tier;h=h.replace(/<button class="mini cr[^"]*"/g,'<button class="mini cr no" disabled').replace(/(<small>วัสดุ:)/,'<div style="padding:7px;border-radius:9px;background:rgba(255,80,60,.15);border:1px solid #ff8a6a;margin:4px 0">🔒 <b>ยังตีระดับ'+TNAMES[n]+'ไม่ได้</b><br><small>คุยกับช่างหนวดเหล็ก → 📜 ตำราช่าง (ต้อง Lv.'+SMQ[n].lv+')</small></div>$1')}return h}}
let smNote=0;setInterval(()=>{if(smAvail()&&SMITH.q!==smNext()&&smNote!==smNext()){smNote=smNext();sysSay('❗ ช่างหนวดเหล็กมีตำรา'+TNAMES[smNote]+'ให้เจ้าแล้ว — ไปที่ร้านอาวุธ');try{banner('❗ ตำราช่างใหม่','ไปหาช่างหนวดเหล็กที่ร้านอาวุธ','')}catch(e){}}},3000);
try{STCH[2].intro='ดาบหินคงไม่พอสู้อสูรในเหมือง! ไปหาช่างหนวดเหล็กที่ร้านอาวุธ รับ “ตำราช่าง: ชุดเหล็ก” เก็บไม้ ขุดแร่ หลอมเป็นแท่งที่เตา แล้วตีดาบเหล็กที่ทั่งด้วยมือเจ้าเอง — และฝึกจนถึง Lv.5';STCH[2].d='Lv.5 + รับตำราช่างแล้วตีอาวุธเหล็กเอง'}catch(e){}
// ป้ายร้านอาวุธใหม่: ดาบไขว้ + โล่ + ทั่ง
SIGN_ICONS.gear=k=>{k.save();k.lineJoin='round';k.lineCap='round';
 k.fillStyle='#3a3e48';k.strokeStyle='#0e0e14';k.lineWidth=2;k.beginPath();k.moveTo(-12,9);k.lineTo(12,9);k.lineTo(9,13);k.lineTo(15,17);k.lineTo(-15,17);k.lineTo(-9,13);k.closePath();k.fill();k.stroke();
 const sw=(a)=>{k.save();k.rotate(a);const g=k.createLinearGradient(-3,0,3,0);g.addColorStop(0,'#8a96aa');g.addColorStop(.5,'#ffffff');g.addColorStop(1,'#6a7488');k.fillStyle=g;k.strokeStyle='#0e0e14';k.lineWidth=1.6;k.beginPath();k.moveTo(-2.6,6);k.lineTo(-2.6,-14);k.lineTo(0,-19);k.lineTo(2.6,-14);k.lineTo(2.6,6);k.closePath();k.fill();k.stroke();k.fillStyle='#e8c14a';k.fillRect(-7,6,14,3);k.strokeRect(-7,6,14,3);k.fillStyle='#5a3418';k.fillRect(-1.5,9,3,6);k.fillStyle='#e8c14a';k.beginPath();k.arc(0,16,2.2,0,7);k.fill();k.restore()};
 sw(-.62);sw(.62);
 const g=k.createLinearGradient(0,-10,0,8);g.addColorStop(0,'#d84a3a');g.addColorStop(1,'#7a1a12');k.fillStyle=g;k.strokeStyle='#e8c14a';k.lineWidth=2;k.beginPath();k.moveTo(0,-10);k.lineTo(8,-6);k.quadraticCurveTo(8,4,0,9);k.quadraticCurveTo(-8,4,-8,-6);k.closePath();k.fill();k.stroke();
 k.fillStyle='#e8c14a';k.beginPath();k.moveTo(0,-6);k.lineTo(2,-1);k.lineTo(0,4);k.lineTo(-2,-1);k.closePath();k.fill();k.restore()};

// =====================================================================
// 4) แท่นค้นหาของหาย (วิหารแห่งแสง): ของตกหล่นตอนกระเป๋าเต็ม + ซื้อคืนของที่เผลอขาย
// =====================================================================
const LOST={L:[]};try{Object.assign(LOST,JSON.parse(localStorage.getItem('fm_lost')||'{}'))}catch(e){}
const saveLost=()=>{try{LOST.L=LOST.L.slice(-40);localStorage.setItem('fm_lost',JSON.stringify(LOST))}catch(e){}};
const ALTAR={x:10,y:25};
function lostAdd(type,id,n,price,why){const e=LOST.L.find(q=>q.type===type&&q.id===id&&q.why===why);if(e){e.n+=n;e.p=Math.max(e.p,price);e.t=Date.now()}else LOST.L.push({type,id,n,p:price,why,t:Date.now()});saveLost()}
flushDrops=function(){let lost=0;for(const d of drops){const ik=DROPMAP[d.type]||d.type;let ok=true;try{ok=canTake(ik)===true}catch(e){}if(ok||ik==='coin')inv[ik]=(inv[ik]|0)+1;else{lostAdd('inv',ik,1,0,'drop');lost++}}drops.length=0;refreshInv();if(lost)setTimeout(()=>sysSay('🎒 กระเป๋าเต็ม — ของตกหล่น '+lost+' ชิ้น ไปรับคืนได้ที่ "แท่นค้นหาของหาย" ในวิหารแห่งแสง'),400)};
{const _sg=sellGear;sellGear=function(g){const it=ITEMS[g];const had=GEAR[g]|0;_sg(g);if(it&&(GEAR[g]|0)<had)lostAdd('gear',g,1,gearPrice(it),'sold')}}
{const snapSell=fn=>function(){const before=Object.assign({},inv),c0=inv.coin;const r=fn.apply(this,arguments);const gain=inv.coin-c0;if(gain>0){const dec=Object.keys(before).filter(k=>k!=='coin'&&(inv[k]|0)<(before[k]|0));const tot=dec.reduce((a,k)=>a+(before[k]-inv[k]),0);for(const k of dec){const n=before[k]-inv[k];lostAdd('inv',k,n,Math.max(1,Math.round(gain/tot)),'sold')}}return r};
 sellOK=snapSell(sellOK);sellIt=snapSell(sellIt)}
function lostCost(e){return e.why==='sold'?Math.ceil(e.p*1.2)*(e.type==='gear'?1:e.n):Math.max(10,8*e.n)}
const lsW=mk6('lostw');
function openLost(){p6open(lsW);renderLost()}window.openLost=openLost;window.closeLost=()=>p6close(lsW);
function renderLost(){let h='<div class="w"><div class="hd"><b>🔮 แท่นค้นหาของหาย · 🪙 '+inv.coin.toLocaleString()+'</b><button onclick="closeLost()">✕</button></div><div class="bd"><div class="col" style="flex:1"><small>แสงแห่งวิหารตามหาของที่ตกหล่นตอนกระเป๋าเต็ม และของที่เผลอขายไป (ซื้อคืนราคา +20%) · เก็บรายการล่าสุด 40 อย่าง</small><div class="fit">';
 const L=LOST.L.slice().reverse();if(!L.length)h+='<small>ไม่มีของหาย 🎉</small>';
 L.forEach(e=>{const i=LOST.L.indexOf(e),name=e.type==='gear'?ITEMS[e.id].name:MN(e.id),ic=e.type==='gear'?iconURL('item:'+e.id):iconURL('mat:'+e.id),c=lostCost(e);
  h+='<div class="it"><div style="display:flex;gap:8px;align-items:center"><img src="'+ic+'" style="width:40px;height:40px;background:none"><div><b>'+name+(e.type==='gear'?'':' ×'+e.n)+'</b><br><small>'+(e.why==='sold'?'💰 ขายไปเมื่อ ':'🎒 ตกหล่นเมื่อ ')+new Date(e.t).toLocaleTimeString('th-TH',{hour:'2-digit',minute:'2-digit'})+'</small></div></div><button class="bt g" '+(inv.coin>=c?'':'disabled')+' onclick="lostGet('+i+')">นำคืน '+c.toLocaleString()+' 🪙</button></div>'});
 h+='</div></div></div></div>';lsW.innerHTML=h}
window.lostGet=i=>{const e=LOST.L[i];if(!e)return;const c=lostCost(e);if(inv.coin<c){say('เหรียญไม่พอ');return}if(e.type==='gear'){try{if(bagCells().length>=bagSlotsMax()){noRoom('slot');return}}catch(_){}GEAR[e.id]=(GEAR[e.id]|0)+1}else{let ok=true;try{ok=canTake(e.id)===true}catch(_){}if(!ok){noRoom('slot');return}inv[e.id]=(inv[e.id]|0)+e.n}
 inv.coin-=c;LOST.L.splice(i,1);saveLost();refreshInv();sfx('gem');tone(900,1500,.4,'sine',.05);say('🔮 ได้ของคืนแล้ว!');renderLost()};
{const _bt=buildTown;buildTown=function(){_bt();try{const k=dcv.getContext('2d'),x=ALTAR.x*T,y=ALTAR.y*T;dm[ALTAR.y][ALTAR.x]=1;
  k.fillStyle='rgba(0,0,0,.25)';k.beginPath();k.ellipse(x+16,y+28,18,5,0,0,7);k.fill();const g=k.createLinearGradient(x,y,x+32,y);g.addColorStop(0,'#bfc4d0');g.addColorStop(.5,'#f4f6fa');g.addColorStop(1,'#9aa0ae');k.fillStyle=g;k.strokeStyle='#5a6070';k.lineWidth=1.5;
  k.fillRect(x+2,y+20,28,8);k.strokeRect(x+2,y+20,28,8);k.fillRect(x+7,y+6,18,14);k.strokeRect(x+7,y+6,18,14);k.fillRect(x+3,y+2,26,5);k.strokeRect(x+3,y+2,26,5);
  k.fillStyle='#7a4ab0';k.font='bold 9px system-ui,"Noto Sans Thai",sans-serif';k.textAlign='center';k.fillStyle='#4a2e16';k.fillRect(x-18,y+31,68,13);k.fillStyle='#fff3c8';k.fillText('แท่นค้นหาของหาย',x+16,y+41)}catch(e){}}}
{const _ta=townAct;townAct=function(){if(D&&D.town&&Math.hypot(P.x-(ALTAR.x*T+16),P.y-(ALTAR.y*T+30))<44){openLost();return true}return _ta()}}

// =====================================================================
// 5) ประตูแบบภาพตัด: เดินถึงหน้าประตู → ดำ+เบลอ → อยู่ในร้าน
// =====================================================================
const cut6=document.createElement('div');cut6.id='cut6';gid('wrap').appendChild(cut6);
const CUT={a:0,to:0,sp:2};
setInterval(()=>{if(Math.abs(CUT.a-CUT.to)<.01){CUT.a=CUT.to}else CUT.a+=(CUT.to-CUT.a)*.28;cut6.style.opacity=CUT.a.toFixed(3)},16);
function cutTo(a){CUT.to=a}window.cutTo=cutTo;
{const _dt=doorTick;doorTick=function(dt){const d=D&&D.doors&&D.doors.find(q=>q.id===DOORA.k);_dt(dt);if(d&&DOORA.k){if(P.y<d.cy-4)P.y=d.cy-4;if(DOORA.t>.35)cutTo(1)}}}
{const _es=enterShop;enterShop=function(id){const r=_es(id);FADE.a=0;CUT.a=1;CUT.to=1;setTimeout(()=>cutTo(0),180);return r}}
{const _ls=leaveShop;leaveShop=function(silent){if(!silent){CUT.a=1;CUT.to=1;setTimeout(()=>cutTo(0),200)}const r=_ls(silent);FADE.a=0;return r}}
