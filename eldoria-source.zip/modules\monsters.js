// =====================================================================
// monsters.js — สร้าง/ปรับค่ามอนจาก GAME_DATABASE · ส่ง MONSTER_DIED · ตารางดรอป · รับคำขอเกิดมอน (SPAWN_REQUEST)
// =====================================================================
(()=>{const DB=GAME_DATABASE,DC=DB.DungeonsData;
 const curFloor=()=>{try{const Zd=D&&D.zone&&D.zone.Zd;return Zd&&Zd.dg?Zd.dg:0}catch(e){return 0}};
 const floorScale=f=>{const E=DC.endless;if(!f||f<E.fromFloor)return {hp:1,atk:1,def:0};const k=f-E.fromFloor+1;return {hp:Math.pow(1+E.hpGrowth,k),atk:Math.pow(1+E.atkGrowth,k),def:Math.min(E.defCap,k*E.defPerFloor)}};
 // มอนที่กำหนดให้เกิดในโซน → ใส่เข้าตารางเกิดของโซนนั้น
 try{for(const M of DB.MonstersData){if(M.legacy||M.eventOnly||!M.spawnIn)continue;for(const zid of M.spawnIn){const Z=ZONES.find((z,i)=>z&&i<200&&z.id===zid);if(Z&&!Z.mobs.some(t=>t[1]===M.name))Z.mobs.push([M.family,M.name,M.colors]);(DB.ZoneSpawns[zid]=DB.ZoneSpawns[zid]||[]).push(M.id)}}}catch(e){console.warn('[monsters] zone spawns',e)}
 // สร้างมอน: ใช้ค่าจากฐานข้อมูล + สเกลตามชั้นดันเจี้ยนแบบไม่สิ้นสุด
 const _mk=mkMob;mkMob=function(f,nm,col,L,x,y,o){o=o||{};const fl=curFloor(),E=DC.endless;if(fl>=E.fromFloor&&L>E.levelCap)L=E.levelCap+Math.max(0,Math.min(2,L-fl));
  const m=_mk(f,nm,col,L,x,y,o);
  try{const M=(o.mid&&DB.monster(o.mid))||DB.monsterByKey(f,nm);const F=FAM[f]||{};let hpR=1,atR=1,def=0;
   if(M){m.mid=M.id;m.dropTableId=M.dropTableId;const s=M.stats||{};hpR=(s.hp||F.hp||1)/(F.hp||1);atR=(s.atk||F.atk||1)/(F.atk||1);def=s.def||0;if(s.speed&&F.spd&&s.speed!==F.spd)m.F=Object.assign({},F,{spd:s.speed});if(M.colors&&M.colors!=='band'&&o.mid)m.col=M.colors}
   const sc=floorScale(fl);hpR*=sc.hp;atR*=sc.atk;def=Math.min(.7,def+sc.def);if(o.hpMul)hpR*=o.hpMul;
   if(hpR!==1){m.hp=m.max=Math.max(1,Math.round(m.hp*hpR))}if(atR!==1)m.atk=Math.max(1,Math.round(m.atk*atR));if(def>0)m.def=def;if(o.event)m.event=o.event;if(o.scMul)m.sc*=o.scMul;
   EventBus.emit(EV.MONSTER_SPAWNED,{m,id:m.mid||null,floor:fl})}catch(e){console.warn('[monsters] mkMob',e)}return m};
 window.mkMob=mkMob;
 // ค่าป้องกันมอน (def) ลดดาเมจที่ได้รับ
 {const _h=hurtE;hurtE=function(e,mult,o){if(e&&e.def>0&&isFinite(mult))mult*=1-e.def;return _h(e,mult,o)}}
 // ตาย → ส่งเหตุการณ์ · เหรียญผ่าน Hooks('coin')
 {const _k=mobKill;mobKill=function(m){const c0=inv.coin,wasDead=m&&m.dead;_k(m);if(wasDead)return;try{const d=inv.coin-c0;if(d>0){const nd=Math.round(Hooks.apply('coin',d,{m}));if(nd>d){inv.coin+=nd-d;refreshInv()}}
   const info={m,id:m.mid||null,x:m.x,y:m.y,level:m.L,boss:!!m.boss,elite:!!m.elite,floor:D&&D.dg||0,zone:D&&D.zone&&D.zone.Zd&&D.zone.Zd.id||null};EventBus.emit(EV.MONSTER_DIED,info);if(m.boss)EventBus.emit(EV.BOSS_DIED,info)}catch(e){console.warn('[monsters] kill',e)}}}
 {const _dl=dropLoot;dropLoot=function(x,y,s){_dl(x,y,s);if(s)EventBus.emit(EV.MONSTER_DIED,{m:null,id:'field_slime',x,y,level:1,field:true})}}
 // ตารางดรอป (เฉพาะมอนที่ระบุ dropTableId นอกจาก legacy)
 const ensureImg=k=>{try{if(!DROPIMG[k]){const im=new Image();im.src=iconURL('mat:'+k);DROPIMG[k]=im}}catch(e){}};
 EventBus.on(EV.MONSTER_DIED,d=>{const m=d.m;if(!m||!m.dropTableId||m.dropTableId==='legacy')return;const T=DB.LootTables[m.dropTableId];if(!T)return;const mul=Hooks.apply('dropChance',1,d);
  for(const r of T.rolls){if(Math.random()<Math.min(1,r.chance*mul)){const n=r.min+Math.floor(Math.random()*(r.max-r.min+1));ensureImg(r.item);for(let i=0;i<n;i++)addDrop(r.item,d.x,d.y);EventBus.emit(EV.LOOT_DROPPED,{item:r.item,n,from:m.mid})}}},'monsters.loot');
 // คำขอให้เกิดมอน (จากระบบอีเวนต์ ฯลฯ)
 function spawnById(id,opt){opt=opt||{};const M=DB.monster(id);if(!M||!D||!D.zone||D.home)return null;let x=P.x,y=P.y;for(let t=0;t<30;t++){const a=Math.random()*6.283,r=opt.r||(140+Math.random()*120),nx=P.x+Math.cos(a)*r,ny=P.y+Math.sin(a)*r;if(!zHit(nx,ny)){x=nx;y=ny;break}}
  const fl=curFloor(),L=fl?Math.min(DC.endless.levelCap,fl+2):Math.max(P.lv,(D.zone.Zd.lv||[1,1])[1]);const col=M.colors==='band'?['#999','#444','#fff']:M.colors;
  const m=mkMob(M.family,M.name,col,L,x,y,{mid:M.id,elite:!!opt.elite||!!M.seasonalBoss,event:opt.event,scMul:M.seasonalBoss?1.7:1});m.aggro=1;m.st='chase';D.mobs.push(m);return m}
 EventBus.on('SPAWN_REQUEST',d=>{const m=spawnById(d.monsterId,d);if(m&&d.announce)say(d.announce)},'monsters.spawn');
 Eldoria.register('monsters',{spawnById,floorScale,db:()=>DB.MonstersData});
})();
